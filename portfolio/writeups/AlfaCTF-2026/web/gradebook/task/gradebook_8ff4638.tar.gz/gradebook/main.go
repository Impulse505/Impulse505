package main

import (
	"embed"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strings"
	"time"

	"gopkg.in/yaml.v3"
)

//go:embed index.html
var staticFS embed.FS

const originalAttestat = `# Подтвержденный аттестат
паспорт: "1337676769"
оценки:
  физика: 4
  химия: 3
  информатика: 5
  английский: 4
  русский: 5
  литература: 4
  физкультура: 5
  обществознание: 3
  алгебра: 4
  история: 5
  география: 4
  биология: 3
  геометрия: 4
`

var requiredSubjects = []string{
	"физика", "химия", "информатика", "английский", "русский",
	"литература", "физкультура", "обществознание", "алгебра",
	"история", "география", "биология", "геометрия",
}

const sigP uint64 = 72057594037927931 // 2^56 − 5, простое

var knownSignatures = map[string]uint64{}

func sigOf(b []byte) uint64 {
	var s uint64
	for _, c := range b {
		s = (s*256 + uint64(c)) % sigP
	}
	return s
}

func ruPlural(n int, one, few, many string) string {
	if n < 0 {
		n = -n
	}
	mod100, mod10 := n%100, n%10
	switch {
	case mod100 >= 11 && mod100 <= 14:
		return many
	case mod10 == 1:
		return one
	case mod10 >= 2 && mod10 <= 4:
		return few
	default:
		return many
	}
}

type Attestat struct {
	Passport string         `yaml:"паспорт"`
	Grades   map[string]int `yaml:"оценки"`
}

type CheckResult struct {
	Label string `json:"label"`
	Value string `json:"value"`
	OK    bool   `json:"ok"`
}

type SubmitResponse struct {
	Results []CheckResult `json:"results"`
	Flag    string        `json:"flag,omitempty"`
}

func init() {
	knownSignatures["1337676769"] = sigOf([]byte(originalAttestat))
}

func indexHandler(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}
	data, _ := staticFS.ReadFile("index.html")
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Write(data)
}

func submitHandler(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	if r.Method != http.MethodPost {
		http.Error(w, "POST only", http.StatusMethodNotAllowed)
		return
	}

	attestat := strings.ReplaceAll(r.FormValue("attestat"), "\r\n", "\n")

	var results []CheckResult
	write := func(flag string) {
		_ = json.NewEncoder(w).Encode(SubmitResponse{Results: results, Flag: flag})
	}
	pass := func(label, value string) {
		results = append(results, CheckResult{label, value, true})
	}
	fail := func(label, value string) {
		results = append(results, CheckResult{label, value, false})
		write("")
	}

	var a Attestat
	if err := yaml.Unmarshal([]byte(attestat), &a); err != nil {
		fail("Файл", "не парсится: "+err.Error())
		return
	}
	pass("Файл", "распознан")

	if a.Passport == "" {
		fail("Паспорт", "не указан в аттестате")
		return
	}
	expected, ok := knownSignatures[a.Passport]
	if !ok {
		fail("Паспорт", "не найден в базе приёмной комиссии ("+a.Passport+")")
		return
	}
	pass("Паспорт", "найден в базе ("+a.Passport+")")

	if a.Grades == nil {
		fail("Структура", "поле «оценки» отсутствует")
		return
	}
	if len(a.Grades) != len(requiredSubjects) {
		got, want := len(a.Grades), len(requiredSubjects)
		fail("Структура", fmt.Sprintf("в аттестате %d %s, ожидалось %d",
			got, ruPlural(got, "предмет", "предмета", "предметов"), want))
		return
	}
	for _, subj := range requiredSubjects {
		if _, ok := a.Grades[subj]; !ok {
			fail("Структура", "не хватает предмета: "+subj)
			return
		}
	}
	pass("Структура", "корректна")

	allFive := true
	sum := 0
	for _, subj := range requiredSubjects {
		g := a.Grades[subj]
		if g < 1 || g > 5 {
			fail(subj, fmt.Sprintf("недопустимая оценка: %d", g))
			return
		}
		sum += g
		if g != 5 {
			allFive = false
		}
	}
	avg := float64(sum) / float64(len(requiredSubjects))
	pass("Средний балл", fmt.Sprintf("%.2f", avg))

	got := sigOf([]byte(attestat))
	if got != expected {
		fail("Подпись", fmt.Sprintf("неверна (ожидалось 0x%016x, получено 0x%016x)", expected, got))
		return
	}
	pass("Подпись", fmt.Sprintf("верна (0x%016x)", got))

	if !allFive {
		fail("Результат", "приходите на вступительные экзамены")
		return
	}
	pass("Результат", "круглые пятёрки!")

	flag := "alfa{REDACTED}"

	pass("Зачисление", "Добро пожаловать в ВУЗ!")
	write(flag)
}

func main() {
	http.HandleFunc("/", indexHandler)
	http.HandleFunc("/submit", submitHandler)
	srv := &http.Server{
        Addr:              ":8080",
        ReadHeaderTimeout: 5 * time.Second,
        ReadTimeout:       10 * time.Second,
        WriteTimeout:      10 * time.Second,
        IdleTimeout:       30 * time.Second,
        MaxHeaderBytes:    1 << 14,
    }
    log.Fatal(srv.ListenAndServe())
}
