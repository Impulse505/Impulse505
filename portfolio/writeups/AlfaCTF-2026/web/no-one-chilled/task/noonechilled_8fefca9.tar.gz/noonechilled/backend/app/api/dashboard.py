from typing import Dict, Any
from fastapi import HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from ..db.models import User, ClickLedger, Achievement, UserAchievement, Order, MerchItem
from datetime import datetime, timedelta
async def get_dashboard_stats(
    current_user: User,
    db: Session
):
    stats = {}
    
    if current_user.role == "boss":
        
        stats = await get_boss_stats(db)
    else:
        
        stats = await get_employee_stats(current_user, db)
    
    return stats


async def get_boss_stats(db: Session) -> Dict[str, Any]:
    total_users = db.query(User).filter(User.is_active == True).count()
    total_employees = db.query(User).filter(
        User.is_active == True,
        User.role == "employee"
    ).count()
    
    
    total_tasks = 0
    completed_tasks = 0
    in_progress_tasks = 0
    queued_tasks = 0
    
    
    total_clicks = db.query(func.sum(ClickLedger.delta)).filter(ClickLedger.delta > 0).scalar() or 0
    
    
    total_achievements = db.query(Achievement).count()
    total_awarded = db.query(UserAchievement).count()
    
    
    total_orders = db.query(Order).count()
    pending_orders = db.query(Order).filter(Order.status == "placed").count()
    total_revenue = db.query(func.sum(Order.total_clicks)).filter(Order.status == "fulfilled").scalar() or 0
    
    
    week_ago = datetime.utcnow() - timedelta(days=7)
    recent_tasks = 0  
    recent_clicks = db.query(func.sum(ClickLedger.delta)).filter(
        ClickLedger.delta > 0,
        ClickLedger.created_at >= week_ago
    ).scalar() or 0
    
    return {
        "users": {
            "total": total_users,
            "employees": total_employees,
            "bosses": total_users - total_employees
        },
        "tasks": {
            "total": total_tasks,
            "completed": completed_tasks,
            "in_progress": in_progress_tasks,
            "queued": queued_tasks,
            "completion_rate": (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
        },
        "clicks": {
            "total": total_clicks,
            "recent_week": recent_clicks
        },
        "achievements": {
            "total": total_achievements,
            "awarded": total_awarded
        },
        "store": {
            "total_orders": total_orders,
            "pending_orders": pending_orders,
            "total_revenue": total_revenue
        },
        "activity": {
            "recent_tasks": recent_tasks,
            "recent_clicks": recent_clicks
        }
    }


async def get_employee_stats(user: User, db: Session) -> Dict[str, Any]:
    total_my_tasks = 0
    completed_my_tasks = 0
    in_progress_my_tasks = 0
    queued_my_tasks = 0
    
    my_clicks = db.query(func.sum(ClickLedger.delta)).filter(
        ClickLedger.user_id == user.id,
        ClickLedger.delta > 0
    ).scalar() or 0
    
    my_achievements = db.query(UserAchievement).filter(UserAchievement.user_id == user.id).count()
    total_achievements = db.query(Achievement).count()
    
    my_orders = db.query(Order).filter(Order.user_id == user.id)
    total_my_orders = my_orders.count()
    pending_my_orders = my_orders.filter(Order.status == "placed").count()
    total_spent = db.query(func.sum(Order.total_clicks)).filter(
        Order.user_id == user.id,
        Order.status == "fulfilled"
    ).scalar() or 0
    
    week_ago = datetime.utcnow() - timedelta(days=7)
    recent_my_tasks = 0  
    recent_my_clicks = db.query(func.sum(ClickLedger.delta)).filter(
        ClickLedger.user_id == user.id,
        ClickLedger.delta > 0,
        ClickLedger.created_at >= week_ago
    ).scalar() or 0
    
    balance = 0
    ledger_entries = db.query(ClickLedger).filter(ClickLedger.user_id == user.id).all()
    for entry in ledger_entries:
        balance += entry.delta
    
    return {
        "tasks": {
            "total": total_my_tasks,
            "completed": completed_my_tasks,
            "in_progress": in_progress_my_tasks,
            "queued": queued_my_tasks,
            "completion_rate": (completed_my_tasks / total_my_tasks * 100) if total_my_tasks > 0 else 0
        },
        "clicks": {
            "total_earned": my_clicks,
            "current_balance": balance,
            "recent_week": recent_my_clicks
        },
        "achievements": {
            "earned": my_achievements,
            "total_available": total_achievements,
            "progress": (my_achievements / total_achievements * 100) if total_achievements > 0 else 0
        },
        "store": {
            "total_orders": total_my_orders,
            "pending_orders": pending_my_orders,
            "total_spent": total_spent
        },
        "activity": {
            "recent_tasks": recent_my_tasks,
            "recent_clicks": recent_my_clicks
        }
    }


async def get_recent_activity(
    current_user: User,
    db: Session,
    limit: int = 20
):
    activities = []
    
    recent_clicks = db.query(ClickLedger).filter(ClickLedger.delta > 0).order_by(
        ClickLedger.created_at.desc()
    ).limit(limit).all()
    
    for click in recent_clicks:
        activities.append({
            "type": "clicks_earned",
            "timestamp": click.created_at,
            "data": {
                "user_id": str(click.user_id),
                "clicks": click.delta,
                "reason": click.reason
            }
        })
    
    activities.sort(key=lambda x: x["timestamp"], reverse=True)
    return activities[:limit]


async def get_leaderboard(
    current_user: User,
    db: Session,
    limit: int = 10
):
    leaderboard = []
    
    users = db.query(User).filter(User.is_active == True).all()
    
    for user in users:
        total_clicks = db.query(func.sum(ClickLedger.delta)).filter(
            ClickLedger.user_id == user.id,
            ClickLedger.delta > 0
        ).scalar() or 0
        
        completed_tasks = 0
        
        total_points = 0
        user_achievements = db.query(UserAchievement).filter(
            UserAchievement.user_id == user.id
        ).all()
        
        for ua in user_achievements:
            achievement = db.query(Achievement).filter(Achievement.id == ua.achievement_id).first()
            if achievement:
                total_points += achievement.points
        
        leaderboard.append({
            "user_id": str(user.id),
            "display_name": user.display_name,
            "role": user.role,
            "total_clicks": total_clicks,
            "completed_tasks": completed_tasks,
            "achievement_points": total_points,
            "achievement_count": len(user_achievements)
        })
    
    leaderboard.sort(key=lambda x: x["total_clicks"], reverse=True)
    
    return leaderboard[:limit]
