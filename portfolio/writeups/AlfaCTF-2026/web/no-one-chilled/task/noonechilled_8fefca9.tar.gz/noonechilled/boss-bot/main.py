import asyncio
import signal
import sys
from contextlib import asynccontextmanager
from loguru import logger
from prometheus_client import start_http_server
import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse

from config import settings
from database import db_manager
from chat_processor import chat_processor
from browser_emulator import browser_emulator
from auth import bot_auth
from ws_client import ws_client

logger.remove()
logger.add(
    sys.stdout,
    format="{time:HH:mm:ss} | {level} | {message}",
    level=settings.log_level,
    serialize=False
)
logger.add(
    "logs/boss_bot.log",
    rotation="100 MB",
    retention="7 days",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {message}",
    level=settings.log_level,
    serialize=False
)

app = FastAPI(title="Boss Bot API", version="1.0.0")


@app.get("/health")
async def health_check():
    try:
        await db_manager.get_boss_user()
        await chat_processor.redis_client.ping()
        
        auth_status = await bot_auth.check_authentication()
        
        return {
            "status": "healthy",
            "boss_user": chat_processor.boss_user is not None,
            "redis_connected": chat_processor.redis_client is not None,
            "authenticated": auth_status
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        raise HTTPException(status_code=503, detail="Service unhealthy")


@app.get("/metrics")
async def metrics():
    from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
    return JSONResponse(
        content=generate_latest(),
        media_type=CONTENT_TYPE_LATEST
    )


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting Boss Bot...")
    
    try:
        await db_manager.initialize()
        logger.info("Database initialized")
        await chat_processor.initialize()
        logger.info("Chat processor initialized")
        start_http_server(settings.metrics_port)
        logger.info(f"Metrics server started on port {settings.metrics_port}")
        processing_task = asyncio.create_task(chat_processor.start_processing())
        logger.info("Chat processing started")
        yield
        
    except Exception as e:
        logger.error(f"Failed to start Boss Bot: {e}")
        raise
    finally:
        logger.info("Shutting down Boss Bot...")

        if 'processing_task' in locals():
            processing_task.cancel()
            try:
                await processing_task
            except asyncio.CancelledError:
                pass

        await chat_processor.close()
        await browser_emulator.close()
        await ws_client.close()
        await db_manager.close()
        
        logger.info("Boss Bot stopped")


app.router.lifespan_context = lifespan


def signal_handler(signum, frame):
    logger.info(f"Received signal {signum}, shutting down...")
    sys.exit(0)


async def main():
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    config = uvicorn.Config(
        app=app,
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )
    server = uvicorn.Server(config)
    await server.serve()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Received keyboard interrupt, shutting down...")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        sys.exit(1)
