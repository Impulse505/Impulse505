from typing import List, Optional

from fastapi import APIRouter, HTTPException, Request, WebSocket, WebSocketDisconnect
from sqlalchemy.orm import Session

from ..db.models import User, ChatRoom, ChatMembership, Message
from ..db.schemas import ChatRoomCreate, ChatRoomResponse, MessageCreate, MessageResponse
import json
import uuid
from datetime import datetime
from jose import jwt
from ..core.config import settings
from ..core.database import SessionLocal

router = APIRouter(prefix="/chat", tags=["chat"])


class ConnectionManager:
    def __init__(self):
        self.active_connections: dict = {}  
    
    async def connect(self, websocket: WebSocket, room_id: str, user_id: str):
        if room_id not in self.active_connections:
            self.active_connections[room_id] = []
        self.active_connections[room_id].append({
            "websocket": websocket,
            "user_id": user_id
        })
    
    def disconnect(self, websocket: WebSocket, room_id: str):
        if room_id in self.active_connections:
            self.active_connections[room_id] = [
                conn for conn in self.active_connections[room_id] 
                if conn["websocket"] != websocket
            ]
            if not self.active_connections[room_id]:
                del self.active_connections[room_id]
    
    async def send_personal_message(self, message: str, websocket: WebSocket):
        await websocket.send_text(message)
    
    async def broadcast_to_room(self, message: str, room_id: str, exclude_user_id: str = None):
        if room_id in self.active_connections:
            connections = list(self.active_connections[room_id])
            dead_connections = []
            for connection in connections:
                if exclude_user_id and connection["user_id"] == exclude_user_id:
                    continue
                try:
                    await connection["websocket"].send_text(message)
                except:
                    dead_connections.append(connection["websocket"])

            if dead_connections:
                self.active_connections[room_id] = [
                    conn for conn in self.active_connections[room_id]
                    if conn["websocket"] not in dead_connections
                ]
                if not self.active_connections[room_id]:
                    del self.active_connections[room_id]

manager = ConnectionManager()


async def create_chat_room(
    room_data: ChatRoomCreate,
    current_user: User,
    db: Session
):
    if room_data.kind == "global" and current_user.role != "boss":
        raise HTTPException(status_code=403, detail="Только боссы могут создавать глобальные комнаты")
    
    
    if current_user.role == "employee" and room_data.kind == "dm":
        
        boss = db.query(User).filter(User.role == "boss").first()
        if not boss:
            raise HTTPException(status_code=404, detail="Босс не найден")
        
        
        existing_dm = db.query(ChatRoom).join(ChatMembership).filter(
            ChatRoom.kind == "dm",
            ChatRoom.created_by == current_user.id,
            ChatMembership.user_id == boss.id
        ).first()
        
        if existing_dm:
            raise HTTPException(status_code=400, detail="Личные сообщения с боссом уже существуют")
        
        
        room = ChatRoom(
            kind="dm",
            title=f"Чат с {boss.display_name}",
            created_by=current_user.id
        )
        
        db.add(room)
        db.commit()
        db.refresh(room)
        
        
        membership1 = ChatMembership(
            room_id=room.id,
            user_id=current_user.id,
            role="member"
        )
        membership2 = ChatMembership(
            room_id=room.id,
            user_id=boss.id,
            role="moderator"
        )
        db.add(membership1)
        db.add(membership2)
        db.commit()
        
        return room
    
    
    room = ChatRoom(
        kind=room_data.kind,
        title=room_data.title,
        created_by=current_user.id
    )
    
    db.add(room)
    db.commit()
    db.refresh(room)
    
    
    membership = ChatMembership(
        room_id=room.id,
        user_id=current_user.id,
        role="moderator" if current_user.role == "boss" else "member"
    )
    db.add(membership)
    db.commit()
    
    return room


async def ensure_boss_dm(
    current_user: User,
    db: Session
):
    if current_user.role != "employee":
        raise HTTPException(status_code=403, detail="Только сотрудники могут использовать этот эндпоинт")
    
    
    boss = db.query(User).filter(User.role == "boss").first()
    if not boss:
        raise HTTPException(status_code=404, detail="Босс не найден")

    existing_dm = db.query(ChatRoom).join(ChatMembership).filter(
        ChatRoom.kind == "dm",
        ChatRoom.created_by == current_user.id,
        ChatMembership.user_id == boss.id
    ).first()
    
    if existing_dm:
        return existing_dm
    
    
    room = ChatRoom(
        kind="dm",
        title=f"Чат с {boss.display_name}",
        created_by=current_user.id
    )
    
    db.add(room)
    db.commit()
    db.refresh(room)
    
    
    membership1 = ChatMembership(
        room_id=room.id,
        user_id=current_user.id,
        role="member"
    )
    membership2 = ChatMembership(
        room_id=room.id,
        user_id=boss.id,
        role="moderator"
    )
    db.add(membership1)
    db.add(membership2)
    db.commit()
    
    return room


async def list_chat_rooms(
    current_user: User,
    db: Session,
    unread_only: bool = False
) -> List[ChatRoomResponse]:
    if current_user.role == "employee":
        
        boss = db.query(User).filter(User.role == "boss").first()
        if not boss:
            return []
        
        rooms = db.query(ChatRoom).join(ChatMembership).filter(
            ChatMembership.user_id == current_user.id,
            ChatRoom.is_active == True,
            ChatRoom.kind == "dm"
        ).all()
        
        
        boss_rooms = []
        for room in rooms:
            
            boss_membership = db.query(ChatMembership).filter(
                ChatMembership.room_id == room.id,
                ChatMembership.user_id == boss.id
            ).first()
            if boss_membership:
                boss_rooms.append(room)
        
        rooms = boss_rooms
    else:
        
        rooms = db.query(ChatRoom).join(ChatMembership).filter(
            ChatMembership.user_id == current_user.id,
            ChatRoom.is_active == True
        ).all()
    
    
    result_rooms = []
    for room in rooms:
        
        membership = db.query(ChatMembership).filter(
            ChatMembership.room_id == room.id,
            ChatMembership.user_id == current_user.id
        ).first()
        
        
        unread_count = 0
        if membership and membership.last_read_at:
            unread_count = db.query(Message).filter(
                Message.room_id == room.id,
                Message.sender_id != current_user.id,  
                Message.created_at > membership.last_read_at,
                Message.deleted_at.is_(None)
            ).count()
        elif membership:
            
            unread_count = db.query(Message).filter(
                Message.room_id == room.id,
                Message.sender_id != current_user.id,
                Message.deleted_at.is_(None)
            ).count()
        
        
        if unread_only and unread_count == 0:
            continue
        
        
        room_data = {
            "id": str(room.id),
            "kind": room.kind,
            "title": room.title,
            "created_by": str(room.created_by),
            "created_at": room.created_at,
            "is_active": room.is_active,
            "unread_count": unread_count
        }
        result_rooms.append(room_data)
    
    return result_rooms


async def get_chat_room(
    room_id: str,
    current_user: User,
    db: Session
) -> ChatRoomResponse:
    room = db.query(ChatRoom).filter(ChatRoom.id == room_id).first()
    if not room:
        raise HTTPException(status_code=404, detail="Чат-комната не найдена")
    
    
    membership = db.query(ChatMembership).filter(
        ChatMembership.room_id == room_id,
        ChatMembership.user_id == current_user.id
    ).first()
    
    if not membership:
        raise HTTPException(status_code=403, detail="Вы не участник этой комнаты")
    
    return room


async def join_chat_room(
    room_id: str,
    current_user: User,
    db: Session
):
    room = db.query(ChatRoom).filter(ChatRoom.id == room_id).first()
    if not room:
        raise HTTPException(status_code=404, detail="Чат-комната не найдена")
    
    
    existing_membership = db.query(ChatMembership).filter(
        ChatMembership.room_id == room_id,
        ChatMembership.user_id == current_user.id
    ).first()
    
    if existing_membership:
        raise HTTPException(status_code=400, detail="Вы уже участник этой комнаты")

    membership = ChatMembership(
        room_id=room_id,
        user_id=current_user.id,
        role="member"
    )
    db.add(membership)
    db.commit()
    
    return {"message": "Вы успешно присоединились к комнате"}


async def leave_chat_room(
    room_id: str,
    current_user: User,
    db: Session
):
    membership = db.query(ChatMembership).filter(
        ChatMembership.room_id == room_id,
        ChatMembership.user_id == current_user.id
    ).first()
    
    if not membership:
        raise HTTPException(status_code=404, detail="Вы не участник этой комнаты")
    
    db.delete(membership)
    db.commit()
    
    return {"message": "Вы покинули комнату"}


async def mark_room_as_read(
    room_id: str,
    current_user: User,
    db: Session
):
    membership = db.query(ChatMembership).filter(
        ChatMembership.room_id == room_id,
        ChatMembership.user_id == current_user.id
    ).first()
    
    if not membership:
        raise HTTPException(status_code=403, detail="Вы не участник этой комнаты")
    
    
    membership.last_read_at = datetime.utcnow()
    db.commit()
    
    return {"message": "Комната отмечена как прочитанная"}


async def get_room_messages(
    room_id: str,
    current_user: User,
    db: Session,
    skip: int = 0,
    limit: int = 50
) -> List[MessageResponse]:
    membership = db.query(ChatMembership).filter(
        ChatMembership.room_id == room_id,
        ChatMembership.user_id == current_user.id
    ).first()
    
    if not membership:
        raise HTTPException(status_code=403, detail="Вы не участник этой комнаты")
    
    messages = db.query(Message).join(User, Message.sender_id == User.id).filter(
        Message.room_id == room_id,
        Message.deleted_at.is_(None)
    ).order_by(Message.created_at.desc()).offset(skip).limit(limit).all()
    
    response_messages = []
    for message in messages:
        response_message = {
            "id": str(message.id),
            "room_id": str(message.room_id),
            "sender_id": str(message.sender_id),
            "body": message.body,
            "attachments": message.attachments,
            "created_at": message.created_at,
            "edited_at": message.edited_at,
            "deleted_at": message.deleted_at,
            "sender": {
                "display_name": message.sender.display_name,
                "email": message.sender.email
            }
        }
        response_messages.append(response_message)
    
    
    if membership:
        membership.last_read_at = datetime.utcnow()
        db.commit()
    
    return response_messages[::-1]  


async def send_message_handler(
    room_id: str,
    request: Request,
    current_user: User,
    db: Session
) -> MessageResponse:
    try:
        body = await request.json()
        message_data = MessageCreate(body=body.get("body", ""), attachments=body.get("attachments"))
    except:
        raise HTTPException(status_code=400, detail="Invalid message data")
    
    return await send_message(room_id, message_data, current_user, db)


async def send_message(
    room_id: str,
    message_data: MessageCreate,
    current_user: User,
    db: Session
) -> MessageResponse:
    membership = db.query(ChatMembership).filter(
        ChatMembership.room_id == room_id,
        ChatMembership.user_id == current_user.id
    ).first()
    
    if not membership:
        raise HTTPException(status_code=403, detail="Not a member of this room")
    
    message = Message(
        room_id=room_id,
        sender_id=current_user.id,
        body=message_data.body,
        attachments=message_data.attachments
    )
    
    db.add(message)
    db.commit()
    db.refresh(message)
    
    
    sender = db.query(User).filter(User.id == current_user.id).first()
    
    response_message = {
        "id": str(message.id),
        "room_id": str(message.room_id),
        "sender_id": str(message.sender_id),
        "body": message.body,
        "attachments": message.attachments,
        "created_at": message.created_at,
        "edited_at": message.edited_at,
        "deleted_at": message.deleted_at,
        "sender": {
            "display_name": sender.display_name,
            "email": sender.email
        }
    }
    
    
    await manager.broadcast_to_room(
        json.dumps({
            "type": "new_message",
            "message": {
                "id": str(message.id),
                "room_id": str(message.room_id),
                "body": message.body,
                "sender_id": str(message.sender_id),
                "created_at": message.created_at.isoformat(),
                "attachments": message.attachments,
                "sender": {
                    "display_name": sender.display_name,
                    "email": sender.email
                }
            }
        }),
        room_id
    )
    
    return response_message


async def get_websocket_token(
    current_user: User
):
    from ..core.security import create_access_token
    token = create_access_token(data={"sub": str(current_user.id)})
    return {"token": token}


@router.websocket("/ws/{room_id}")
async def websocket_endpoint(websocket: WebSocket, room_id: str, token: str = None):
    try:
        
        if not token:
            await websocket.accept()
            await websocket.close(code=4001, reason="Токен обязателен")
            return
        
        try:
            
            payload = jwt.decode(token, settings.secret_key, algorithms=["HS256"])
            user_id = payload.get("sub")
            if not user_id:
                await websocket.accept()
                await websocket.close(code=4001, reason="Неверный токен")
                return
        except jwt.InvalidTokenError:
            await websocket.accept()
            await websocket.close(code=4001, reason="Неверный токен")
            return
        
        
        db = SessionLocal()
        try:
            membership = db.query(ChatMembership).filter(
                ChatMembership.room_id == room_id,
                ChatMembership.user_id == user_id
            ).first()
            
            if not membership:
                await websocket.accept()
                await websocket.close(code=4003, reason="Вы не участник этой комнаты")
                return
        finally:
            db.close()
        
        
        await websocket.accept()
        
        
        await manager.connect(websocket, room_id, user_id)
        
        try:
            while True:
                data = await websocket.receive_text()
                message_data = json.loads(data)
                
                
                if message_data.get("type") == "ping":
                    await websocket.send_text(json.dumps({"type": "pong"}))
                elif message_data.get("type") == "message":
                    
                    db = SessionLocal()
                    try:
                        message = Message(
                            room_id=room_id,
                            sender_id=user_id,
                            body=message_data.get("body", ""),
                            attachments=message_data.get("attachments")
                        )
                        db.add(message)
                        db.commit()
                        db.refresh(message)
                        
                        
                        sender = db.query(User).filter(User.id == user_id).first()
                        
                        
                        await manager.broadcast_to_room(
                            json.dumps({
                                "type": "new_message",
                                "message": {
                                    "id": str(message.id),
                                    "room_id": str(message.room_id),
                                    "sender_id": str(message.sender_id),
                                    "body": message.body,
                                    "attachments": message.attachments,
                                    "created_at": message.created_at.isoformat(),
                                    "sender": {
                                        "display_name": sender.display_name,
                                        "email": sender.email
                                    }
                                }
                            }),
                            room_id
                        )
                    finally:
                        db.close()
                elif message_data.get("type") == "typing":
                    
                    await manager.broadcast_to_room(
                        json.dumps({
                            "type": "typing",
                            "user_id": user_id,
                            "is_typing": message_data.get("is_typing", False)
                        }),
                        room_id,
                        exclude_user_id=user_id
                    )
        
        except WebSocketDisconnect:
            manager.disconnect(websocket, room_id)
        except Exception as e:
            print(f"WebSocket error: {e}")
            manager.disconnect(websocket, room_id)
    
    except Exception as e:
        print(f"WebSocket connection error: {e}")
        try:
            await websocket.close(code=4000, reason="Внутренняя ошибка")
        except:
            pass
