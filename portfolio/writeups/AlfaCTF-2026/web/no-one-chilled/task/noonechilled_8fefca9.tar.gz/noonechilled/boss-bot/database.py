import asyncpg
import asyncio
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
import uuid
from loguru import logger
from config import settings


class DatabaseManager:
    def __init__(self):
        self.pool: Optional[asyncpg.Pool] = None
        self._connection_lock = asyncio.Lock()
    
    async def initialize(self):
        try:
            self.pool = await asyncpg.create_pool(
                settings.database_url,
                min_size=5,
                max_size=20,
                command_timeout=60,
                server_settings={
                    'application_name': 'boss_bot'
                }
            )
            logger.info("Database connection pool initialized")
        except Exception as e:
            logger.error(f"Failed to initialize database pool: {e}")
            raise
    
    async def close(self):
        if self.pool:
            await self.pool.close()
            logger.info("Database connection pool closed")
    
    async def get_boss_user(self) -> Optional[Dict[str, Any]]:
        async with self.pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT id, email, display_name, role
                FROM users 
                WHERE role = 'boss' AND is_active = true
                LIMIT 1
                """
            )
            if row:
                logger.info(f"Found boss user: {row['display_name']} ({row['id']})")
                return dict(row)
            else:
                logger.error("No boss user found in database")
                return None
    
    async def get_unread_chats(self, boss_id: str) -> List[Dict[str, Any]]:
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT DISTINCT
                    cr.id as room_id,
                    cr.kind,
                    cr.title,
                    cr.created_at,
                    COUNT(m.id) as unread_count,
                    MAX(m.created_at) as last_message_at
                FROM chat_rooms cr
                JOIN chat_memberships cm ON cr.id = cm.room_id
                LEFT JOIN messages m ON cr.id = m.room_id 
                    AND m.created_at > COALESCE(cm.last_read_at, '1970-01-01'::timestamp)
                    AND m.sender_id != $1
                WHERE cm.user_id = $1 
                    AND cr.is_active = true
                GROUP BY cr.id, cr.kind, cr.title, cr.created_at
                HAVING COUNT(m.id) > 0
                ORDER BY last_message_at DESC
                """,
                boss_id
            )
            return [dict(row) for row in rows]
    
    async def get_unread_messages(self, room_id: str, boss_id: str) -> List[Dict[str, Any]]:
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT 
                    m.id,
                    m.body,
                    m.created_at,
                    u.display_name as sender_name,
                    u.email as sender_email
                FROM messages m
                JOIN users u ON m.sender_id = u.id
                JOIN chat_memberships cm ON m.room_id = cm.room_id
                WHERE m.room_id = $1 
                    AND m.sender_id != $2
                    AND m.created_at > COALESCE(cm.last_read_at, '1970-01-01'::timestamp)
                    AND cm.user_id = $2
                ORDER BY m.created_at ASC
                """,
                room_id, boss_id
            )
            return [dict(row) for row in rows]
    
    async def send_message(self, room_id: str, sender_id: str, message: str) -> str:
        async with self.pool.acquire() as conn:
            is_member = await conn.fetchval(
                """
                SELECT 1 FROM chat_memberships 
                WHERE room_id = $1 AND user_id = $2
                """,
                room_id, sender_id
            )
            
            if not is_member:
                raise Exception(f"User {sender_id} is not a member of room {room_id}")
            
            message_id = str(uuid.uuid4())
            await conn.execute(
                """
                INSERT INTO messages (id, room_id, sender_id, body, created_at)
                VALUES ($1, $2, $3, $4, $5)
                """,
                message_id, room_id, sender_id, message, datetime.utcnow()
            )
            return message_id
    
    async def mark_room_as_read(self, room_id: str, user_id: str):
        async with self.pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE chat_memberships 
                SET last_read_at = $1
                WHERE room_id = $2 AND user_id = $3
                """,
                datetime.utcnow(), room_id, user_id
            )
    
    async def get_chat_members(self, room_id: str) -> List[Dict[str, Any]]:
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT 
                    u.id,
                    u.display_name,
                    u.email,
                    u.role,
                    cm.role as membership_role
                FROM chat_memberships cm
                JOIN users u ON cm.user_id = u.id
                WHERE cm.room_id = $1 AND u.is_active = true
                """,
                room_id
            )
            return [dict(row) for row in rows]
    
    async def is_boss_in_room(self, room_id: str, boss_id: str) -> bool:
        async with self.pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT 1 FROM chat_memberships 
                WHERE room_id = $1 AND user_id = $2
                """,
                room_id, boss_id
            )
            return bool(row)

db_manager = DatabaseManager()
