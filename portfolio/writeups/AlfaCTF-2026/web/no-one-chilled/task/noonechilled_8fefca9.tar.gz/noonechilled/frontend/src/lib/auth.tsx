import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { useNavigate } from 'react-router-dom'
import { apiService } from './api'

interface User {
  id: string
  email: string
  role: 'boss' | 'employee'
  display_name: string
  avatar_url?: string
  timezone: string
}

interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (email: string, password: string, display_name: string, role: string) => Promise<void>
  logout: () => void
  refreshToken: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

interface AuthProviderProps {
  children: ReactNode
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const navigate = useNavigate()

  const fetchUser = async () => {
    try {
      const response = await apiService.getCurrentUser()
      
      if (response.data) {
        setUser(response.data)
      } else {
        await refreshToken()
      }
    } catch (error) {
      console.error('Failed to fetch user:', error)
      logout()
    } finally {
      setIsLoading(false)
    }
  }

  const refreshToken = async () => {
    try {
      const response = await apiService.refreshToken()

      if (response.data && response.data.user) {
        setUser(response.data.user)
        await fetchUser()
      } else {
        logout()
      }
    } catch (error) {
      console.error('Failed to refresh token:', error)
      logout()
    }
  }

  const login = async (email: string, password: string) => {
    const response = await apiService.login(email, password)

    if (response.error) {
      throw new Error(response.error)
    }

    if (response.data && response.data.user) {
      setUser(response.data.user)
      navigate('/')
    }
  }

  const register = async (email: string, password: string, display_name: string, role: string) => {
    const response = await apiService.register(email, password, display_name, role)

    if (response.error) {
      throw new Error(response.error)
    }

    if (response.data && response.data.user) {
      setUser(response.data.user)
      navigate('/')
    }
  }

  const logout = () => {
    apiService.logout().catch(console.error)
    
    setUser(null)
    navigate('/login')
  }

  useEffect(() => {
    fetchUser()
  }, [])

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    register,
    logout,
    refreshToken,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
