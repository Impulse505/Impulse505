import base64
import hashlib
import hmac


def generate_vacation_code(secret: str, boss_id: str) -> str:
    payload = str(boss_id)
    digest = hmac.new(secret.encode("utf-8"), payload.encode("utf-8"), hashlib.sha256).digest()
    return base64.b32encode(digest).decode("ascii").rstrip("=").upper()[:20]
