#!/usr/bin/env python3

import sys
import os
import uuid
from pathlib import Path
from sqlalchemy.orm import Session
from ..core.database import SessionLocal, engine
from ..core.security import get_password_hash
from .models import User, Achievement, MerchItem, ChatRoom, ChatMembership
from ..core.database import Base

SEED_IMAGES_DIR = Path(__file__).resolve().parent / "seed_images"


def load_seed_image_bytes(filename: str) -> bytes:
    image_path = SEED_IMAGES_DIR / filename
    return image_path.read_bytes()


def create_initial_users(db: Session):
    print("Creating initial users...")
    
    boss = db.query(User).filter(User.email == "boss@company.com").first()
    if not boss:
        boss = User(
            id=uuid.uuid4(),
            email="boss@company.com",
            display_name="The Boss",
            role="boss",
            hashed_password=get_password_hash("WhiteboxBossPassword123!"),
            is_active=True
        )
        db.add(boss)
        print("✅ Created boss user: boss@company.com / WhiteboxBossPassword123!")
    
    db.commit()
    return boss


def create_initial_chats(db: Session, boss: User):
    print("Creating initial chat rooms...")
    
    global_room = db.query(ChatRoom).filter(
        ChatRoom.kind == "global",
        ChatRoom.title == "General Chat"
    ).first()
    
    if not global_room:
        global_room = ChatRoom(
            id=uuid.uuid4(),
            kind="global",
            title="General Chat",
            created_by=boss.id,
            is_active=True
        )
        db.add(global_room)
        print("✅ Created global chat room")
    
    boss_global_membership = db.query(ChatMembership).filter(
        ChatMembership.room_id == global_room.id,
        ChatMembership.user_id == boss.id
    ).first()
    
    if not boss_global_membership:
        boss_global_membership = ChatMembership(
            room_id=global_room.id,
            user_id=boss.id,
            role="moderator"
        )
        db.add(boss_global_membership)
    
    employees = db.query(User).filter(User.id != boss.id, User.is_active == True).all()

    for employee in employees:
        emp_global_membership = db.query(ChatMembership).filter(
            ChatMembership.room_id == global_room.id,
            ChatMembership.user_id == employee.id
        ).first()
        
        if not emp_global_membership:
            emp_global_membership = ChatMembership(
                room_id=global_room.id,
                user_id=employee.id,
                role="member"
            )
            db.add(emp_global_membership)
    
    for employee in employees:
        existing_dm = db.query(ChatRoom).join(ChatMembership).filter(
            ChatRoom.kind == "dm",
            ChatRoom.created_by == employee.id,
            ChatMembership.user_id == boss.id
        ).first()
        
        if not existing_dm:
            dm_room = ChatRoom(
                id=uuid.uuid4(),
                kind="dm",
                title=f"Chat with {boss.display_name}",
                created_by=employee.id,
                is_active=True
            )
            db.add(dm_room)
            db.flush()  
            
            emp_membership = ChatMembership(
                room_id=dm_room.id,
                user_id=employee.id,
                role="member"
            )
            db.add(emp_membership)
            
            boss_membership = ChatMembership(
                room_id=dm_room.id,
                user_id=boss.id,
                role="moderator"
            )
            db.add(boss_membership)
            
            print(f"✅ Created DM for {employee.display_name} with boss")
    
    db.commit()


def create_sample_achievements(db: Session):
    print("Creating sample achievements...")
    
    achievements_data = [
        {
            "code": "FIRST_CLICK",
            "name": "Первый клик",
            "description": "Сделайте свой первый клик на работе. Начните свой путь к богатству!",
            "criteria": {"clicks": 1},
            "points": 10
        },
        {
            "code": "CLICK_APPRENTICE",
            "name": "Ученик кликера",
            "description": "Сделайте 10 кликов. Вы только начинаете понимать основы работы кликером.",
            "criteria": {"clicks": 10},
            "points": 20
        },
        {
            "code": "CLICK_NOVICE",
            "name": "Новичок кликера",
            "description": "Сделайте 50 кликов. Ваши пальцы становятся быстрее с каждым кликом.",
            "criteria": {"clicks": 50},
            "points": 30
        },
        {
            "code": "CLICK_ENTHUSIAST",
            "name": "Энтузиаст кликера",
            "description": "Сделайте 100 кликов. Вы проявляете настоящий энтузиазм к работе кликером!",
            "criteria": {"clicks": 100},
            "points": 40
        },
        {
            "code": "CLICK_MASTER",
            "name": "Мастер кликера",
            "description": "Сделайте 500 кликов. Вы достигли уровня мастера в искусстве кликинга.",
            "criteria": {"clicks": 500},
            "points": 50
        },
        {
            "code": "CLICK_LEGEND",
            "name": "Легенда кликера",
            "description": "Сделайте 1000 кликов. Ваше имя войдет в историю работы кликером!",
            "criteria": {"clicks": 1000},
            "points": 100
        },
        {
            "code": "CLICK_GOD",
            "name": "Бог кликера",
            "description": "Сделайте 5000 кликов. Вы достигли божественного уровня в работе кликером!",
            "criteria": {"clicks": 5000},
            "points": 200
        },
        {
            "code": "DAILY_CLICKER",
            "name": "Ежедневный кликер",
            "description": "Сделайте 100 кликов за один день. Покажите свою ежедневную преданность!",
            "criteria": {"daily_clicks": 100},
            "points": 50
        },
        {
            "code": "STREAK_MASTER",
            "name": "Мастер серии",
            "description": "Кликайте 7 дней подряд. Создайте впечатляющую серию ежедневных кликов!",
            "criteria": {"click_streak": 7},
            "points": 75
        },
        {
            "code": "STREAK_LEGEND",
            "name": "Легенда серии",
            "description": "Кликайте 30 дней подряд. Месяц непрерывных кликов - это настоящая легенда!",
            "criteria": {"click_streak": 30},
            "points": 150
        },
        {
            "code": "SPEED_CLICKER",
            "name": "Скоростной кликер",
            "description": "Сделайте 50 кликов менее чем за минуту. Покажите свою скорость!",
            "criteria": {"speed_clicks": 50},
            "points": 100
        },
        {
            "code": "CLICK_MILLIONAIRE",
            "name": "Кликер-миллионер",
            "description": "Заработайте 10,000 кликов в общей сложности. Вы стали настоящим миллионером кликов!",
            "criteria": {"total_clicks": 10000},
            "points": 500
        },
        
        {
            "code": "STORE_SHOPPER",
            "name": "Покупатель",
            "description": "Сделайте свою первую покупку в магазине. Начните тратить заработанные клики!",
            "criteria": {"purchases": 1},
            "points": 30
        },
        {
            "code": "TEAM_PLAYER",
            "name": "Командный игрок",
            "description": "Присоединитесь к 5 чат-комнатам. Покажите свою социальную активность!",
            "criteria": {"chat_rooms": 5},
            "points": 40
        },
        {
            "code": "SOCIAL_BUTTERFLY",
            "name": "Социальная бабочка",
            "description": "Присоединитесь к 10 чат-комнатам. Вы настоящий социальный эксперт!",
            "criteria": {"chat_rooms": 10},
            "points": 80
        },
        {
            "code": "SHOPPING_SPREE",
            "name": "Покупки без остановки",
            "description": "Сделайте 5 покупок в магазине. Вы любите тратить свои клики!",
            "criteria": {"purchases": 5},
            "points": 100
        },
        {
            "code": "CLICK_ADDICT",
            "name": "Кликер-наркоман",
            "description": "Сделайте 100 кликов за один день. Вы действительно зависимы от кликинга!",
            "criteria": {"daily_clicks": 100},
            "points": 150
        },
    ]
    
    for achievement_data in achievements_data:
        existing = db.query(Achievement).filter(Achievement.code == achievement_data["code"]).first()
        if not existing:
            achievement = Achievement(
                id=uuid.uuid4(),
                code=achievement_data["code"],
                name=achievement_data["name"],
                description=achievement_data["description"],
                criteria=achievement_data["criteria"],
                points=achievement_data["points"]
            )
            db.add(achievement)
            print(f"✅ Created achievement: {achievement_data['name']}")
    
    db.commit()


def create_sample_merch_items(db: Session):
    print("Creating sample merchandise items...")
    
    merch_items_data = [
        {
            "sku": "ANTI_LAG_AMULET",
            "name": "Антилаг амулет",
            "description": "Магический амулет, который защищает от лагов и ускоряет клики. Незаменимый предмет для любого кликера!",
            "price_clicks": 500,
            "product_image": load_seed_image_bytes("anti_lag_amulet.jpg"),
            "inventory": 10,
            "category": "accessories"
        },
        {
            "sku": "NO_REPORTS_DAY",
            "name": "День без отчетов",
            "description": "Особый день, когда можно кликать без необходимости писать отчеты. Ценится всеми сотрудниками!",
            "price_clicks": 1000,
            "product_image": load_seed_image_bytes("no_reports_day.jpg"),
            "inventory": 5,
            "category": "special"
        },
        {
            "sku": "CLICK_PET",
            "name": "Клик питомец",
            "description": "Виртуальный питомец, который помогает кликать автоматически. Ваш верный помощник в работе кликером!",
            "price_clicks": 2000,
            "product_image": load_seed_image_bytes("click_pet.jpg"),
            "inventory": 3,
            "category": "pets"
        },
        {
            "sku": "ROYAL_BUTTON",
            "name": "Королевская кнопка",
            "description": "Эксклюзивная кнопка с королевским дизайном. Каждый клик по ней приносит больше удовольствия!",
            "price_clicks": 1500,
            "product_image": load_seed_image_bytes("royal_button.jpg"),
            "inventory": 7,
            "category": "accessories"
        },
        {
            "sku": "COFFEE_FOR_POINTS",
            "name": "Кофе за баллы",
            "description": "Вкусный кофе, который можно получить за клики. Идеально для перерыва между кликами!",
            "price_clicks": 300,
            "product_image": load_seed_image_bytes("coffee_for_points.jpg"),
            "inventory": 20,
            "category": "food"
        },
        {
            "sku": "CURSOR_UPGRADE",
            "name": "Курсор",
            "description": "Улучшенный курсор, который делает клики более точными и эффективными. Обязательно для профессионалов!",
            "price_clicks": 800,
            "product_image": load_seed_image_bytes("cursor.jpg"),
            "inventory": 15,
            "category": "accessories"
        },
    ]
    
    for item_data in merch_items_data:
        existing = db.query(MerchItem).filter(MerchItem.sku == item_data["sku"]).first()
        if not existing:
            item = MerchItem(
                id=uuid.uuid4(),
                sku=item_data["sku"],
                name=item_data["name"],
                description=item_data["description"],
                price_clicks=item_data["price_clicks"],
                product_image=item_data["product_image"],
                inventory=item_data["inventory"],
                category=item_data["category"],
                active=True
            )
            db.add(item)
            print(f"✅ Created merch item: {item_data['name']} ({item_data['price_clicks']} clicks)")
    
    db.commit()


def main():
    print("🌱 Starting database seeding...")
    
    try:
        Base.metadata.create_all(bind=engine)
        print("✅ Database tables created/verified")
    except Exception as e:
        print(f"⚠️  Database table creation warning: {e}")
    
    db = SessionLocal()
    try:
        boss = create_initial_users(db)
        create_initial_chats(db, boss)
        create_sample_achievements(db)
        create_sample_merch_items(db)

    except Exception as e:
        print(f"❌ Error during seeding: {e}")
        db.rollback()
        raise
    finally:
        db.close()


if __name__ == "__main__":
    main()
