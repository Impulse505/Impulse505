import React, { useState, useEffect } from 'react'
import { apiService } from '../lib/api'
import {
  Box,
  Grid,
  Card,
  CardBody,
  VStack,
  HStack,
  Text,
  Heading,
  Button,
  Badge,
  Image,
  useToast,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  FormControl,
  FormLabel,
  NumberInput,
  NumberInputField,
  NumberInputStepper,
  NumberIncrementStepper,
  NumberDecrementStepper,
  useDisclosure,
  Divider,
  Icon,
} from '@chakra-ui/react'
import { 
  AddIcon, 
  StarIcon, 
  CheckIcon,
} from '@chakra-ui/icons'
import { t } from '../lib/translations'


interface StoreItem {
  id: string
  sku: string
  name: string
  description: string
  price_clicks: number
  image_path?: string
  inventory: number
  category: string
  active: boolean
}

interface CartItem {
  item: StoreItem
  quantity: number
}

const StorePage: React.FC = () => {
  const [items, setItems] = useState<StoreItem[]>([])
  const [cart, setCart] = useState<CartItem[]>([])
  const [loading, setLoading] = useState(true)
  const [userBalance, setUserBalance] = useState(0)
  const { isOpen, onOpen, onClose } = useDisclosure()
  const [selectedItem, setSelectedItem] = useState<StoreItem | null>(null)
  const [orderQuantity, setOrderQuantity] = useState(1)
  const toast = useToast()

  useEffect(() => {
    fetchStoreItems()
    fetchUserBalance()
  }, [])

  const fetchStoreItems = async () => {
    try {
      const response = await apiService.getStoreItems()
      
      if (response.data) {
        setItems(response.data)
      } else if (response.error) {
        toast({
          title: t('common', 'error'),
          description: response.error,
          status: 'error',
          duration: 3000,
        })
      }
    } catch (error) {
      toast({
        title: t('common', 'error'),
        description: t('store', 'failedToLoadStoreItems'),
        status: 'error',
        duration: 3000,
      })
    } finally {
      setLoading(false)
    }
  }

  const fetchUserBalance = async () => {
    try {
      const response = await apiService.getDashboardStats()
      
      if (response.data) {
        setUserBalance(response.data.clicks.current_balance)
      }
    } catch (error) {
      console.error('Failed to fetch user balance:', error)
    }
  }

  const addToCart = (item: StoreItem) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(cartItem => cartItem.item.id === item.id)
      if (existingItem) {
        return prevCart.map(cartItem =>
          cartItem.item.id === item.id
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        )
      }
      return [...prevCart, { item, quantity: 1 }]
    })
    
    toast({
      title: t('store', 'addedToCart'),
      description: `${item.name} ${t('store', 'addedToCartDescription')}`,
      status: 'success',
      duration: 2000,
    })
  }

  const removeFromCart = (itemId: string) => {
    setCart(prevCart => prevCart.filter(cartItem => cartItem.item.id !== itemId))
  }



  const getCartTotal = () => {
    return cart.reduce((total, cartItem) => 
      total + (cartItem.item.price_clicks * cartItem.quantity), 0
    )
  }

  const handlePurchase = async () => {
    if (getCartTotal() > userBalance) {
      toast({
        title: t('store', 'insufficientBalance'),
        description: t('store', 'insufficientBalanceDescription'),
        status: 'error',
        duration: 3000,
      })
      return
    }

    try {
      const orderItems = cart.map(cartItem => ({
        merch_item_id: cartItem.item.id,
        qty: cartItem.quantity
      }))

      const response = await apiService.createOrder({ items: orderItems })

      if (response.data) {
        toast({
          title: t('store', 'orderPlacedSuccessfully'),
          description: t('store', 'orderPlacedDescription'),
          status: 'success',
          duration: 5000,
        })
        setCart([])
        fetchUserBalance() 
      } else if (response.error) {
        throw new Error(response.error)
      }
    } catch (error) {
      toast({
        title: t('common', 'error'),
        description: error instanceof Error ? error.message : t('store', 'failedToPlaceOrder'),
        status: 'error',
        duration: 3000,
      })
    }
  }

  const openItemModal = (item: StoreItem) => {
    setSelectedItem(item)
    setOrderQuantity(1)
    onOpen()
  }

  const handleQuickPurchase = async () => {
    if (!selectedItem) return

    if (selectedItem.price_clicks * orderQuantity > userBalance) {
      toast({
        title: t('store', 'insufficientBalance'),
        description: t('store', 'insufficientBalanceForPurchase'),
        status: 'error',
        duration: 3000,
      })
      return
    }

    try {
      const response = await apiService.createOrder({
        items: [{
          merch_item_id: selectedItem.id,
          qty: orderQuantity
        }]
      })

      if (response.data) {
        toast({
          title: t('store', 'purchaseSuccessful'),
          description: `${t('store', 'youPurchased')} ${orderQuantity}x ${selectedItem.name}`,
          status: 'success',
          duration: 3000,
        })
        onClose()
        fetchUserBalance()
      } else if (response.error) {
        throw new Error(response.error)
      }
    } catch (error) {
      toast({
        title: t('common', 'error'),
        description: error instanceof Error ? error.message : t('store', 'failedToCompletePurchase'),
        status: 'error',
        duration: 3000,
      })
    }
  }

  if (loading) {
    return (
      <Box textAlign="center" py={20}>
        <Text color="gray.400">{t('store', 'loadingStore')}</Text>
      </Box>
    )
  }

  return (
    <Box>
      <VStack spacing={6} align="stretch" mb={8}>
        <Box>
          <Heading size="lg" color="white" mb={2}>
            {t('store', 'title')}
          </Heading>
          <Text color="gray.400">
            {t('store', 'description')}
          </Text>
        </Box>

        {/* User Balance */}
        <Card bg="crypto.light" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
          <CardBody p={6}>
            <HStack justify="space-between">
              <VStack align="start" spacing={1}>
                <Text color="gray.400" fontSize="sm">{t('store', 'availableBalance')}</Text>
                <Text color="crypto.success" fontSize="2xl" fontWeight="bold">
                  {userBalance.toLocaleString()} {t('store', 'clicks')}
                </Text>
              </VStack>
              <Icon as={StarIcon} color="crypto.success" boxSize={8} />
            </HStack>
          </CardBody>
        </Card>

        {/* Cart Summary */}
        {cart.length > 0 && (
          <Card bg="crypto.light" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
            <CardBody p={6}>
              <VStack align="stretch" spacing={4}>
                <HStack justify="space-between">
                  <Heading size="md" color="white">{t('store', 'shoppingCart')}</Heading>
                  <Badge colorScheme="green" variant="subtle">
                    {cart.length} {t('store', 'items')}
                  </Badge>
                </HStack>
                
                <VStack align="stretch" spacing={2}>
                  {cart.map((cartItem) => (
                    <HStack key={cartItem.item.id} justify="space-between">
                      <Text color="gray.300">{cartItem.item.name} x{cartItem.quantity}</Text>
                      <HStack spacing={2}>
                        <Text color="crypto.primary" fontWeight="medium">
                          {cartItem.item.price_clicks * cartItem.quantity} {t('store', 'clicks')}
                        </Text>
                        <Button
                          size="sm"
                          colorScheme="red"
                          variant="ghost"
                          onClick={() => removeFromCart(cartItem.item.id)}
                        >
                          {t('store', 'remove')}
                        </Button>
                      </HStack>
                    </HStack>
                  ))}
                </VStack>

                <Divider borderColor="crypto.lighter" />

                <HStack justify="space-between">
                  <Text color="white" fontWeight="bold">{t('store', 'total')}</Text>
                  <Text color="crypto.success" fontSize="lg" fontWeight="bold">
                    {getCartTotal().toLocaleString()} {t('store', 'clicks')}
                  </Text>
                </HStack>

                <Button
                  colorScheme="green"
                  onClick={handlePurchase}
                  isDisabled={getCartTotal() > userBalance}
                  leftIcon={<CheckIcon />}
                >
                  {t('store', 'purchaseAll')}
                </Button>
              </VStack>
            </CardBody>
          </Card>
        )}
      </VStack>

      {/* Store Items Grid */}
      <Grid templateColumns={{ base: '1fr', md: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' }} gap={6}>
        {items.map((item) => (
          <Card key={item.id} bg="crypto.light" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
            <CardBody p={6}>
              <VStack align="stretch" spacing={4}>
                {/* Item Image */}
                <Box
                  bg="crypto.darker"
                  borderRadius="lg"
                  h="240px"
                  overflow="hidden"
                  position="relative"
                >
                  {item.image_path ? (
                    <Image 
                      src={item.image_path}
                      alt={item.name} 
                      w="100%" 
                      h="100%" 
                      objectFit="cover" 
                      objectPosition="center"
                    />
                  ) : (
                    <Box
                      display="flex"
                      alignItems="center"
                      justifyContent="center"
                      h="100%"
                    >
                      <Icon as={AddIcon} color="crypto.lighter" boxSize={12} />
                    </Box>
                  )}
                </Box>

                {/* Item Info */}
                <VStack align="start" spacing={2}>
                  <Heading size="md" color="white">{item.name}</Heading>
                  <Text color="gray.400" fontSize="sm" noOfLines={2}>
                    {item.description}
                  </Text>
                  
                  <HStack justify="space-between" w="full">
                    <Badge colorScheme="blue" variant="subtle">
                      {item.category}
                    </Badge>
                    <Badge colorScheme={item.inventory > 0 ? "green" : "red"} variant="subtle">
                      {item.inventory > 0 ? `${item.inventory} ${t('store', 'inStock')}` : t('store', 'outOfStock')}
                    </Badge>
                  </HStack>

                  <Text color="crypto.primary" fontSize="xl" fontWeight="bold">
                    {item.price_clicks.toLocaleString()} {t('store', 'clicks')}
                  </Text>
                </VStack>

                {/* Action Buttons */}
                <HStack spacing={2}>
                  <Button
                    flex={1}
                    colorScheme="blue"
                    variant="outline"
                    onClick={() => openItemModal(item)}
                    isDisabled={item.inventory <= 0}
                  >
                    {t('store', 'quickBuy')}
                  </Button>
                  <Button
                    flex={1}
                    colorScheme="green"
                    onClick={() => addToCart(item)}
                    isDisabled={item.inventory <= 0}
                    leftIcon={<AddIcon />}
                  >
                    {t('store', 'addToCart')}
                  </Button>
                </HStack>
              </VStack>
            </CardBody>
          </Card>
        ))}
      </Grid>

      {/* Quick Purchase Modal */}
      <Modal isOpen={isOpen} onClose={onClose}>
        <ModalOverlay />
        <ModalContent bg="crypto.light" border="1px solid" borderColor="crypto.lighter">
          <ModalHeader color="white">{t('store', 'quickPurchase')}</ModalHeader>
          <ModalCloseButton color="gray.400" />
          <ModalBody pb={6}>
            {selectedItem && (
              <VStack spacing={4} align="stretch">
                <Text color="gray.300" fontSize="lg" fontWeight="medium">
                  {selectedItem.name}
                </Text>
                <Text color="gray.400">
                  {selectedItem.description}
                </Text>
                
                <HStack justify="space-between">
                  <Text color="gray.300">{t('store', 'price')} {t('store', 'perItem')}:</Text>
                  <Text color="crypto.primary" fontWeight="bold">
                    {selectedItem.price_clicks.toLocaleString()} {t('store', 'clicks')}
                  </Text>
                </HStack>

                <FormControl>
                  <FormLabel color="gray.300">{t('store', 'quantity')}</FormLabel>
                  <NumberInput
                    value={orderQuantity}
                    onChange={(_, value) => setOrderQuantity(value)}
                    min={1}
                    max={selectedItem.inventory}
                  >
                    <NumberInputField bg="crypto.darker" borderColor="crypto.lighter" color="white" />
                    <NumberInputStepper>
                      <NumberIncrementStepper color="crypto.primary" />
                      <NumberDecrementStepper color="crypto.primary" />
                    </NumberInputStepper>
                  </NumberInput>
                </FormControl>

                <HStack justify="space-between">
                  <Text color="white" fontWeight="bold">{t('store', 'total')}:</Text>
                  <Text color="crypto.success" fontSize="lg" fontWeight="bold">
                    {(selectedItem.price_clicks * orderQuantity).toLocaleString()} {t('store', 'clicks')}
                  </Text>
                </HStack>

                <Button
                  colorScheme="green"
                  onClick={handleQuickPurchase}
                  isDisabled={selectedItem.price_clicks * orderQuantity > userBalance}
                  leftIcon={<CheckIcon />}
                >
                  {t('store', 'confirmPurchase')}
                </Button>
              </VStack>
            )}
          </ModalBody>
        </ModalContent>
      </Modal>
    </Box>
  )
}

export default StorePage
