import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { ChakraProvider, Box } from '@chakra-ui/react'
import { QueryClient, QueryClientProvider } from 'react-query'
import { Toaster } from 'react-hot-toast'
import { AuthProvider } from './lib/auth'
import theme from './lib/theme'
import LoginPage from './pages/LoginPage'
import RegisterPage from './pages/RegisterPage'
import DashboardPage from './pages/DashboardPage'

import ChatPage from './pages/ChatPage'
import StorePage from './pages/StorePage'
import ClickerPage from './pages/ClickerPage'
import ProfilePage from './pages/ProfilePage'
import AdminPage from './pages/AdminPage'
import AchievementsPage from './pages/AchievementsPage'
import VacationApprovalPage from './pages/VacationApprovalPage'
import Layout from './components/Layout'
import ProtectedRoute from './components/ProtectedRoute'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
})

function App() {
  return (
    <ChakraProvider theme={theme}>
      <QueryClientProvider client={queryClient}>
        <BrowserRouter>
          <AuthProvider>
            <Box minH="100vh" bg="crypto.dark" color="white">
              <Routes>
                <Route path="/login" element={<LoginPage />} />
                <Route path="/register" element={<RegisterPage />} />
                <Route
                  path="/"
                  element={
                    <ProtectedRoute>
                      <Layout />
                    </ProtectedRoute>
                  }
                >
                                    <Route index element={<DashboardPage />} />
                  <Route path="clicker" element={<ClickerPage />} />
                  <Route path="chat" element={<ChatPage />} />
                  <Route path="store" element={<StorePage />} />
                  <Route path="achievements" element={<AchievementsPage />} />
                  <Route path="profile" element={<ProfilePage />} />
                  <Route path="profile/:id" element={<ProfilePage />} />
                  <Route path="admin" element={<AdminPage />} />
                  <Route path="admin/vacation-approval" element={<VacationApprovalPage />} />
                </Route>
              </Routes>
            </Box>
            <Toaster 
              position="top-right"
              toastOptions={{
                style: {
                  background: '#1e293b',
                  color: '#fff',
                  border: '1px solid #334155',
                },
              }}
            />
          </AuthProvider>
        </BrowserRouter>
      </QueryClientProvider>
    </ChakraProvider>
  )
}

export default App
