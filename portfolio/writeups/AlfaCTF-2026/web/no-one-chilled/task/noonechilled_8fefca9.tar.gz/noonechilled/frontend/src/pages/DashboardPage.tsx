import React, { useState, useEffect } from 'react'
import {
  Box,
  Grid,
  Card,
  CardBody,
  VStack,
  HStack,
  Text,
  Heading,
  Stat,
  StatNumber,
  StatHelpText,
  Progress,
  Icon,
  useToast,
} from '@chakra-ui/react'
import { 
  TimeIcon, 
  ChatIcon, 
  SettingsIcon, 
  StarIcon,
} from '@chakra-ui/icons'
import { useAuth } from '../lib/auth'
import { apiService } from '../lib/api'
import { useNavigate } from 'react-router-dom'
import { t } from '../lib/translations'

interface DashboardStats {
  tasks: { total: number; completed: number; in_progress: number; queued: number; completion_rate: number }
  clicks: { current_balance: number; total_earned: number; recent_week: number }
  achievements: { earned: number; total_available: number; progress: number }
  store: { total_orders: number; pending_orders: number; total_spent: number }
  activity: { recent_clicks: number }
}

const DashboardPage: React.FC = () => {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [loading, setLoading] = useState(true)
  const toast = useToast()

  useEffect(() => {
    fetchDashboardStats()
  }, [])

  const fetchDashboardStats = async () => {
    try {
      const response = await apiService.getDashboardStats()
      
      if (response.data) {
        setStats(response.data)
      } else if (response.error) {
        toast({
          title: t('common', 'error'),
          description: response.error,
          status: 'error',
          duration: 3000,
        })
      }
    } catch (error) {
      toast({
        title: t('common', 'error'),
        description: t('dashboard', 'failedToLoadDashboard'),
        status: 'error',
        duration: 3000,
      })
    } finally {
      setLoading(false)
    }
  }

  const StatCard = ({ title, value, icon, color = 'crypto.primary', subtitle }: {
    title: string
    value: string | number
    icon: any
    color?: string
    subtitle?: string
  }) => (
    <Card bg="crypto.light" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
      <CardBody p={6}>
        <HStack justify="space-between" align="start">
          <VStack align="start" spacing={2}>
            <HStack spacing={2}>
              <Icon as={icon} color={color} boxSize={5} />
              <Text color="gray.400" fontSize="sm" fontWeight="medium">{title}</Text>
            </HStack>
            <Stat>
              <StatNumber color="white" fontSize="2xl" fontWeight="bold">{value}</StatNumber>
              {subtitle && <StatHelpText color="gray.400" fontSize="sm">{subtitle}</StatHelpText>}
            </Stat>
          </VStack>
        </HStack>
      </CardBody>
    </Card>
  )

  if (loading) {
    return (
      <Box textAlign="center" py={20}>
        <Text color="gray.400">{t('dashboard', 'loadingDashboard')}</Text>
      </Box>
    )
  }

  
  if (!stats) {
    return (
      <Box textAlign="center" py={20}>
        <Text color="gray.400">{t('dashboard', 'failedToLoadDashboard')}</Text>
      </Box>
    )
  }

  return (
    <Box>
      <VStack spacing={6} align="stretch" mb={8}>
        <Box>
          <Heading size="lg" color="white" mb={2}>
            {t('dashboard', 'welcomeBack')}, {user?.display_name}! 🚀
          </Heading>
          <Text color="gray.400">
            {t('dashboard', 'cryptoClickingDashboard')}
          </Text>
        </Box>
      </VStack>

      <Grid templateColumns={{ base: '1fr', md: 'repeat(2, 1fr)', lg: 'repeat(4, 1fr)' }} gap={6} mb={8}>
        <StatCard
          title={t('dashboard', 'totalClicks')}
          value={stats?.clicks.current_balance || 0}
          icon={TimeIcon}
          color="crypto.success"
          subtitle={t('dashboard', 'currentBalance')}
        />
        <Box 
          onClick={() => navigate('/clicker')}
          cursor="pointer"
          _hover={{ transform: 'scale(1.02)' }}
          transition="transform 0.2s"
        >
          <StatCard
            title={t('dashboard', 'clickerJob')}
            value={t('dashboard', 'workNow')}
            icon={ChatIcon}
            color="crypto.primary"
            subtitle={t('dashboard', 'earnClicks')}
          />
        </Box>
        <StatCard
          title={t('dashboard', 'totalEarned')}
          value={stats?.clicks.total_earned || 0}
          icon={SettingsIcon}
          color="crypto.accent"
          subtitle={t('dashboard', 'lifetimeClicks')}
        />
        <StatCard
          title={t('dashboard', 'achievements')}
          value={stats?.achievements.earned || 0}
          icon={StarIcon}
          color="crypto.secondary"
          subtitle={t('dashboard', 'unlocked')}
        />
      </Grid>

      <Card bg="crypto.light" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
        <CardBody p={6}>
          <VStack align="stretch" spacing={4}>
            <Heading size="md" color="white">{t('dashboard', 'achievementProgress')}</Heading>
            <VStack spacing={4} align="stretch">
              <Box>
                <HStack justify="space-between" mb={2}>
                  <Text color="gray.300" fontSize="sm">{t('dashboard', 'unlocked')}</Text>
                  <Text color="crypto.success" fontSize="sm" fontWeight="medium">
                    {stats?.achievements.earned || 0}
                  </Text>
                </HStack>
                <Progress 
                  value={stats.achievements.total_available ? (stats.achievements.earned / stats.achievements.total_available) * 100 : 0} 
                  colorScheme="green" 
                  borderRadius="full"
                  bg="crypto.darker"
                />
              </Box>
              <Box>
                <HStack justify="space-between" mb={2}>
                  <Text color="gray.300" fontSize="sm">{t('dashboard', 'available')}</Text>
                  <Text color="crypto.primary" fontSize="sm" fontWeight="medium">
                    {stats?.achievements.total_available || 0}
                  </Text>
                </HStack>
                <Progress 
                  value={100} 
                  colorScheme="blue" 
                  borderRadius="full"
                  bg="crypto.darker"
                />
              </Box>
            </VStack>
          </VStack>
        </CardBody>
      </Card>
    </Box>
  )
}

export default DashboardPage
