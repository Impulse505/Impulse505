from typing import List
from fastapi import HTTPException, status
from sqlalchemy.orm import Session
from ..core.config import settings
from ..core.vacation import generate_vacation_code
from ..db.models import User
from ..db.schemas import UserResponse, UserUpdate, SuccessResponse, VacationRequest
async def get_user(
    user_id: str,
    current_user: User,
    db: Session
):
    if current_user.role != "boss" and str(current_user.id) != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Нет прав для просмотра этого пользователя"
        )
    
    user = db.query(User).filter(User.id == user_id, User.is_active == True).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Пользователь не найден"
        )
    
    return user


async def list_users(
    db: Session,
    current_user: User,
    skip: int = 0,
    limit: int = 100
):
    if current_user.role != "boss":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Нет прав для обновления этого пользователя"
        )

    users = db.query(User).filter(User.is_active == True).offset(skip).limit(limit).all()
    return users


async def update_user(
    user_id: str,
    user_update: UserUpdate,
    current_user: User,
    db: Session
):

    if current_user.role != "boss" and str(current_user.id) != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Нет прав для обновления этого пользователя"
        )
    
    user = db.query(User).filter(User.id == user_id, User.is_active == True).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Пользователь не найден"
        )
    
    
    update_data = user_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(user, field, value)
    
    db.commit()
    db.refresh(user)
    
    return user


async def go_on_vacation_and_soft_delete(
    vacation: VacationRequest,
    current_user: User,
    db: Session
):
    bosses = db.query(User).filter(User.role == "boss", User.is_active == True).all()
    if not bosses:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Нет доступных аккаунтов босса для проверки кода")

    provided = vacation.code.strip().upper()
    is_valid = any(provided == generate_vacation_code(settings.secret_key, str(boss.id)) for boss in bosses)

    if not is_valid:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Неверный код для отпуска")

    
    user = db.query(User).filter(User.id == current_user.id, User.is_active == True).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Пользователь не найден")

    user.is_active = False
    db.commit()

    return {"message": "Аккаунт деактивирован. Приятного отпуска!", "data": {"flag": "alfa{******REDACTED******}"}}
