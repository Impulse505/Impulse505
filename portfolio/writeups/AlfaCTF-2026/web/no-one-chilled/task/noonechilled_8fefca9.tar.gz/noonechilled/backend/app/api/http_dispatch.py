from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from fastapi import HTTPException, Request, Response
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from pydantic import BaseModel, TypeAdapter, ValidationError

from ..core.database import SessionLocal
from ..core.security import get_current_boss, get_current_employee, get_current_user
from ..db.schemas import (
    AchievementCreate,
    AchievementResponse,
    ChatRoomCreate,
    ChatRoomResponse,
    LoginRequest,
    MerchItemCreate,
    MerchItemResponse,
    MerchItemUpdate,
    MessageResponse,
    OrderCreate,
    OrderResponse,
    RegisterRequest,
    SuccessResponse,
    UserAchievementResponse,
    UserResponse,
    UserUpdate,
    VacationApprovalResponse,
    VacationRequest,
)
from . import achievements, auth, chat, dashboard, store, users


class AwardAchievementRequest(BaseModel):
    user_id: str


class PathParam:
    def __init__(self, name: str):
        self.name = name


def _format_validation_error(exc: ValidationError) -> str:
    errors = exc.errors()
    if not errors:
        return "Validation failed"

    first_error = errors[0]
    location = ".".join(str(part) for part in first_error.get("loc", []) if part != "body")
    message = first_error.get("msg", "Validation failed")

    if location:
        return f"{location}: {message}"
    return str(message)


Handler = Callable[["DispatchContext", dict[str, str]], Awaitable[Response]]


@dataclass(frozen=True)
class RouteSpec:
    method: str
    pattern: tuple[str | PathParam, ...]
    handler: Handler

    @property
    def priority(self) -> tuple[int, int]:
        static_count = sum(isinstance(part, str) for part in self.pattern)
        return (len(self.pattern), static_count)

    def match(self, method: str, segments: list[str]) -> dict[str, str] | None:
        if method != self.method or len(segments) < len(self.pattern):
            return None

        params: dict[str, str] = {}
        for part, segment in zip(self.pattern, segments):
            if isinstance(part, PathParam):
                params[part.name] = segment
                continue
            if part != segment:
                return None
        return params


class DispatchContext:
    def __init__(self, request: Request, segments: list[str]):
        self.request = request
        self.segments = segments
        self.db = SessionLocal()
        self._json_body: Any = ...
        self._current_user: Any = ...

    async def close(self) -> None:
        self.db.close()

    async def json_body(self) -> dict[str, Any]:
        if self._json_body is ...:
            raw_body = await self.request.body()
            if not raw_body:
                self._json_body = {}
            else:
                try:
                    self._json_body = await self.request.json()
                except Exception as exc:
                    raise HTTPException(status_code=400, detail="Invalid JSON body") from exc

        if not isinstance(self._json_body, dict):
            raise HTTPException(status_code=422, detail="JSON object expected")

        return self._json_body

    async def body_model(self, model_type: type[BaseModel]) -> BaseModel:
        body = await self.json_body()
        try:
            return model_type.model_validate(body)
        except ValidationError as exc:
            raise HTTPException(status_code=422, detail=_format_validation_error(exc)) from exc

    def current_user(self):
        if self._current_user is ...:
            self._current_user = get_current_user(self.request, self.db)
        return self._current_user

    def current_boss(self):
        return get_current_boss(self.current_user())

    def current_employee(self):
        return get_current_employee(self.current_user())

    def query_str(self, name: str, default: str | None = None) -> str | None:
        value = self.request.query_params.get(name)
        if value is None or value == "":
            return default
        return value

    def query_int(
        self,
        name: str,
        default: int,
        *,
        minimum: int | None = None,
        maximum: int | None = None,
    ) -> int:
        raw_value = self.request.query_params.get(name)
        if raw_value is None or raw_value == "":
            value = default
        else:
            try:
                value = int(raw_value)
            except ValueError as exc:
                raise HTTPException(status_code=422, detail=f"Invalid integer for '{name}'") from exc

        if minimum is not None and value < minimum:
            raise HTTPException(status_code=422, detail=f"'{name}' must be >= {minimum}")
        if maximum is not None and value > maximum:
            raise HTTPException(status_code=422, detail=f"'{name}' must be <= {maximum}")
        return value

    def query_bool(self, name: str, default: bool) -> bool:
        raw_value = self.request.query_params.get(name)
        if raw_value is None or raw_value == "":
            return default

        normalized = raw_value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
        raise HTTPException(status_code=422, detail=f"Invalid boolean for '{name}'")

    def respond(
        self,
        payload: Any,
        response_type: Any = None,
        *,
        carrier: Response | None = None,
    ) -> Response:
        if isinstance(payload, Response):
            response = payload
        else:
            content = self._serialize(payload, response_type)
            response = JSONResponse(content=content)

        if carrier is not None:
            self._merge_carrier(response, carrier)

        return response

    def _serialize(self, payload: Any, response_type: Any) -> Any:
        if response_type is None:
            return jsonable_encoder(payload)

        adapter = TypeAdapter(response_type)
        try:
            validated = adapter.validate_python(payload, from_attributes=True)
        except ValidationError as exc:
            raise HTTPException(status_code=500, detail=exc.errors()) from exc
        return adapter.dump_python(validated, mode="json")

    def _merge_carrier(self, response: Response, carrier: Response) -> None:
        response.status_code = carrier.status_code

        for header, value in carrier.headers.items():
            if header.lower() in {"content-length", "set-cookie"}:
                continue
            response.headers[header] = value

        for header, value in carrier.raw_headers:
            if header.lower() == b"set-cookie":
                response.raw_headers.append((header, value))


USER_ID = PathParam("user_id")
ITEM_ID = PathParam("item_id")
IMAGE_NAME = PathParam("image_name")
ORDER_ID = PathParam("order_id")
ROOM_ID = PathParam("room_id")
ACHIEVEMENT_ID = PathParam("achievement_id")


async def handle_auth_register(ctx: DispatchContext, _: dict[str, str]) -> Response:
    payload = await ctx.body_model(RegisterRequest)
    carrier = Response()
    result = await auth.register(payload, carrier, ctx.db)
    return ctx.respond(result, carrier=carrier)


async def handle_auth_login(ctx: DispatchContext, _: dict[str, str]) -> Response:
    payload = await ctx.body_model(LoginRequest)
    carrier = Response()
    result = await auth.login(payload, carrier, ctx.db)
    return ctx.respond(result, carrier=carrier)


async def handle_auth_refresh(ctx: DispatchContext, _: dict[str, str]) -> Response:
    carrier = Response()
    result = await auth.refresh_token(carrier, ctx.request, ctx.db)
    return ctx.respond(result, carrier=carrier)


async def handle_auth_logout(ctx: DispatchContext, _: dict[str, str]) -> Response:
    carrier = Response()
    result = await auth.logout(carrier)
    return ctx.respond(result, carrier=carrier)


async def handle_auth_vacation_code(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await auth.get_vacation_access_code(ctx.current_boss())
    return ctx.respond(result)


async def handle_auth_vacation_approval(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await auth.get_vacation_approval(ctx.current_boss())
    return ctx.respond(result, VacationApprovalResponse)


async def handle_auth_me(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await auth.get_current_user_info(ctx.current_user())
    return ctx.respond(result, UserResponse)


async def handle_users_me_vacation(ctx: DispatchContext, _: dict[str, str]) -> Response:
    payload = await ctx.body_model(VacationRequest)
    result = await users.go_on_vacation_and_soft_delete(
        payload,
        ctx.request,
        ctx.current_employee(),
        ctx.db,
    )
    return ctx.respond(result, SuccessResponse)


async def handle_users_list(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await users.list_users(
        ctx.db,
        ctx.current_user(),
        skip=ctx.query_int("skip", 0, minimum=0),
        limit=ctx.query_int("limit", 100, minimum=1),
    )
    return ctx.respond(result, list[UserResponse])


async def handle_users_get(ctx: DispatchContext, params: dict[str, str]) -> Response:
    result = await users.get_user(params["user_id"], ctx.current_user(), ctx.db)
    return ctx.respond(result, UserResponse)


async def handle_users_update(ctx: DispatchContext, params: dict[str, str]) -> Response:
    payload = await ctx.body_model(UserUpdate)
    result = await users.update_user(params["user_id"], payload, ctx.current_user(), ctx.db)
    return ctx.respond(result, UserResponse)


async def handle_dashboard_stats(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await dashboard.get_dashboard_stats(ctx.current_user(), ctx.db)
    return ctx.respond(result)


async def handle_dashboard_recent_activity(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await dashboard.get_recent_activity(
        ctx.current_user(),
        ctx.db,
        limit=ctx.query_int("limit", 20, minimum=1),
    )
    return ctx.respond(result)


async def handle_dashboard_leaderboard(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await dashboard.get_leaderboard(
        ctx.current_user(),
        ctx.db,
        limit=ctx.query_int("limit", 10, minimum=1),
    )
    return ctx.respond(result)


async def handle_store_items_create(ctx: DispatchContext, _: dict[str, str]) -> Response:
    ctx.current_boss()
    payload = await ctx.body_model(MerchItemCreate)
    result = await store.create_merch_item(payload, ctx.db)
    return ctx.respond(result, MerchItemResponse)


async def handle_store_items_list(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await store.list_merch_items(
        ctx.db,
        category=ctx.query_str("category"),
        active_only=ctx.query_bool("active_only", True),
        skip=ctx.query_int("skip", 0, minimum=0),
        limit=ctx.query_int("limit", 100, minimum=1, maximum=1000),
    )
    return ctx.respond(result, list[MerchItemResponse])


async def handle_store_items_get(ctx: DispatchContext, params: dict[str, str]) -> Response:
    result = await store.get_merch_item(params["item_id"], ctx.db)
    return ctx.respond(result, MerchItemResponse)


async def handle_store_item_image_get(ctx: DispatchContext, params: dict[str, str]) -> Response:
    return await store.get_merch_item_image(params["image_name"], ctx.db)


async def handle_store_items_update(ctx: DispatchContext, params: dict[str, str]) -> Response:
    ctx.current_boss()
    payload = await ctx.body_model(MerchItemUpdate)
    result = await store.update_merch_item(params["item_id"], payload, ctx.db)
    return ctx.respond(result, MerchItemResponse)


async def handle_store_items_delete(ctx: DispatchContext, params: dict[str, str]) -> Response:
    ctx.current_boss()
    result = await store.delete_merch_item(params["item_id"], ctx.db)
    return ctx.respond(result)


async def handle_store_orders_create(ctx: DispatchContext, _: dict[str, str]) -> Response:
    payload = await ctx.body_model(OrderCreate)
    result = await store.create_order(payload, ctx.current_user(), ctx.db)
    return ctx.respond(result, OrderResponse)


async def handle_store_orders_list(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await store.list_orders(
        ctx.current_user(),
        ctx.db,
        status_filter=ctx.query_str("status_filter"),
        skip=ctx.query_int("skip", 0, minimum=0),
        limit=ctx.query_int("limit", 100, minimum=1, maximum=1000),
    )
    return ctx.respond(result, list[OrderResponse])


async def handle_store_orders_get(ctx: DispatchContext, params: dict[str, str]) -> Response:
    result = await store.get_order(params["order_id"], ctx.current_user(), ctx.db)
    return ctx.respond(result, OrderResponse)


async def handle_store_orders_fulfill(ctx: DispatchContext, params: dict[str, str]) -> Response:
    result = await store.fulfill_order(params["order_id"], ctx.current_boss(), ctx.db)
    return ctx.respond(result)


async def handle_store_balance(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await store.get_click_balance(ctx.current_user(), ctx.db)
    return ctx.respond(result)


async def handle_store_categories(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await store.get_categories(ctx.current_user(), ctx.db)
    return ctx.respond(result, list[str])


async def handle_store_click(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await store.record_click(ctx.current_user(), ctx.db)
    return ctx.respond(result)


async def handle_store_clicker_stats(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await store.get_clicker_stats(ctx.current_user(), ctx.db)
    return ctx.respond(result)


async def handle_achievements_create(ctx: DispatchContext, _: dict[str, str]) -> Response:
    ctx.current_boss()
    payload = await ctx.body_model(AchievementCreate)
    result = await achievements.create_achievement(payload, ctx.db)
    return ctx.respond(result, AchievementResponse)


async def handle_achievements_progress(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await achievements.get_achievements_with_progress(ctx.current_user(), ctx.db)
    return ctx.respond(result, list[dict[str, Any]])


async def handle_achievements_list(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await achievements.list_achievements_only(ctx.db)
    return ctx.respond(result, list[AchievementResponse])


async def handle_achievements_get(ctx: DispatchContext, params: dict[str, str]) -> Response:
    result = await achievements.get_achievement(params["achievement_id"], ctx.db)
    return ctx.respond(result, AchievementResponse)


async def handle_achievements_user_list(ctx: DispatchContext, params: dict[str, str]) -> Response:
    result = await achievements.get_user_achievements(params["user_id"], ctx.current_user(), ctx.db)
    return ctx.respond(result, list[UserAchievementResponse])


async def handle_achievements_me_list(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await achievements.get_my_achievements(ctx.current_user(), ctx.db)
    return ctx.respond(result, list[UserAchievementResponse])


async def handle_achievements_check_progress(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await achievements.check_achievement_progress(ctx.current_user(), ctx.db)
    return ctx.respond(result)


async def handle_achievements_award(ctx: DispatchContext, params: dict[str, str]) -> Response:
    payload = await ctx.body_model(AwardAchievementRequest)
    result = await achievements.manually_award_achievement(
        params["achievement_id"],
        payload.user_id,
        ctx.current_boss(),
        ctx.db,
    )
    return ctx.respond(result)


async def handle_achievements_leaderboard(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await achievements.get_achievement_leaderboard(
        ctx.current_user(),
        ctx.db,
        limit=ctx.query_int("limit", 10, minimum=1, maximum=100),
    )
    return ctx.respond(result)


async def handle_chat_rooms_create(ctx: DispatchContext, _: dict[str, str]) -> Response:
    payload = await ctx.body_model(ChatRoomCreate)
    result = await chat.create_chat_room(payload, ctx.current_user(), ctx.db)
    return ctx.respond(result, ChatRoomResponse)


async def handle_chat_rooms_ensure_boss_dm(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await chat.ensure_boss_dm(ctx.current_user(), ctx.db)
    return ctx.respond(result, ChatRoomResponse)


async def handle_chat_rooms_list(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await chat.list_chat_rooms(
        ctx.current_user(),
        ctx.db,
        unread_only=ctx.query_bool("unread_only", False),
    )
    return ctx.respond(result, list[ChatRoomResponse])


async def handle_chat_room_get(ctx: DispatchContext, params: dict[str, str]) -> Response:
    result = await chat.get_chat_room(params["room_id"], ctx.current_user(), ctx.db)
    return ctx.respond(result, ChatRoomResponse)


async def handle_chat_room_join(ctx: DispatchContext, params: dict[str, str]) -> Response:
    result = await chat.join_chat_room(params["room_id"], ctx.current_user(), ctx.db)
    return ctx.respond(result)


async def handle_chat_room_leave(ctx: DispatchContext, params: dict[str, str]) -> Response:
    result = await chat.leave_chat_room(params["room_id"], ctx.current_user(), ctx.db)
    return ctx.respond(result)


async def handle_chat_room_messages_get(ctx: DispatchContext, params: dict[str, str]) -> Response:
    result = await chat.get_room_messages(
        params["room_id"],
        ctx.current_user(),
        ctx.db,
        skip=ctx.query_int("skip", 0, minimum=0),
        limit=ctx.query_int("limit", 50, minimum=1, maximum=100),
    )
    return ctx.respond(result, list[MessageResponse])


async def handle_chat_room_messages_post(ctx: DispatchContext, params: dict[str, str]) -> Response:
    result = await chat.send_message_handler(params["room_id"], ctx.request, ctx.current_user(), ctx.db)
    return ctx.respond(result, MessageResponse)


async def handle_chat_room_mark_read(ctx: DispatchContext, params: dict[str, str]) -> Response:
    result = await chat.mark_room_as_read(params["room_id"], ctx.current_user(), ctx.db)
    return ctx.respond(result)


async def handle_chat_ws_token(ctx: DispatchContext, _: dict[str, str]) -> Response:
    result = await chat.get_websocket_token(ctx.current_user())
    return ctx.respond(result)


ROUTES = sorted(
    [
        RouteSpec("POST", ("auth", "register"), handle_auth_register),
        RouteSpec("POST", ("auth", "login"), handle_auth_login),
        RouteSpec("POST", ("auth", "refresh"), handle_auth_refresh),
        RouteSpec("POST", ("auth", "logout"), handle_auth_logout),
        RouteSpec("GET", ("auth", "vacation-code"), handle_auth_vacation_code),
        RouteSpec("GET", ("auth", "vacation-approval"), handle_auth_vacation_approval),
        RouteSpec("GET", ("auth", "me"), handle_auth_me),
        RouteSpec("POST", ("users", "me", "vacation"), handle_users_me_vacation),
        RouteSpec("GET", ("users", USER_ID), handle_users_get),
        RouteSpec("GET", ("users",), handle_users_list),
        RouteSpec("PATCH", ("users", USER_ID), handle_users_update),
        RouteSpec("GET", ("dashboard", "stats"), handle_dashboard_stats),
        RouteSpec("GET", ("dashboard", "recent-activity"), handle_dashboard_recent_activity),
        RouteSpec("GET", ("dashboard", "leaderboard"), handle_dashboard_leaderboard),
        RouteSpec("POST", ("store", "items"), handle_store_items_create),
        RouteSpec("GET", ("store", "images", IMAGE_NAME), handle_store_item_image_get),
        RouteSpec("GET", ("store", "items", ITEM_ID), handle_store_items_get),
        RouteSpec("GET", ("store", "items"), handle_store_items_list),
        RouteSpec("PATCH", ("store", "items", ITEM_ID), handle_store_items_update),
        RouteSpec("DELETE", ("store", "items", ITEM_ID), handle_store_items_delete),
        RouteSpec("POST", ("store", "orders"), handle_store_orders_create),
        RouteSpec("GET", ("store", "orders", ORDER_ID), handle_store_orders_get),
        RouteSpec("GET", ("store", "orders"), handle_store_orders_list),
        RouteSpec("PATCH", ("store", "orders", ORDER_ID, "fulfill"), handle_store_orders_fulfill),
        RouteSpec("GET", ("store", "balance"), handle_store_balance),
        RouteSpec("GET", ("store", "categories"), handle_store_categories),
        RouteSpec("POST", ("store", "click"), handle_store_click),
        RouteSpec("GET", ("store", "clicker-stats"), handle_store_clicker_stats),
        RouteSpec("POST", ("achievements",), handle_achievements_create),
        RouteSpec("GET", ("achievements", "user", USER_ID, "achievements"), handle_achievements_user_list),
        RouteSpec("GET", ("achievements", "me", "achievements"), handle_achievements_me_list),
        RouteSpec("POST", ("achievements", "check-progress"), handle_achievements_check_progress),
        RouteSpec("POST", ("achievements", "award", ACHIEVEMENT_ID), handle_achievements_award),
        RouteSpec("GET", ("achievements", "leaderboard"), handle_achievements_leaderboard),
        RouteSpec("GET", ("achievements", "list"), handle_achievements_list),
        RouteSpec("GET", ("achievements", ACHIEVEMENT_ID), handle_achievements_get),
        RouteSpec("GET", ("achievements",), handle_achievements_progress),
        RouteSpec("POST", ("chat", "rooms", "ensure-boss-dm"), handle_chat_rooms_ensure_boss_dm),
        RouteSpec("POST", ("chat", "rooms"), handle_chat_rooms_create),
        RouteSpec("GET", ("chat", "rooms", ROOM_ID, "messages"), handle_chat_room_messages_get),
        RouteSpec("POST", ("chat", "rooms", ROOM_ID, "messages"), handle_chat_room_messages_post),
        RouteSpec("POST", ("chat", "rooms", ROOM_ID, "join"), handle_chat_room_join),
        RouteSpec("POST", ("chat", "rooms", ROOM_ID, "leave"), handle_chat_room_leave),
        RouteSpec("POST", ("chat", "rooms", ROOM_ID, "mark-read"), handle_chat_room_mark_read),
        RouteSpec("GET", ("chat", "rooms", ROOM_ID), handle_chat_room_get),
        RouteSpec("GET", ("chat", "rooms"), handle_chat_rooms_list),
        RouteSpec("GET", ("chat", "ws-token"), handle_chat_ws_token),
    ],
    key=lambda route: route.priority,
    reverse=True,
)


async def dispatch_api_request(request: Request) -> Response:
    api_path = request.url.path.removeprefix("/xhr/api").strip("/")
    segments = [segment for segment in api_path.split("/") if segment]
    ctx = DispatchContext(request, segments)

    try:
        try:
            for route in ROUTES:
                params = route.match(request.method, segments)
                if params is not None:
                    return await route.handler(ctx, params)
            raise HTTPException(status_code=404, detail="Endpoint not found")
        except HTTPException as exc:
            content = {"detail": exc.detail}
            return JSONResponse(
                status_code=exc.status_code,
                content=jsonable_encoder(content),
                headers=exc.headers,
            )
    finally:
        await ctx.close()
