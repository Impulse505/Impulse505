import React, { useState, useEffect } from 'react'
import {
  Box,
  Button,
  Text,
  VStack,
  HStack,
  Card,
  CardBody,
  Heading,
  Stat,
  StatNumber,
  StatHelpText,
  Progress,
  Badge,
  useToast,
  Icon,
  Grid,
  GridItem,
} from '@chakra-ui/react'
import { useAuth } from '../lib/auth'
import { apiService } from '../lib/api'
import { StarIcon, TriangleUpIcon } from '@chakra-ui/icons'
import { t } from '../lib/translations'
import { playClickSound } from '../lib/sound'

interface ClickerStats {
  current_balance: number
  today_clicks: number
  total_clicks_earned: number
  click_streak: number
  max_daily_clicks: number
}

interface ClickRecordResponse {
  message: string
  clicks_earned: number
  new_balance: number
  daily_clicks: number
  max_daily_clicks: number
  awarded_count: number
  awarded_achievements: Array<{
    code: string
    name: string
    points: number
  }>
}

const ClickerPage: React.FC = () => {
  const { user: _user } = useAuth()
  const [stats, setStats] = useState<ClickerStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [clicking, setClicking] = useState(false)
  const [showCoin, setShowCoin] = useState(false)
  const [coinPosition, setCoinPosition] = useState({ x: 0, y: 0 })
  const toast = useToast()

  useEffect(() => {
    fetchClickerStats()
    
    
    const enableAudio = () => {
      import('../lib/sound').then(({ soundManager }) => {
        soundManager.enableAudio()
      })
      document.removeEventListener('click', enableAudio)
      document.removeEventListener('keydown', enableAudio)
    }
    
    document.addEventListener('click', enableAudio)
    document.addEventListener('keydown', enableAudio)
    
    return () => {
      document.removeEventListener('click', enableAudio)
      document.removeEventListener('keydown', enableAudio)
    }
  }, [])

  const fetchClickerStats = async () => {
    try {
      const response = await apiService.getClickerStats()
      
      if (response.data) {
        setStats(response.data)
      } else if (response.error) {
        toast({
          title: t('common', 'error'),
          description: response.error,
          status: 'error',
          duration: 3000,
        })
      }
    } catch (error) {
      toast({
        title: t('common', 'error'),
        description: t('clicker', 'failedToLoadClickerStats'),
        status: 'error',
        duration: 3000,
      })
    } finally {
      setLoading(false)
    }
  }

  const handleClick = async (event: React.MouseEvent) => {
    if (clicking) return

    
    const nextClickNumber = (stats?.today_clicks ?? 0) + 1
    const isMilestone = nextClickNumber % 100 === 0
    playClickSound(isMilestone)

    setClicking(true)

    
    const rect = event.currentTarget.getBoundingClientRect()
    setCoinPosition({
      x: event.clientX - rect.left,
      y: event.clientY - rect.top
    })
    setShowCoin(true)

    try {
      const response = await apiService.recordClick()
      
      if (response.data) {
        const data = response.data as unknown as ClickRecordResponse
        const unlockedAchievements = data.awarded_achievements || []
        
        setStats(prev => prev ? {
          ...prev,
          current_balance: data.new_balance,
          today_clicks: data.daily_clicks
        } : null)

        
        toast({
          title: t('clicker', 'clickRecorded'),
          description: `${t('clicker', 'balance')}: ${data.new_balance} ${t('clicker', 'clicks')}`,
          status: 'success',
          duration: 1000,
          position: 'top-right',
        })

        if (unlockedAchievements.length > 0) {
          const achievementMessage = unlockedAchievements
            .map((achievement) => `${achievement.name} (+${achievement.points} ${t('achievements', 'pts')})`)
            .join(', ')
          const title = unlockedAchievements.length === 1
            ? t('achievements', 'achievementUnlocked')
            : t('achievements', 'achievementsUnlocked')

          toast({
            title,
            description: achievementMessage,
            status: 'warning',
            duration: 3500,
            position: 'bottom',
            isClosable: true,
            render: () => (
              <Box
                p={4}
                bg="linear-gradient(135deg, #d97706 0%, #f59e0b 100%)"
                color="#0f172a"
                border="1px solid rgba(251, 191, 36, 0.7)"
                borderRadius="md"
                boxShadow="0 8px 24px rgba(0, 0, 0, 0.25)"
                width="fit-content"
                maxW="calc(100vw - 2rem)"
              >
                <Text fontWeight="bold" mb={1}>{title}</Text>
                <Text fontSize="sm">{achievementMessage}</Text>
              </Box>
            ),
          })
        }
      } else if (response.error) {
        toast({
          title: t('common', 'error'),
          description: response.error,
          status: 'error',
          duration: 3000,
        })
      }
    } catch (error) {
      toast({
        title: t('common', 'error'),
        description: t('clicker', 'failedToRecordClick'),
        status: 'error',
        duration: 3000,
      })
    } finally {
      setClicking(false)
      
      
      setTimeout(() => {
        setShowCoin(false)
      }, 1000)
    }
  }

  const getDailyProgress = () => {
    if (!stats) return 0
    return (stats.today_clicks / stats.max_daily_clicks) * 100
  }

  const getStreakColor = (streak: number) => {
    if (streak >= 30) return 'purple'
    if (streak >= 7) return 'orange'
    if (streak >= 3) return 'green'
    return 'gray'
  }

  if (loading) {
    return (
      <Box textAlign="center" py={20}>
        <Text color="gray.400">{t('clicker', 'loadingClickerJob')}</Text>
      </Box>
    )
  }

  if (!stats) {
    return (
      <Box textAlign="center" py={20}>
        <Text color="gray.400">{t('clicker', 'failedToLoadClickerStats')}</Text>
      </Box>
    )
  }

  return (
    <Box>
      <VStack spacing={6} align="stretch" mb={8}>
        <Box>
          <Heading size="lg" color="white" mb={2}>
            {t('clicker', 'title')}
          </Heading>
          <Text color="gray.400">
            {t('clicker', 'description')}
          </Text>
        </Box>
      </VStack>

      <Grid templateColumns={{ base: '1fr', lg: '2fr 1fr' }} gap={8}>
        {/* Main Clicker Area */}
        <GridItem>
          <Card bg="crypto.light" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
            <CardBody p={8}>
              <VStack spacing={6}>
                {/* Click Button */}
                <Box position="relative">
                  <Button
                    size="lg"
                    height="200px"
                    width="200px"
                    borderRadius="full"
                    bg="linear-gradient(135deg, crypto.primary 0%, crypto.accent 100%)"
                    color="white"
                    fontSize="2xl"
                    fontWeight="bold"
                    onClick={handleClick}
                    disabled={clicking}

                    _hover={{
                      transform: 'scale(1.05)',
                      boxShadow: '0 10px 30px rgba(0,0,0,0.3)',
                    }}
                    _active={{
                      transform: 'scale(0.95)',
                    }}
                    transition="all 0.2s"
                    sx={{
                      '@keyframes clickPulse': {
                        '0%': { transform: 'scale(1)' },
                        '50%': { transform: 'scale(1.1)' },
                        '100%': { transform: 'scale(1)' }
                      },
                      animation: clicking ? 'clickPulse 0.1s ease-in-out' : 'none'
                    }}
                  >
                    🪙 {t('clicker', 'click')}!
                  </Button>

                  {/* Floating Coin Animation */}
                  {showCoin && (
                    <Box
                      position="absolute"
                      left={coinPosition.x}
                      top={coinPosition.y}

                      pointerEvents="none"
                      fontSize="2xl"
                      sx={{
                        '@keyframes coinFloat': {
                          '0%': { transform: 'translateY(0px) rotate(0deg)', opacity: 1 },
                          '100%': { transform: 'translateY(-100px) rotate(360deg)', opacity: 0 }
                        },
                        animation: 'coinFloat 1s ease-out forwards'
                      }}
                    >
                      🪙
                    </Box>
                  )}
                </Box>

                {/* Click Counter */}
                <Text fontSize="xl" color="crypto.primary" fontWeight="bold">
                  {t('clicker', 'clicksToday')}: {stats.today_clicks}
                </Text>

                {/* Daily Progress */}
                <Box width="100%">
                  <HStack justify="space-between" mb={2}>
                    <Text color="gray.300" fontSize="sm">{t('clicker', 'dailyProgress')}</Text>
                    <Text color="crypto.primary" fontSize="sm" fontWeight="medium">
                      {stats.today_clicks} / {stats.max_daily_clicks}
                    </Text>
                  </HStack>
                  <Progress 
                    value={getDailyProgress()} 
                    colorScheme="green" 
                    borderRadius="full"
                    bg="crypto.darker"
                    height="8px"
                  />
                </Box>
              </VStack>
            </CardBody>
          </Card>
        </GridItem>

        {/* Statistics Panel */}
        <GridItem>
          <VStack spacing={4} align="stretch">
            {/* Current Balance */}
            <Card bg="crypto.light" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
              <CardBody p={6}>
                <Stat>
                  <StatNumber color="crypto.success" fontSize="3xl">
                    {stats.current_balance.toLocaleString()}
                  </StatNumber>
                  <StatHelpText color="gray.400">{t('clicker', 'currentBalance')}</StatHelpText>
                </Stat>
              </CardBody>
            </Card>

            {/* Click Streak */}
            <Card bg="crypto.light" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
              <CardBody p={6}>
                <VStack spacing={2}>
                  <HStack>
                    <Icon as={TriangleUpIcon} color="crypto.accent" boxSize={5} />
                    <Text color="white" fontWeight="bold">{t('clicker', 'clickStreak')}</Text>
                  </HStack>
                  <Badge 
                    colorScheme={getStreakColor(stats.click_streak)} 
                    variant="solid" 
                    fontSize="lg"
                    px={4}
                    py={2}
                    borderRadius="full"
                  >
                    {stats.click_streak} {t('clicker', 'days')}
                  </Badge>
                  <Text color="gray.400" fontSize="sm" textAlign="center">
                    {stats.click_streak >= 7 ? t('clicker', 'amazingStreak') : t('clicker', 'keepClickingDaily')}
                  </Text>
                </VStack>
              </CardBody>
            </Card>

            {/* Total Clicks Earned */}
            <Card bg="crypto.light" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
              <CardBody p={6}>
                <VStack spacing={2}>
                  <HStack>
                    <Icon as={StarIcon} color="crypto.secondary" boxSize={5} />
                    <Text color="white" fontWeight="bold">{t('clicker', 'totalEarned')}</Text>
                  </HStack>
                  <Text color="crypto.secondary" fontSize="2xl" fontWeight="bold">
                    {stats.total_clicks_earned.toLocaleString()}
                  </Text>
                  <Text color="gray.400" fontSize="sm" textAlign="center">
                    {t('clicker', 'lifetimeClicksEarned')}
                  </Text>
                </VStack>
              </CardBody>
            </Card>

            {/* Tips */}
            <Card bg="crypto.lighter" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
              <CardBody p={4}>
                <VStack spacing={2} align="start">
                  <Text color="white" fontWeight="bold" fontSize="sm">{t('clicker', 'tips')}</Text>
                  <Text color="gray.400" fontSize="xs">
                    • {t('clicker', 'clickDailyForStreak')}
                  </Text>
                  <Text color="gray.400" fontSize="xs">
                    • {t('clicker', 'reach100ClicksForBonus')}
                  </Text>
                  <Text color="gray.400" fontSize="xs">
                    • {t('clicker', 'spendClicksInStore')}
                  </Text>
                </VStack>
              </CardBody>
            </Card>
          </VStack>
        </GridItem>
      </Grid>
    </Box>
  )
}

export default ClickerPage
