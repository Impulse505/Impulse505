import React, { useState } from 'react'
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  VStack,
  Heading,
  Text,
  useToast,
  Container,
  Card,
  CardBody,
  InputGroup,
  InputRightElement,
  IconButton,
  Link,
} from '@chakra-ui/react'
import { Link as RouterLink } from 'react-router-dom'
import { ViewIcon, ViewOffIcon } from '@chakra-ui/icons'
import { useAuth } from '../lib/auth'
import { t } from '../lib/translations'

const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const { login } = useAuth()
  const toast = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      await login(email, password)
      toast({
        title: t('auth', 'loginSuccessful'),
        status: 'success',
        duration: 3000,
      })
    } catch (error) {
      toast({
        title: t('auth', 'loginFailed'),
        description: error instanceof Error ? error.message : t('auth', 'invalidCredentials'),
        status: 'error',
        duration: 5000,
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Box
      minH="100vh"
      bg="linear-gradient(135deg, crypto.dark 0%, crypto.darker 100%)"
      display="flex"
      alignItems="center"
      justifyContent="center"
      position="relative"
      overflow="hidden"
    >
      {/* Animated background elements */}
      <Box
        position="absolute"
        top="10%"
        left="10%"
        w="200px"
        h="200px"
        bg="crypto.primary"
        borderRadius="full"
        opacity="0.1"
        animation="float 6s ease-in-out infinite"
      />
      <Box
        position="absolute"
        bottom="20%"
        right="15%"
        w="150px"
        h="150px"
        bg="crypto.accent"
        borderRadius="full"
        opacity="0.1"
        animation="float 8s ease-in-out infinite reverse"
      />
      
      <Container maxW="md" position="relative" zIndex={1}>
        <Card
          bg="crypto.light"
          border="1px solid"
          borderColor="crypto.lighter"
          borderRadius="2xl"
          backdropFilter="blur(20px)"
          boxShadow="0 25px 50px -12px rgba(0, 0, 0, 0.5)"
        >
          <CardBody p={8}>
            <VStack spacing={8}>
              {/* Logo and title */}
              <VStack spacing={4}>
                <Box
                  w="80px"
                  h="80px"
                  bg="linear-gradient(135deg, crypto.primary 0%, crypto.accent 100%)"
                  borderRadius="full"
                  display="flex"
                  alignItems="center"
                  justifyContent="center"
                  fontSize="3xl"
                  boxShadow="0 10px 30px rgba(0, 212, 170, 0.3)"
                >
                  🚀
                </Box>
                <VStack spacing={2}>
                  <Heading size="lg" textAlign="center" color="white">
                    {t('auth', 'welcomeBack')}
                  </Heading>
                  <Text color="gray.400" textAlign="center" fontSize="sm">
                    {t('auth', 'signInToAccess')}
                  </Text>
                </VStack>
              </VStack>
              
              {/* Login form */}
              <Box as="form" w="100%" onSubmit={handleSubmit}>
                <VStack spacing={6}>
                  <FormControl isRequired>
                    <FormLabel color="gray.300" fontSize="sm" fontWeight="medium">
                      {t('auth', 'email')}
                    </FormLabel>
                    <Input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder={t('auth', 'enterEmail')}
                      size="lg"
                      bg="crypto.darker"
                      borderColor="crypto.lighter"
                      _focus={{
                        borderColor: 'crypto.primary',
                        boxShadow: '0 0 0 1px var(--chakra-colors-crypto-primary)',
                      }}
                      _placeholder={{ color: 'gray.500' }}
                    />
                  </FormControl>

                  <FormControl isRequired>
                    <FormLabel color="gray.300" fontSize="sm" fontWeight="medium">
                      {t('auth', 'password')}
                    </FormLabel>
                    <InputGroup size="lg">
                      <Input
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder={t('auth', 'enterPassword')}
                        bg="crypto.darker"
                        borderColor="crypto.lighter"
                        _focus={{
                          borderColor: 'crypto.primary',
                          boxShadow: '0 0 0 1px var(--chakra-colors-crypto-primary)',
                        }}
                        _placeholder={{ color: 'gray.500' }}
                      />
                      <InputRightElement>
                        <IconButton
                          aria-label={showPassword ? t('auth', 'hidePassword') : t('auth', 'showPassword')}
                          icon={showPassword ? <ViewOffIcon /> : <ViewIcon />}
                          onClick={() => setShowPassword(!showPassword)}
                          variant="ghost"
                          size="sm"
                          color="gray.400"
                          _hover={{ color: 'crypto.primary' }}
                        />
                      </InputRightElement>
                    </InputGroup>
                  </FormControl>

                  <Button
                    type="submit"
                    size="lg"
                    w="100%"
                    isLoading={isLoading}
                    loadingText={t('auth', 'signingIn')}
                    bg="linear-gradient(135deg, crypto.primary 0%, crypto.accent 100%)"
                    color="white"
                    _hover={{
                      transform: 'translateY(-2px)',
                      boxShadow: '0 10px 30px rgba(0, 212, 170, 0.3)',
                    }}
                    _active={{
                      transform: 'translateY(0)',
                    }}
                    transition="all 0.2s"
                    fontWeight="semibold"
                  >
                    {t('auth', 'signIn')}
                  </Button>

                  {/* Link to register */}
                  <Text color="gray.400" fontSize="sm" textAlign="center">
                    {t('auth', 'dontHaveAccount')}{' '}
                    <Link as={RouterLink} to="/register" color="crypto.primary" _hover={{ textDecoration: 'underline' }}>
                      {t('auth', 'createAccount')}
                    </Link>
                  </Text>
                </VStack>
              </Box>
            </VStack>
          </CardBody>
        </Card>
      </Container>


    </Box>
  )
}

export default LoginPage
