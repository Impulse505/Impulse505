export interface StaticPreview {
  type: 'image' | 'other'
  url: string
  filename: string
  extension: string
}

export function detectStaticUrls(message: string): StaticPreview[] {
  const urlRegex = /https?:\/\/[^\s]+/g
  const urls = message.match(urlRegex) || []
  
  return urls
    .map(url => {
      try {
        const urlObj = new URL(url)
        const pathname = urlObj.pathname
        const filename = pathname.split('/').pop() || ''
        const extension = filename.split('.').pop()?.toLowerCase() || ''
        
        return {
          type: getFileType(extension),
          url,
          filename,
          extension,
        }
      } catch {
        return null
      }
    })
    .filter((preview): preview is StaticPreview => preview !== null && preview.type === 'image')
}

function getFileType(extension: string): StaticPreview['type'] {
  const imageExtensions = ['png', 'jpg', 'jpeg', 'gif', 'svg', 'ico', 'webp']
  
  if (imageExtensions.includes(extension)) return 'image'
  return 'other'
}

export async function generatePreview(preview: StaticPreview): Promise<string | null> {
  try {
    return preview.url
  } catch {
    return null
  }
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B'
  
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

export function getFileIcon(type: StaticPreview['type']): string {
  switch (type) {
    case 'image': return '🖼️'
    case 'other': return '📄'
  }
}

export function getDomain(url: string): string {
  try {
    return new URL(url).hostname
  } catch {
    return 'unknown'
  }
}
