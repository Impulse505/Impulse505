from typing import List, Optional

from fastapi import HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func

from ..db.models import User, Achievement, UserAchievement, ClickLedger, ChatMembership, Order
from ..db.schemas import AchievementCreate, AchievementResponse, UserAchievementResponse
import uuid
from datetime import datetime


async def create_achievement(
    achievement_data: AchievementCreate,
    db: Session
):
    try:
        existing = db.query(Achievement).filter(Achievement.code == achievement_data.code).first()
        if existing:
            raise HTTPException(status_code=400, detail="Код достижения уже существует")
        
        achievement = Achievement(
            code=achievement_data.code,
            name=achievement_data.name,
            description=achievement_data.description,
            criteria=achievement_data.criteria,
            icon_url=achievement_data.icon_url,
            points=achievement_data.points
        )
        
        db.add(achievement)
        db.commit()
        db.refresh(achievement)
        
        return achievement
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Не удалось создать достижение: {str(e)}")


async def get_achievements_with_progress(
    current_user: User,
    db: Session
):
    try:
        achievements = db.query(Achievement).all()
        if not achievements:
            return []
        progress_data = []
        
        
        total_clicks = db.query(ClickLedger).filter(
            ClickLedger.user_id == current_user.id,
            ClickLedger.delta > 0
        ).with_entities(func.sum(ClickLedger.delta)).scalar() or 0

        if total_clicks is None:
            total_clicks = 0

        from datetime import datetime, timedelta
        today = datetime.utcnow().date()
        today_clicks = db.query(ClickLedger).filter(
            ClickLedger.user_id == current_user.id,
            ClickLedger.reason == "clicker_job",
            func.date(ClickLedger.created_at) == today
        ).count() or 0

        streak = 0
        current_date = today
        while True:
            day_clicks = db.query(ClickLedger).filter(
                ClickLedger.user_id == current_user.id,
                ClickLedger.reason == "clicker_job",
                func.date(ClickLedger.created_at) == current_date
            ).count()
            
            if day_clicks > 0:
                streak += 1
                current_date -= timedelta(days=1)
            else:
                break

        purchases = db.query(Order).filter(
            Order.user_id == current_user.id,
            Order.status == "fulfilled"
        ).count() or 0

        chat_rooms = db.query(ChatMembership).filter(
            ChatMembership.user_id == current_user.id
        ).count() or 0
        
        for achievement in achievements:
            existing = db.query(UserAchievement).filter(
                UserAchievement.user_id == current_user.id,
                UserAchievement.achievement_id == achievement.id
            ).first()
            
            is_unlocked = existing is not None
            progress_percentage = 0
            current_value = 0
            target_value = 0
            progress_description = "Пока нет прогресса"
            
            if not is_unlocked:
                
                criteria = achievement.criteria or {}
                
                if achievement.code == "FIRST_CLICK":
                    current_value = total_clicks
                    target_value = 1
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} кликов"
                
                elif achievement.code == "CLICK_APPRENTICE":
                    current_value = total_clicks
                    target_value = 10
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} кликов"
                
                elif achievement.code == "CLICK_NOVICE":
                    current_value = total_clicks
                    target_value = 50
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} кликов"
                
                elif achievement.code == "CLICK_ENTHUSIAST":
                    current_value = total_clicks
                    target_value = 100
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} кликов"
                
                elif achievement.code == "CLICK_MASTER":
                    current_value = total_clicks
                    target_value = 500
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} кликов"
                
                elif achievement.code == "CLICK_LEGEND":
                    current_value = total_clicks
                    target_value = 1000
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} clicks"
                
                elif achievement.code == "CLICK_GOD":
                    current_value = total_clicks
                    target_value = 5000
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} clicks"
                
                elif achievement.code == "DAILY_CLICKER":
                    current_value = today_clicks
                    target_value = 100
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} кликов сегодня"
                
                elif achievement.code == "STREAK_MASTER":
                    current_value = streak
                    target_value = 7
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} дней серии"
                
                elif achievement.code == "STREAK_LEGEND":
                    current_value = streak
                    target_value = 30
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} дней серии"
                
                elif achievement.code == "SPEED_CLICKER":
                    current_value = today_clicks
                    target_value = 50
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} кликов сегодня"
                
                elif achievement.code == "CLICK_MILLIONAIRE":
                    current_value = total_clicks
                    target_value = 10000
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} кликов всего"
                
                elif achievement.code == "STORE_SHOPPER":
                    current_value = purchases
                    target_value = 1
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} покупок"
                
                elif achievement.code == "TEAM_PLAYER":
                    current_value = chat_rooms
                    target_value = 5
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} чатов"
                
                elif achievement.code == "SOCIAL_BUTTERFLY":
                    current_value = chat_rooms
                    target_value = 10
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} чатов"
                
                elif achievement.code == "SHOPPING_SPREE":
                    current_value = purchases
                    target_value = 5
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} покупок"
                
                elif achievement.code == "CLICK_ADDICT":
                    current_value = today_clicks
                    target_value = 100
                    progress_percentage = min(100, (current_value / target_value) * 100) if target_value > 0 else 0
                    progress_description = f"{current_value}/{target_value} кликов сегодня"
            
            progress_data.append({
                "achievement": {
                    "id": str(achievement.id),
                    "code": achievement.code,
                    "name": achievement.name,
                    "description": achievement.description,
                    "points": achievement.points
                },
                "is_unlocked": is_unlocked,
                "progress_percentage": max(0, min(100, progress_percentage)),
                "progress_description": progress_description,
                "current_value": current_value,
                "target_value": target_value
            })
        
        return progress_data
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Не удалось получить прогресс достижений: {str(e)}")


async def list_achievements_only(
    db: Session
):
    
    try:
        achievements = db.query(Achievement).all()
        return achievements
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Не удалось получить список достижений: {str(e)}")


async def get_achievement(
    achievement_id: str,
    db: Session
):
    try:
        try:
            uuid.UUID(achievement_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="Неверный формат ID достижения")
        
        achievement = db.query(Achievement).filter(Achievement.id == achievement_id).first()
        if not achievement:
            raise HTTPException(status_code=404, detail="Достижение не найдено")
        
        return achievement
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Не удалось получить достижение: {str(e)}")


async def get_user_achievements(
    user_id: str,
    current_user: User,
    db: Session
):
    try:
        try:
            uuid.UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="Неверный формат ID пользователя")
        
        
        if current_user.role != "boss" and str(current_user.id) != user_id:
            raise HTTPException(status_code=403, detail="Нет прав для просмотра достижений этого пользователя")
        
        user_achievements = db.query(UserAchievement).filter(
            UserAchievement.user_id == user_id
        ).all()
        
        return user_achievements
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Не удалось получить достижения пользователя: {str(e)}")


async def get_my_achievements(
    current_user: User,
    db: Session
):
    try:
        user_achievements = db.query(UserAchievement).filter(
            UserAchievement.user_id == current_user.id
        ).all()
        
        return user_achievements
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Не удалось получить достижения: {str(e)}")


async def check_achievement_progress(
    current_user: User,
    db: Session
):
    try:
        achievements = db.query(Achievement).all()
        awarded_achievements = []
        
        for achievement in achievements:
            
            existing = db.query(UserAchievement).filter(
                UserAchievement.user_id == current_user.id,
                UserAchievement.achievement_id == achievement.id
            ).first()
            
            if existing:
                continue

            if await check_achievement_criteria(achievement, current_user, db):
                
                user_achievement = UserAchievement(
                    user_id=current_user.id,
                    achievement_id=achievement.id,
                    awarded_at=datetime.utcnow(),
                    evidence={"auto_awarded": True}
                )
                db.add(user_achievement)
                awarded_achievements.append(achievement)
        
        if awarded_achievements:
            db.commit()
        
        return {
            "awarded_count": len(awarded_achievements),
            "awarded_achievements": [
                {
                    "code": ach.code,
                    "name": ach.name,
                    "points": ach.points
                } for ach in awarded_achievements
            ]
        }
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Не удалось проверить прогресс достижений: {str(e)}")


async def check_achievement_criteria(achievement: Achievement, user: User, db: Session) -> bool:
    if not achievement.criteria:
        return False
    
    criteria = achievement.criteria
    
    
    total_clicks = db.query(ClickLedger).filter(
        ClickLedger.user_id == user.id,
        ClickLedger.delta > 0
    ).with_entities(func.sum(ClickLedger.delta)).scalar() or 0
    
    
    from datetime import datetime, timedelta
    today = datetime.utcnow().date()
    today_clicks = db.query(ClickLedger).filter(
        ClickLedger.user_id == user.id,
        ClickLedger.reason == "clicker_job",
        func.date(ClickLedger.created_at) == today
    ).count()
    
    streak = 0
    current_date = today
    while True:
        day_clicks = db.query(ClickLedger).filter(
            ClickLedger.user_id == user.id,
            ClickLedger.reason == "clicker_job",
            func.date(ClickLedger.created_at) == current_date
        ).count()
        
        if day_clicks > 0:
            streak += 1
            current_date -= timedelta(days=1)
        else:
            break
    
    
    if achievement.code == "FIRST_CLICK":
        return total_clicks >= 1
    
    elif achievement.code == "CLICK_APPRENTICE":
        return total_clicks >= 10
    
    elif achievement.code == "CLICK_NOVICE":
        return total_clicks >= 50
    
    elif achievement.code == "CLICK_ENTHUSIAST":
        return total_clicks >= 100
    
    elif achievement.code == "CLICK_MASTER":
        return total_clicks >= 500
    
    elif achievement.code == "CLICK_LEGEND":
        return total_clicks >= 1000
    
    elif achievement.code == "CLICK_GOD":
        return total_clicks >= 5000
    
    elif achievement.code == "DAILY_CLICKER":
        return today_clicks >= 100
    
    elif achievement.code == "STREAK_MASTER":
        return streak >= 7
    
    elif achievement.code == "STREAK_LEGEND":
        return streak >= 30
    
    elif achievement.code == "CLICK_MILLIONAIRE":
        return total_clicks >= 10000
    
    elif achievement.code == "TEAM_PLAYER":
        
        unique_rooms = db.query(ChatMembership).filter(
            ChatMembership.user_id == user.id
        ).count()
        return unique_rooms >= 5
    
    elif achievement.code == "SPEED_CLICKER":
        
        
        return total_clicks >= 50
    
    
    else:
        if "clicks" in criteria:
            return total_clicks >= criteria["clicks"]
        
        if "daily_clicks" in criteria:
            return today_clicks >= criteria["daily_clicks"]
        
        if "click_streak" in criteria:
            return streak >= criteria["click_streak"]
        
        if "total_clicks" in criteria:
            return total_clicks >= criteria["total_clicks"]
        
        if "purchases" in criteria:
            
            purchases = db.query(Order).filter(
                Order.user_id == user.id,
                Order.status == "fulfilled"
            ).count()
            return purchases >= criteria["purchases"]
        
        if "chat_rooms" in criteria:
            unique_rooms = db.query(ChatMembership).filter(
                ChatMembership.user_id == user.id
            ).count()
            return unique_rooms >= criteria["chat_rooms"]
    
    return False


async def manually_award_achievement(
    achievement_id: str,
    user_id: str,
    current_user: User,
    db: Session
):
    
    try:
        
        try:
            uuid.UUID(achievement_id)
            uuid.UUID(user_id)
        except ValueError:
            raise HTTPException(status_code=400, detail="Неверный формат ID")
        
        achievement = db.query(Achievement).filter(Achievement.id == achievement_id).first()
        if not achievement:
            raise HTTPException(status_code=404, detail="Достижение не найдено")
        
        target_user = db.query(User).filter(User.id == user_id).first()
        if not target_user:
            raise HTTPException(status_code=404, detail="Пользователь не найден")
        
        
        existing = db.query(UserAchievement).filter(
            UserAchievement.user_id == user_id,
            UserAchievement.achievement_id == achievement_id
        ).first()
        
        if existing:
            raise HTTPException(status_code=400, detail="Достижение уже выдано этому пользователю")
        
        
        user_achievement = UserAchievement(
            user_id=user_id,
            achievement_id=achievement_id,
            awarded_at=datetime.utcnow(),
            evidence={"manually_awarded_by": str(current_user.id)}
        )
        db.add(user_achievement)
        db.commit()
        
        return {"message": f"Достижение '{achievement.name}' выдано пользователю"}
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Не удалось выдать достижение: {str(e)}")


async def get_achievement_leaderboard(
    current_user: User,
    db: Session,
    limit: int = 10
):
    
    try:
        
        users_with_points = []
        users = db.query(User).filter(User.is_active == True).all()
        
        for user in users:
            total_points = 0
            user_achievements = db.query(UserAchievement).filter(
                UserAchievement.user_id == user.id
            ).all()
            
            for ua in user_achievements:
                achievement = db.query(Achievement).filter(Achievement.id == ua.achievement_id).first()
                if achievement:
                    total_points += achievement.points
            
            users_with_points.append({
                "user_id": str(user.id),
                "display_name": user.display_name,
                "role": user.role,
                "total_points": total_points,
                "achievement_count": len(user_achievements)
            })

        users_with_points.sort(key=lambda x: x["total_points"], reverse=True)
        
        return users_with_points[:limit]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Не удалось получить таблицу лидеров: {str(e)}")
