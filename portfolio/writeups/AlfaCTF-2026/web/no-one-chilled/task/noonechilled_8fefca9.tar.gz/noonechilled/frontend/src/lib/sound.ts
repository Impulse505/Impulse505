class SoundManager {
  private audioContext: AudioContext | null = null
  private clickSound: HTMLAudioElement | null = null
  private milestoneSound: HTMLAudioElement | null = null

  constructor() {
    this.initAudio()
  }

  private initAudio() {
    try {
      
      this.clickSound = new Audio('/sounds/123.mp3')
      this.clickSound.preload = 'auto'
      this.milestoneSound = new Audio('/sounds/321.mp3')
      this.milestoneSound.preload = 'auto'
      
      if (typeof window !== 'undefined' && window.AudioContext) {
        this.audioContext = new AudioContext()
      }
    } catch (error) {
      console.warn('Audio initialization failed:', error)
    }
  }

  public playClickSound(isMilestone: boolean = false) {
    try {
      
      const target = isMilestone ? this.milestoneSound : this.clickSound
      if (target) {
        target.currentTime = 0
        target.play().catch(() => {
          this.playGeneratedClickSound()
        })
      } else {
        this.playGeneratedClickSound()
      }
    } catch (error) {
      console.warn('Failed to play click sound:', error)
    }
  }

  private playGeneratedClickSound() {
    if (!this.audioContext) return

    try {
      
      const oscillator = this.audioContext.createOscillator()
      const gainNode = this.audioContext.createGain()
      
      oscillator.connect(gainNode)
      gainNode.connect(this.audioContext.destination)
      
      oscillator.frequency.setValueAtTime(800, this.audioContext.currentTime)
      oscillator.frequency.exponentialRampToValueAtTime(400, this.audioContext.currentTime + 0.1)
      
      gainNode.gain.setValueAtTime(0.3, this.audioContext.currentTime)
      gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.1)
      
      oscillator.start(this.audioContext.currentTime)
      oscillator.stop(this.audioContext.currentTime + 0.1)
    } catch (error) {
      console.warn('Failed to generate click sound:', error)
    }
  }

  public enableAudio() {
    if (this.audioContext && this.audioContext.state === 'suspended') {
      this.audioContext.resume()
    }
  }
}

export const soundManager = new SoundManager()

export const playClickSound = (isMilestone: boolean = false) => {
  soundManager.playClickSound(isMilestone)
}
