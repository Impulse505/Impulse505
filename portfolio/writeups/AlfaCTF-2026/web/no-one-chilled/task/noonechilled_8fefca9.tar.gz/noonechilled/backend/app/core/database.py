from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from .config import settings


engine = create_engine(
    settings.database_url,
    pool_pre_ping=True,
    pool_size=50,
    max_overflow=100,
    pool_recycle=3600,
    echo=False,
    pool_reset_on_return='commit',
)


SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


Base = declarative_base()


def get_db():
    
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
