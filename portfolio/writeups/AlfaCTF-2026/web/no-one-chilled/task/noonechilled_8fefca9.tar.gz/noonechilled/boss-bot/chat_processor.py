import asyncio
import random
import time
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from loguru import logger
from prometheus_client import Counter, Histogram, Gauge
import redis.asyncio as redis

from config import settings
from database import db_manager
from browser_emulator import browser_emulator
from auth import bot_auth
from ws_client import ws_client

messages_processed = Counter('boss_bot_messages_processed_total', 'Total messages processed')
messages_sent = Counter('boss_bot_messages_sent_total', 'Total messages sent by bot')
processing_time = Histogram('boss_bot_message_processing_seconds', 'Time spent processing messages')
active_chats = Gauge('boss_bot_active_chats', 'Number of active chats being processed')
error_counter = Counter('boss_bot_errors_total', 'Total errors encountered')

class ChatProcessor:
    def __init__(self):
        self.redis_client: Optional[redis.Redis] = None
        self.boss_user: Optional[Dict[str, Any]] = None
        self.processing_tasks: Dict[str, asyncio.Task] = {}
        self.stop_event = asyncio.Event()
        
    async def initialize(self):
        try:
            self.redis_client = redis.from_url(settings.redis_url)
            await self.redis_client.ping()
            logger.info("Redis connection established")
            
            await bot_auth.initialize()
            auth_success = await bot_auth.authenticate()
            if not auth_success:
                raise Exception("Failed to authenticate bot")
            logger.info("Bot authentication successful")
            
            await ws_client.initialize(http_base_url=bot_auth.api_base_url)
            await browser_emulator.initialize(session=bot_auth.session)
            
            self.boss_user = await db_manager.get_boss_user()
            if not self.boss_user:
                raise Exception("Boss user not found in database")
            
            logger.info(f"Bot initialized for boss: {self.boss_user['display_name']}")
            
        except Exception as e:
            logger.error(f"Failed to initialize chat processor: {e}")
            raise
    
    async def close(self):
        self.stop_event.set()
        
        for task in self.processing_tasks.values():
            task.cancel()
        
        if self.processing_tasks:
            await asyncio.gather(*self.processing_tasks.values(), return_exceptions=True)
        
        if self.redis_client:
            await self.redis_client.close()
        
        
        await bot_auth.close()
        await ws_client.close()
        
        logger.info("Chat processor closed")
    
    async def start_processing(self):
        logger.info("Starting chat processing loop")
        last_auth_check = 0
        auth_check_interval = settings.auth_refresh_interval
        
        while not self.stop_event.is_set():
            try:
                current_time = time.time()
                if current_time - last_auth_check > auth_check_interval:
                    try:
                        await bot_auth.refresh_auth_if_needed()
                        last_auth_check = current_time
                    except Exception as e:
                        logger.error(f"Error refreshing authentication: {e}")
                
                await self._process_unread_chats()
                await asyncio.sleep(settings.chat_polling_interval)
                
            except Exception as e:
                logger.error(f"Error in main processing loop: {e}")
                error_counter.inc()
                await asyncio.sleep(5)  
    
    async def _process_unread_chats(self):
        try:
            unread_chats = await db_manager.get_unread_chats(self.boss_user['id'])
            active_chats.set(len(unread_chats))
            
            if len(self.processing_tasks) >= settings.max_concurrent_chats:
                logger.info(f"Max concurrent chats reached ({settings.max_concurrent_chats})")
                return
            
            for chat in unread_chats:
                if chat['room_id'] not in self.processing_tasks:
                    
                    if await self._check_rate_limit(chat['room_id']):
                        task = asyncio.create_task(self._process_chat(chat))
                        self.processing_tasks[chat['room_id']] = task
                        task.add_done_callback(lambda t, room_id=chat['room_id']: 
                                             self.processing_tasks.pop(room_id, None))
                    
        except Exception as e:
            logger.error(f"Error processing unread chats: {e}")
            error_counter.inc()
    
    async def _process_chat(self, chat: Dict[str, Any]):
        room_id = chat['room_id']
        start_time = time.time()
        
        try:
            logger.info(f"Chat: {room_id} ({chat['unread_count']} messages)")
            
            is_member = await db_manager.is_boss_in_room(room_id, self.boss_user['id'])
            if not is_member:
                logger.warning(f"Boss is not a member of room {room_id}")
                return
            
            messages = await db_manager.get_unread_messages(room_id, self.boss_user['id'])
            
            if not messages:
                return
            
            for message in messages:
                await self._process_message(room_id, message)
                messages_processed.inc()
                await asyncio.sleep(settings.message_processing_delay)
            
            await db_manager.mark_room_as_read(room_id, self.boss_user['id'])
            
            processing_time.observe(time.time() - start_time)
            logger.info(f"Completed: {room_id}")
            
        except Exception as e:
            logger.error(f"Error processing chat {room_id}: {e}")
            error_counter.inc()
    
    async def _process_message(self, room_id: str, message: Dict[str, Any]):
        try:
            await self._process_static_urls(message)
            should_respond = await self._should_respond(room_id, message)
            if not should_respond:
                return
            response = await self._generate_response(message)
            if response:
                try:
                    token = await bot_auth.get_websocket_token()
                    sent_via_ws = False
                    if token:
                        sent_via_ws = await ws_client.send_message(room_id, response, token)
                    if not sent_via_ws:
                        await db_manager.send_message(room_id, self.boss_user['id'], response)
                    messages_sent.inc()
                    await self._set_rate_limit(room_id)
                    logger.info(f"Sent: {room_id}")
                except Exception as e:
                    logger.error(f"Failed to send message to {room_id}: {e}")
            
        except Exception as e:
            logger.error(f"Error processing message in {room_id}: {e}")
            error_counter.inc()
    
    async def _should_respond(self, room_id: str, message: Dict[str, Any]) -> bool:
        try:
            message_time = message['created_at']
            if isinstance(message_time, str):
                message_time = datetime.fromisoformat(message_time.replace('Z', '+00:00'))
            if datetime.now(message_time.tzinfo) - message_time > timedelta(hours=24):
                logger.info(f"Message too old, skipping: {message_time}")
                return False
            last_response_key = f"boss_bot:last_response:{room_id}"
            last_response = await self.redis_client.get(last_response_key)
            if last_response:
                last_response_time = float(last_response)
                if time.time() - last_response_time < 30:  
                    logger.info(f"Rate limited, skipping: {time.time() - last_response_time}s ago")
                    return False
            
            message_text = message['body'].lower()
            keywords = ['отпуск', 'отдых', 'выходной', 'больничный', 'кликать', 'клики', 'работа', 'продуктивность', 'привет', 'hello', 'hi', 'бот', 'boss', 'начальник', 'управляющий', 'скуч', 'скук', 'зае', 'кек', 'лол', 'мем', 'хах', 'kek', 'lol', 'mem', 'hah']
            if any(keyword in message_text for keyword in keywords):
                logger.info(f"Keyword match found: {message_text}")
                return True
            
            should_respond = random.random() < 0.3
            logger.info(f"Random response check: {should_respond}")
            return should_respond
            
        except Exception as e:
            logger.error(f"Error checking if should respond: {e}")
            return False
    
    async def _generate_response(self, message: Dict[str, Any]) -> str:
        try:
            message_text = message['body'].lower()
            
            if any(word in message_text for word in ['отпуск', 'отдых', 'выходной']):
                responses = [
                    "Лучше кликай, в отпуск никто не пойдет",
                    "Отпуск - это для слабаков",
                    "Работай больше, отдыхай меньше",
                    "Кликай вместо отпуска",
                    "https://www.dailyfunnyquote.com/wp-content/uploads/2025/08/funny-work-meme-dog.jpg",
                    "https://i.chzbgr.com/full/10483390976/hB6A90A65/meme.png"
                ]
            elif any(word in message_text for word in ['больничный', 'болею', 'заболел']):
                responses = [
                    "Болезнь - не оправдание, кликай через боль",
                    "Кликай даже когда болеете",
                    "Продуктивность превыше здоровья",
                    "https://www.dailyfunnyquote.com/wp-content/uploads/2025/08/funny-work-memes-coworkers.jpg",
                    "https://framerusercontent.com/images/NyUhF13NrMfa59T9d5BAEVy5jbo.png"
                ]
            elif any(word in message_text for word in ['кликать', 'клики', 'работ']):
                responses = [
                    "Кликай быстрее, время деньги",
                    "Больше кликов - больше успеха",
                    "Кликай до изнеможения",
                    "Кликай или уходи",
                    "https://www.teamtravelsource.com/wp-content/uploads/2022/10/zoom-meme.png",
                    "https://framerusercontent.com/images/G9qLlsBlzIMf8Q5SWNLKVuqtE8.png",
                    "https://i.chzbgr.com/full/10483387904/h850622D1/s-going-corporatebish/meme.png"
                ]
            elif any(word in message_text for word in ['привет', 'hello', 'hi', 'бот', 'boss', 'начальник']):
                responses = [
                    "Привет! Готов к работе?",
                    "Здравствуйте! Время кликать!",
                    "Приветствую! Продуктивность превыше всего!",
                    "Добро пожаловать! Кликай усердно!",
                    "https://framerusercontent.com/images/NyUhF13NrMfa59T9d5BAEVy5jbo.png"
                ]
            elif any(word in message_text for word in ['скуч', 'скук', 'зае', 'кек', 'лол', 'мем', 'хах', 'kek', 'lol', 'mem', 'hah']):
                responses = [
                    "https://www.dailyfunnyquote.com/wp-content/uploads/2025/08/funny-work-meme-dog.jpg",
                    "https://i.chzbgr.com/full/10483390976/hB6A90A65/meme.png",
                    "https://www.dailyfunnyquote.com/wp-content/uploads/2025/08/funny-work-memes-coworkers.jpg",
                    "https://framerusercontent.com/images/NyUhF13NrMfa59T9d5BAEVy5jbo.png",
                    "https://www.teamtravelsource.com/wp-content/uploads/2022/10/zoom-meme.png",
                    "https://framerusercontent.com/images/G9qLlsBlzIMf8Q5SWNLKVuqtE8.png",
                    "https://i.chzbgr.com/full/10483387904/h850622D1/s-going-corporatebish/meme.png",
                ]
            else:
                responses = settings.response_templates
            
            return random.choice(responses)
            
        except Exception as e:
            logger.error(f"Error generating response: {e}")
            return random.choice(settings.response_templates)
    
    async def _check_rate_limit(self, room_id: str) -> bool:
        try:
            rate_limit_key = f"boss_bot:rate_limit:{room_id}"
            current_count = await self.redis_client.get(rate_limit_key)
            
            if current_count and int(current_count) >= 200:  
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error checking rate limit: {e}")
            return True  
    
    async def _set_rate_limit(self, room_id: str):
        try:
            rate_limit_key = f"boss_bot:rate_limit:{room_id}"
            await self.redis_client.incr(rate_limit_key)
            await self.redis_client.expire(rate_limit_key, 60)  
            
        except Exception as e:
            logger.error(f"Error setting rate limit: {e}")
    
    async def _process_static_urls(self, message: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        try:
            message_text = message['body']
            
            static_urls = browser_emulator.detect_static_urls(message_text)
            
            if not static_urls:
                return None
            
            logger.info(f"Processing {len(static_urls)} URLs")
            
            attachments = []
            for static_url in static_urls:
                try:
                    file_type = static_url['type']
                    filename = static_url['filename']
                    url = static_url['url']
                    extension = static_url['extension']
                    
                    preview = await browser_emulator.generate_preview(static_url)
                    if not preview:
                        continue

                    attachment = {
                        "type": "image",
                        "url": url,
                        "filename": filename,
                        "extension": extension
                    }
                    
                    attachments.append(attachment)
                    await asyncio.sleep(0.1)
                    
                except Exception as e:
                    logger.error(f"Error processing URL {static_url['url']}: {e}")
            
            if attachments:
                return {"attachments": attachments}
            return None
            
        except Exception as e:
            logger.error(f"Error processing URLs in message: {e}")
            return None

chat_processor = ChatProcessor()
