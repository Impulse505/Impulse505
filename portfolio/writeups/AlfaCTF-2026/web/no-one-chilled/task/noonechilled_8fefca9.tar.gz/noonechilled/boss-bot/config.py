from pydantic_settings import BaseSettings
import os


class BotSettings(BaseSettings):
    database_url: str = "postgresql://intranet_user:whitebox-postgres-password@localhost:5432/intranet"
    redis_url: str = "redis://localhost:6379/0"
    api_base_url: str = "http://nginx"
    bot_username: str = "boss@company.com"
    bot_password: str = "WhiteboxBossPassword123!"
    max_concurrent_chats: int = 50
    message_processing_delay: float = 0.1 
    chat_polling_interval: int = 5  
    response_templates: list[str] = [
        "Лучше кликай, в отпуск никто не пойдет",
        "Работай больше, отдыхай меньше",
        "Кликай быстрее, время деньги",
        "Никаких отпусков, только клики",
        "Продуктивность превыше всего",
        "Кликай или уходи",
        "Время кликать, не время отдыхать",
        "Больше кликов - больше успеха",
        "Отпуск - это для слабаков",
        "Кликай до изнеможения"
    ]
    log_level: str = "INFO"
    log_format: str = "json"
    metrics_port: int = 9090
    health_check_interval: int = 30
    auth_refresh_interval: int = 300
    model_config = {
        "env_file": ".env",
        "case_sensitive": False,
    }


settings = BotSettings()
