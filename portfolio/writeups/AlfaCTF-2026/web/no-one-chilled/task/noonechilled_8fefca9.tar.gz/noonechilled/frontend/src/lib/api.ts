import { requestHandler } from './requestHandler'

interface ApiResponse<T = any> {
  data?: T
  error?: string
  status: number
}

interface ApiOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH'
  body?: any
  headers?: Record<string, string>
}

function getErrorMessage(errorData: any, fallbackStatus: number): string {
  const detail = errorData?.detail

  if (typeof detail === 'string' && detail.trim()) {
    return detail
  }

  if (Array.isArray(detail) && detail.length > 0) {
    const first = detail[0]
    if (typeof first === 'string' && first.trim()) {
      return first
    }

    if (first && typeof first === 'object') {
      const location = Array.isArray(first.loc) ? first.loc.join('.') : ''
      const message = typeof first.msg === 'string' ? first.msg : ''

      if (location && message) {
        return `${location}: ${message}`
      }

      if (message) {
        return message
      }
    }
  }

  if (typeof errorData?.error === 'string' && errorData.error.trim()) {
    return errorData.error
  }

  return `HTTP ${fallbackStatus}`
}

class ApiService {
  private baseUrl = '/xhr/api'

  private async request<T>(endpoint: string, options: ApiOptions = {}): Promise<ApiResponse<T>> {
    const {
      method = 'GET',
      body,
      headers = {},
    } = options

    const requestHeaders: Record<string, string> = {
      'Content-Type': 'application/json',
      ...headers
    }

    const requestOptions: any = {
      method,
      headers: requestHeaders,
    }

    if (body && method !== 'GET') {
      requestOptions.body = JSON.stringify(body)
    }

    try {
      const response = await requestHandler.fetch(`${this.baseUrl}${endpoint}`, requestOptions)
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ detail: 'Неизвестная ошибка' }))
        return {
          error: getErrorMessage(errorData, response.status),
          status: response.status
        }
      }

      const data = await response.json()
      return {
        data,
        status: response.status
      }
    } catch (error) {
      return {
        error: error instanceof Error ? error.message : 'Ошибка сети',
        status: 0
      }
    }
  }

  
  async login(email: string, password: string): Promise<ApiResponse<{ message: string; user: any }>> {
    return this.request('/auth/login', {
      method: 'POST',
      body: { email, password },
    })
  }

  async register(email: string, password: string, display_name: string, role: string = 'employee'): Promise<ApiResponse<{ message: string; user: any }>> {
    return this.request('/auth/register', {
      method: 'POST',
      body: { email, password, display_name, role },
    })
  }

  async refreshToken(): Promise<ApiResponse<{ message: string; user: any }>> {
    return this.request('/auth/refresh', {
      method: 'POST',
    })
  }

  async logout(): Promise<ApiResponse<void>> {
    return this.request('/auth/logout', {
      method: 'POST'
    })
  }

  async getCurrentUser(): Promise<ApiResponse<any>> {
    return this.request('/auth/me')
  }

  async getVacationApprovalCard(): Promise<ApiResponse<{ code: string; boss_name: string }>> {
    return this.request('/auth/vacation-approval')
  }

  async getWebSocketToken(): Promise<ApiResponse<{ token: string }>> {
    return this.request('/chat/ws-token')
  }

  
  async inviteUser(userData: any): Promise<ApiResponse<any>> {
    return this.request('/users/invite', {
      method: 'POST',
      body: userData
    })
  }

  async getUsers(): Promise<ApiResponse<any[]>> {
    return this.request('/users/')
  }

  async getUser(userId: string): Promise<ApiResponse<any>> {
    return this.request(`/users/${userId}`)
  }

  async updateUser(userId: string, userData: any): Promise<ApiResponse<any>> {
    return this.request(`/users/${userId}`, {
      method: 'PATCH',
      body: userData
    })
  }

  async deleteUser(userId: string): Promise<ApiResponse<any>> {
    return this.request(`/users/${userId}`, {
      method: 'DELETE'
    })
  }

  async goOnVacation(code: string): Promise<ApiResponse<any>> {
    return this.request('/users/me/vacation', {
      method: 'POST',
      body: { code }
    })
  }

  
  async getDashboardStats(): Promise<ApiResponse<any>> {
    return this.request('/dashboard/stats')
  }

  async getRecentActivity(): Promise<ApiResponse<any>> {
    return this.request('/dashboard/recent-activity')
  }

  async getLeaderboard(): Promise<ApiResponse<any>> {
    return this.request('/dashboard/leaderboard')
  }

  async recordClick(): Promise<ApiResponse<any>> {
    return this.request('/store/click', {
      method: 'POST'
    })
  }

  async getClickerStats(): Promise<ApiResponse<any>> {
    return this.request('/store/clicker-stats')
  }

  
  async getStoreItems(): Promise<ApiResponse<any[]>> {
    return this.request('/store/items')
  }

  async getStoreItem(itemId: string): Promise<ApiResponse<any>> {
    return this.request(`/store/items/${itemId}`)
  }

  async createStoreItem(itemData: any): Promise<ApiResponse<any>> {
    return this.request('/store/items', {
      method: 'POST',
      body: itemData
    })
  }

  async deleteStoreItem(itemId: string): Promise<ApiResponse<any>> {
    return this.request(`/store/items/${itemId}`, {
      method: 'DELETE'
    })
  }

  async getStoreCategories(): Promise<ApiResponse<any[]>> {
    return this.request('/store/categories')
  }

  async getClickBalance(): Promise<ApiResponse<any>> {
    return this.request('/store/balance')
  }

  async createOrder(orderData: any): Promise<ApiResponse<any>> {
    return this.request('/store/orders', {
      method: 'POST',
      body: orderData
    })
  }

  async getOrders(): Promise<ApiResponse<any[]>> {
    return this.request('/store/orders')
  }

  async getOrder(orderId: string): Promise<ApiResponse<any>> {
    return this.request(`/store/orders/${orderId}`)
  }
  
  async getAchievements(): Promise<ApiResponse<any[]>> {
    return this.request('/achievements/')
  }

  async getAchievement(achievementId: string): Promise<ApiResponse<any>> {
    return this.request(`/achievements/${achievementId}`)
  }

  async createAchievement(achievementData: any): Promise<ApiResponse<any>> {
    return this.request('/achievements/', {
      method: 'POST',
      body: achievementData
    })
  }

  async getUserAchievements(): Promise<ApiResponse<any[]>> {
    return this.request('/achievements/me/achievements')
  }

  async getUserAchievementsById(userId: string): Promise<ApiResponse<any[]>> {
    return this.request(`/achievements/user/${userId}/achievements`)
  }

  async checkAchievementProgress(): Promise<ApiResponse<any>> {
    return this.request('/achievements/check-progress', {
      method: 'POST'
    })
  }

  async getAchievementProgress(): Promise<ApiResponse<any[]>> {
    return this.request('/achievements/')
  }

  async awardAchievement(achievementId: string, userId: string): Promise<ApiResponse<any>> {
    return this.request(`/achievements/award/${achievementId}`, {
      method: 'POST',
      body: { user_id: userId }
    })
  }

  async getAchievementLeaderboard(): Promise<ApiResponse<any[]>> {
    return this.request('/achievements/leaderboard')
  }

  
  async getChatRooms(unreadOnly: boolean = false): Promise<ApiResponse<any[]>> {
    return this.request(`/chat/rooms?unread_only=${unreadOnly}`)
  }

  async getChatRoom(roomId: string): Promise<ApiResponse<any>> {
    return this.request(`/chat/rooms/${roomId}`)
  }

  async createChatRoom(roomData: any): Promise<ApiResponse<any>> {
    return this.request('/chat/rooms', {
      method: 'POST',
      body: roomData
    })
  }

  async ensureBossDm(): Promise<ApiResponse<any>> {
    return this.request('/chat/rooms/ensure-boss-dm', {
      method: 'POST'
    })
  }

  async joinChatRoom(roomId: string): Promise<ApiResponse<any>> {
    return this.request(`/chat/rooms/${roomId}/join`, {
      method: 'POST'
    })
  }

  async leaveChatRoom(roomId: string): Promise<ApiResponse<any>> {
    return this.request(`/chat/rooms/${roomId}/leave`, {
      method: 'POST'
    })
  }

  async getChatMessages(roomId: string): Promise<ApiResponse<any[]>> {
    return this.request(`/chat/rooms/${roomId}/messages`)
  }

  async sendMessage(roomId: string, message: string): Promise<ApiResponse<any>> {
    return this.request(`/chat/rooms/${roomId}/messages`, {
      method: 'POST',
      body: { body: message }
    })
  }

  async markRoomAsRead(roomId: string): Promise<ApiResponse<any>> {
    return this.request(`/chat/rooms/${roomId}/mark-read`, {
      method: 'POST'
    })
  }
}

export const apiService = new ApiService()

export type { ApiResponse, ApiOptions }
