import React, { useState, useEffect } from 'react'
import { apiService } from '../lib/api'
import {
  Box,
  Card,
  CardBody,
  VStack,
  HStack,
  Text,
  Heading,
  Button,
  Avatar,
  Badge,
  useToast,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  FormControl,
  FormLabel,
  Input,
  Select,
  useDisclosure,
  Divider,
  Stat,
  StatNumber,
  StatHelpText,
  Grid,
} from '@chakra-ui/react'
import { 
  EditIcon, 
  TimeIcon,
  StarIcon,
  CheckIcon,
} from '@chakra-ui/icons'
import { useAuth } from '../lib/auth'
import { t } from '../lib/translations'

interface UserProfile {
  id: string
  email: string
  display_name: string
  role: string
  avatar_url?: string
  timezone: string
  created_at: string
  is_active: boolean
}

interface ProfileStats {
  total_earned: number
  achievements_earned: number
}

const ProfilePage: React.FC = () => {
  const { logout } = useAuth()
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [stats, setStats] = useState<ProfileStats | null>(null)
    const [loading, setLoading] = useState(true)
  const [vacationCode, setVacationCode] = useState('')
  const { isOpen, onOpen, onClose } = useDisclosure()
  const [editForm, setEditForm] = useState({
    display_name: '',
    timezone: '',
  })
  const toast = useToast()

  useEffect(() => {
    fetchProfile()
    fetchProfileStats()
  }, [])

  const fetchProfile = async () => {
    try {
      const response = await apiService.getCurrentUser()
      
      if (response.data) {
        setProfile(response.data)
        setEditForm({
          display_name: response.data.display_name,
          timezone: response.data.timezone,
        })
      } else if (response.error) {
        toast({
          title: t('common', 'error'),
          description: response.error,
          status: 'error',
          duration: 3000,
        })
      }
    } catch (error) {
      toast({
        title: t('common', 'error'),
        description: t('profile', 'failedToLoadProfile'),
        status: 'error',
        duration: 3000,
      })
    } finally {
      setLoading(false)
    }
  }

  const fetchProfileStats = async () => {
    try {
      const response = await apiService.getDashboardStats()
      
      if (response.data) {
        setStats({
          total_earned: response.data.clicks.total_earned,
          achievements_earned: response.data.achievements.earned,
        })
      }
    } catch (error) {
      console.error('Failed to fetch profile stats:', error)
    }
  }

  const handleEditProfile = () => {
    onOpen()
  }

  const handleSaveProfile = async () => {
    try {
      const response = await apiService.updateUser(profile?.id || '', editForm)

      if (response.data) {
        setProfile(response.data)
        onClose()
        toast({
          title: t('common', 'success'),
          description: t('profile', 'profileUpdatedSuccessfully'),
          status: 'success',
          duration: 3000,
        })
      } else if (response.error) {
        throw new Error(response.error)
      }
    } catch (error) {
      toast({
        title: t('common', 'error'),
        description: error instanceof Error ? error.message : t('profile', 'failedToUpdateProfile'),
        status: 'error',
        duration: 3000,
      })
    }
  }

  const handleLogout = () => {
    logout()
  }

  const handleVacation = async () => {
    try {
      if (!vacationCode.trim()) {
        toast({
          title: t('common', 'error'),
          description: t('profile', 'vacationCodeRequired') || 'Введите код',
          status: 'error',
          duration: 3000,
        })
        return
      }

      const response = await apiService.goOnVacation(vacationCode.trim())
      if (response.data) {
        let description = response.data.message || t('profile', 'accountDeactivated') || 'Аккаунт деактивирован. Приятного отпуска!'
        
        if (response.data.data.flag) {
          description += `\n\n🏁 Флаг: ${response.data.data.flag}`
        }
        
        toast({
          title: t('common', 'success'),
          description: description,
          status: 'success',
          duration: 10000,
          isClosable: true,
        })
        setTimeout(() => {
          logout()
        }, 10000)
        
      } else if (response.error) {
        throw new Error(response.error)
      }
    } catch (error) {
      toast({
        title: t('common', 'error'),
        description: error instanceof Error ? error.message : t('profile', 'vacationFailed') || 'Не удалось подтвердить код',
        status: 'error',
        duration: 3000,
      })
    }
  }

  if (loading) {
    return (
      <Box textAlign="center" py={20}>
        <Text color="gray.400">{t('profile', 'loadingProfile')}</Text>
      </Box>
    )
  }

  if (!profile) {
    return (
      <Box textAlign="center" py={20}>
        <Text color="gray.400">{t('profile', 'failedToLoadProfile')}</Text>
      </Box>
    )
  }

  return (
    <Box>
      <VStack spacing={6} align="stretch" mb={8}>
        <Box>
          <Heading size="lg" color="white" mb={2}>
            {t('profile', 'title')}
          </Heading>
          <Text color="gray.400">
            {t('profile', 'description')}
          </Text>
        </Box>
      </VStack>

      <Grid templateColumns={{ base: '1fr', lg: '2fr 1fr' }} gap={8}>
        {/* Profile Information */}
        <VStack spacing={6} align="stretch">
          <Card bg="crypto.light" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
            <CardBody p={6}>
              <VStack spacing={6} align="stretch">
                {/* Profile Header */}
                <HStack spacing={4}>
                  <Avatar
                    size="xl"
                    name={profile.display_name}
                    src={profile.avatar_url}
                    bg="crypto.primary"
                  />
                  <VStack align="start" spacing={2} flex={1}>
                    <Heading size="lg" color="white">{profile.display_name}</Heading>
                    <Text color="gray.400">{profile.email}</Text>
                    <HStack>
                                          <Badge colorScheme={profile.role === 'boss' ? 'purple' : 'blue'} variant="subtle">
                      {profile.role === 'boss' ? t('roles', 'boss') : t('roles', 'employee')}
                    </Badge>
                    <Badge colorScheme={profile.is_active ? 'green' : 'red'} variant="subtle">
                      {profile.is_active ? t('profile', 'active') : t('profile', 'inactive')}
                    </Badge>
                    </HStack>
                  </VStack>
                  <Button
                    leftIcon={<EditIcon />}
                    colorScheme="blue"
                    variant="outline"
                    onClick={handleEditProfile}
                  >
                    {t('common', 'edit')}
                  </Button>
                </HStack>

                <Divider borderColor="crypto.lighter" />

                {/* Profile Details */}
                <Grid templateColumns={{ base: '1fr', md: 'repeat(2, 1fr)' }} gap={4}>
                  <VStack align="start" spacing={2}>
                    <Text color="gray.400" fontSize="sm">{t('profile', 'displayName')}</Text>
                    <Text color="white" fontWeight="medium">{profile.display_name}</Text>
                  </VStack>
                  
                  <VStack align="start" spacing={2}>
                    <Text color="gray.400" fontSize="sm">{t('auth', 'email')}</Text>
                    <Text color="white" fontWeight="medium">{profile.email}</Text>
                  </VStack>
                  
                  <VStack align="start" spacing={2}>
                    <Text color="gray.400" fontSize="sm">{t('profile', 'role')}</Text>
                    <Text color="white" fontWeight="medium">
                      {profile.role === 'boss' ? t('roles', 'boss') : t('roles', 'employee')}
                    </Text>
                  </VStack>
                  
                  <VStack align="start" spacing={2}>
                    <Text color="gray.400" fontSize="sm">{t('profile', 'timezone')}</Text>
                    <Text color="white" fontWeight="medium">{profile.timezone}</Text>
                  </VStack>
                  
                  <VStack align="start" spacing={2}>
                    <Text color="gray.400" fontSize="sm">{t('profile', 'memberSince')}</Text>
                    <Text color="white" fontWeight="medium">
                      {new Date(profile.created_at).toLocaleDateString()}
                    </Text>
                  </VStack>
                  
                  <VStack align="start" spacing={2}>
                    <Text color="gray.400" fontSize="sm">{t('profile', 'status')}</Text>
                    <Text color={profile.is_active ? "crypto.success" : "crypto.error"} fontWeight="medium">
                      {profile.is_active ? t('profile', 'active') : t('profile', 'inactive')}
                    </Text>
                  </VStack>
                </Grid>
              </VStack>
            </CardBody>
          </Card>

          {/* Statistics */}
          <Card bg="crypto.light" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
            <CardBody p={6}>
              <VStack spacing={6} align="stretch">
                <Heading size="md" color="white">{t('profile', 'yourStatistics')}</Heading>
                
                <Grid templateColumns={{ base: '1fr', md: 'repeat(2, 1fr)' }} gap={6}>
                  <Stat>
                    <StatNumber color="crypto.primary" fontSize="2xl">
                      {stats?.total_earned?.toLocaleString() || 0}
                    </StatNumber>
                    <StatHelpText color="gray.400">{t('profile', 'totalClicksEarned')}</StatHelpText>
                  </Stat>
                  
                  <Stat>
                    <StatNumber color="crypto.success" fontSize="2xl">
                      {stats?.achievements_earned || 0}
                    </StatNumber>
                    <StatHelpText color="gray.400">{t('profile', 'achievementsUnlocked')}</StatHelpText>
                  </Stat>
                  
                  <Stat>
                    <StatNumber color="crypto.accent" fontSize="2xl">
                      {stats?.total_earned?.toLocaleString() || 0}
                    </StatNumber>
                    <StatHelpText color="gray.400">{t('profile', 'currentBalance')}</StatHelpText>
                  </Stat>
                  
                  <Stat>
                    <StatNumber color="crypto.secondary" fontSize="2xl">
                      {stats?.achievements_earned || 0}
                    </StatNumber>
                    <StatHelpText color="gray.400">{t('profile', 'storeOrders')}</StatHelpText>
                  </Stat>
                </Grid>
              </VStack>
            </CardBody>
          </Card>
        </VStack>

        {/* Sidebar */}
        <VStack spacing={6} align="stretch">
          {/* Quick Actions */}
          <Card bg="crypto.light" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
            <CardBody p={6}>
              <VStack spacing={4} align="stretch">
                                <Heading size="md" color="white">{t('profile', 'quickActions')}</Heading>
                
                <Button
                  leftIcon={<StarIcon />}
                  colorScheme="yellow"
                  variant="outline"
                  onClick={() => window.location.href = '/achievements'}
                >
                  {t('profile', 'viewAchievements')}
                </Button>
                
                <Button
                  leftIcon={<TimeIcon />}
                  colorScheme="green"
                  variant="outline"
                  onClick={() => window.location.href = '/store'}
                >
                  {t('profile', 'visitStore')}
                </Button>
              </VStack>
            </CardBody>
          </Card>

          {/* Account Actions */}
          <Card bg="crypto.light" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
            <CardBody p={6}>
              <VStack spacing={4} align="stretch">
                <Heading size="md" color="white">{t('profile', 'account')}</Heading>

                <FormControl>
                  <FormLabel color="gray.300">{t('profile', 'vacationCode') || 'Код от начальника'}</FormLabel>
                  <Input
                    value={vacationCode}
                    onChange={(e) => setVacationCode(e.target.value)}
                    placeholder={t('profile', 'vacationCodePlaceholder') || 'Введите код'}
                    bg="crypto.darker"
                    borderColor="crypto.lighter"
                    color="white"
                  />
                </FormControl>
                <Button
                  colorScheme="red"
                  onClick={handleVacation}
                >
                  {t('profile', 'goOnVacationAndDelete') || 'Пойти в отпуск и удалить аккаунт'}
                </Button>
                
                <Button
                  leftIcon={<EditIcon />}
                  colorScheme="blue"
                  variant="outline"
                  onClick={handleEditProfile}
                >
                  {t('profile', 'editProfile')}
                </Button>
                
                <Button
                  colorScheme="red"
                  variant="outline"
                  onClick={handleLogout}
                >
                  {t('auth', 'logout')}
                </Button>
              </VStack>
            </CardBody>
          </Card>
        </VStack>
      </Grid>

      {/* Edit Profile Modal */}
      <Modal isOpen={isOpen} onClose={onClose}>
        <ModalOverlay />
        <ModalContent bg="crypto.light" border="1px solid" borderColor="crypto.lighter">
          <ModalHeader color="white">{t('profile', 'editProfileTitle')}</ModalHeader>
          <ModalCloseButton color="gray.400" />
          <ModalBody pb={6}>
            <VStack spacing={4} align="stretch">
              <FormControl>
                <FormLabel color="gray.300">{t('profile', 'displayName')}</FormLabel>
                <Input
                  value={editForm.display_name}
                  onChange={(e) => setEditForm(prev => ({ ...prev, display_name: e.target.value }))}
                  bg="crypto.darker"
                  borderColor="crypto.lighter"
                  color="white"
                  _placeholder={{ color: 'gray.400' }}
                />
              </FormControl>

              <FormControl>
                <FormLabel color="gray.300">{t('profile', 'timezone')}</FormLabel>
                <Select
                  value={editForm.timezone}
                  onChange={(e) => setEditForm(prev => ({ ...prev, timezone: e.target.value }))}
                  bg="crypto.darker"
                  borderColor="crypto.lighter"
                  color="white"
                >
                  <option value="UTC">{t('timezones', 'UTC')}</option>
                  <option value="America/New_York">{t('timezones', 'America/New_York')}</option>
                  <option value="America/Chicago">{t('timezones', 'America/Chicago')}</option>
                  <option value="America/Denver">{t('timezones', 'America/Denver')}</option>
                  <option value="America/Los_Angeles">{t('timezones', 'America/Los_Angeles')}</option>
                  <option value="Europe/London">{t('timezones', 'Europe/London')}</option>
                  <option value="Europe/Paris">{t('timezones', 'Europe/Paris')}</option>
                  <option value="Asia/Tokyo">{t('timezones', 'Asia/Tokyo')}</option>
                </Select>
              </FormControl>

              <HStack spacing={3} pt={4}>
                <Button
                  flex={1}
                  colorScheme="green"
                  onClick={handleSaveProfile}
                  leftIcon={<CheckIcon />}
                >
                  {t('profile', 'saveChanges')}
                </Button>
                <Button
                  flex={1}
                  variant="outline"
                  onClick={onClose}
                >
                  {t('common', 'cancel')}
                </Button>
              </HStack>
            </VStack>
          </ModalBody>
        </ModalContent>
      </Modal>
    </Box>
  )
}

export default ProfilePage
