import React, { useState, useEffect, useRef, useCallback } from 'react'
import {
  Box,
  VStack,
  HStack,
  Text,
  Input,
  Button,
  List,
  ListItem,
  Heading,
  useToast,
  Flex,
  Badge,
  Spinner
} from '@chakra-ui/react'
import { useAuth } from '../lib/auth'
import { apiService } from '../lib/api'
import { useWebSocket } from '../hooks/useWebSocket'
import { t } from '../lib/translations'
import { detectStaticUrls } from '../lib/staticPreview'
import StaticPreviewComponent from '../components/StaticPreview'

interface ChatRoom {
  id: string
  kind: string
  title: string
  created_by: string
  created_at: string
  is_active: boolean
  unread_count?: number
}

interface Message {
  id: string
  room_id: string
  sender_id: string
  body: string
  created_at: string
  sender?: {
    display_name: string
    email: string
  }
  attachments?: {
    attachments: {
      type: string
      url: string
      filename: string
      extension: string
    }[]
  }
}

const ChatPage: React.FC = () => {
  const { user } = useAuth()
  const toast = useToast()
  const [rooms, setRooms] = useState<ChatRoom[]>([])
  const [selectedRoom, setSelectedRoom] = useState<ChatRoom | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [loading, setLoading] = useState(false)
  const [sending, setSending] = useState(false)
  const [typingUsers, setTypingUsers] = useState<Set<string>>(new Set())
  const [showUnreadOnly, setShowUnreadOnly] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const loadChatRooms = useCallback(async () => {
    setLoading(true)
    try {
      const response = await apiService.getChatRooms(showUnreadOnly)
      if (response.data) {
        setRooms(response.data)
        
        if (response.data.length > 0 && user?.role === 'employee') {
          setSelectedRoom(response.data[0])
        }
      } else {
        toast({
          title: t('chat', 'errorLoadingChatRooms'),
          description: t('chat', 'failedToLoadChatRooms'),
          status: 'error'
        })
      }
    } catch (error) {
      toast({
        title: t('common', 'error'),
        description: t('chat', 'failedToLoadChatRooms'),
        status: 'error'
      })
    } finally {
      setLoading(false)
    }
  }, [user?.role, toast, showUnreadOnly])

  const loadMessages = useCallback(async (roomId: string) => {
    try {
      const response = await apiService.getChatMessages(roomId)
      if (response.data) {
        setMessages(response.data)
        
        await apiService.markRoomAsRead(roomId)
        
        setRooms(prev => prev.map(room => 
          room.id === roomId ? { ...room, unread_count: 0 } : room
        ))
      } else {
        toast({
          title: t('chat', 'errorLoadingMessages'),
          description: t('chat', 'failedToLoadMessages'),
          status: 'error'
        })
      }
    } catch (error) {
      toast({
        title: t('common', 'error'),
        description: t('chat', 'failedToLoadMessages'),
        status: 'error'
      })
    }
  }, [toast])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    loadChatRooms()
  }, [loadChatRooms])

  useEffect(() => {
    if (selectedRoom) {
      loadMessages(selectedRoom.id)
    }
  }, [selectedRoom, loadMessages])

  
  const handleNewMessage = useCallback((message: Message) => {
    setMessages(prev => [...prev, message])
    
    
    if (message.sender_id !== user?.id) {
      setRooms(prev => prev.map(room => 
        room.id === message.room_id 
          ? { ...room, unread_count: (room.unread_count || 0) + 1 }
          : room
      ))
    }
  }, [user?.id])

  const handleTyping = useCallback((userId: string, isTyping: boolean) => {
    setTypingUsers(prev => {
      const newSet = new Set(prev)
      if (isTyping) {
        newSet.add(userId)
      } else {
        newSet.delete(userId)
      }
      return newSet
    })
  }, [])

  const handleWebSocketConnect = useCallback(() => {
    console.log('WebSocket connected for room:', selectedRoom?.id)
  }, [selectedRoom?.id])

  const handleWebSocketDisconnect = useCallback(() => {
    console.log('WebSocket disconnected for room:', selectedRoom?.id)
  }, [selectedRoom?.id])

  const handleToggleUnreadOnly = useCallback(() => {
    setShowUnreadOnly(prev => !prev)
  }, [])

  
  const { isConnected, isConnecting, sendMessage, sendTyping } = useWebSocket({
    roomId: selectedRoom?.id || '',
    onMessage: handleNewMessage,
    onTyping: handleTyping,
    onConnect: handleWebSocketConnect,
    onDisconnect: handleWebSocketDisconnect
  })

  const ensureBossDm = async () => {
    if (user?.role !== 'employee') return
    
    try {
      const response = await apiService.ensureBossDm()
      if (response.data) {
        await loadChatRooms()
        toast({
          title: t('common', 'success'),
          description: t('chat', 'chatWithBossCreated'),
          status: 'success'
        })
      }
    } catch (error) {
      toast({
        title: t('common', 'error'),
        description: t('chat', 'failedToCreateChatWithBoss'),
        status: 'error'
      })
    }
  }

  const handleSendMessage = async () => {
    if (!selectedRoom || !newMessage.trim() || !isConnected) return

    setSending(true)
    try {
      
      sendMessage(newMessage.trim())
      setNewMessage('')
      
      
      sendTyping(false)
      
      toast({
        title: t('common', 'success'),
        description: t('chat', 'messageSentSuccessfully'),
        status: 'success'
      })
    } catch (error) {
      toast({
        title: t('common', 'error'),
        description: t('chat', 'failedToSendMessage'),
        status: 'error'
      })
    } finally {
      setSending(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setNewMessage(value)
    
    
    if (isConnected) {
      sendTyping(true)
      
      
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current)
      }
      
      
      typingTimeoutRef.current = setTimeout(() => {
        sendTyping(false)
      }, 2000)
    }
  }

  if (loading) {
    return (
      <Flex justify="center" align="center" h="400px">
        <Spinner size="xl" />
      </Flex>
    )
  }

  return (
    <Box h="calc(100vh - 200px)" display="flex">
      {/* Sidebar with chat rooms */}
      <Box w="300px" borderRight="1px" borderColor="gray.200" p={4}>
        <VStack spacing={4} align="stretch">
          <HStack justify="space-between" align="center">
            <Heading size="md">{t('chat', 'chatRooms')}</Heading>
            <Button
              size="sm"
              variant={showUnreadOnly ? "solid" : "outline"}
              colorScheme="blue"
              onClick={handleToggleUnreadOnly}
            >
              {showUnreadOnly ? t('chat', 'showAll') : t('chat', 'unreadOnly')}
            </Button>
          </HStack>
          
          {user?.role === 'employee' && rooms.length === 0 && (
            <Button onClick={ensureBossDm} colorScheme="blue">
              {t('chat', 'startChatWithBoss')}
            </Button>
          )}
          
          <List spacing={2}>
            {rooms.map((room) => (
              <ListItem
                key={room.id}
                p={3}
                bg={selectedRoom?.id === room.id ? 'blue.600' : 'transparent'}
                borderRadius="md"
                cursor="pointer"
                _hover={{ bg: 'gray.600' }}
                onClick={() => {
                  setSelectedRoom(room)
                  
                  setRooms(prev => prev.map(r => 
                    r.id === room.id ? { ...r, unread_count: 0 } : r
                  ))
                }}
              >
                <VStack align="start" spacing={1}>
                  <HStack justify="space-between" w="full">
                    <HStack>
                      <Badge colorScheme={room.kind === 'global' ? 'green' : 'blue'}>
                        {room.kind === 'global' ? t('chat', 'global') : t('chat', 'dm')}
                      </Badge>
                      <Text fontWeight="bold" fontSize="sm">
                        {room.title}
                      </Text>
                    </HStack>
                    {room.unread_count && room.unread_count > 0 && (
                      <Badge colorScheme="red" borderRadius="full">
                        {room.unread_count}
                      </Badge>
                    )}
                  </HStack>
                </VStack>
              </ListItem>
            ))}
          </List>
        </VStack>
      </Box>

      {/* Chat area */}
      <Box flex={1} display="flex" flexDirection="column">
        {selectedRoom ? (
          <>
            {/* Chat header */}
            <Box p={4} borderBottom="1px" borderColor="gray.200">
              <HStack justify="space-between">
                <HStack>
                  <Badge colorScheme={selectedRoom.kind === 'global' ? 'green' : 'blue'}>
                    {selectedRoom.kind === 'global' ? t('chat', 'global') : t('chat', 'dm')}
                  </Badge>
                  <Heading size="md">{selectedRoom.title}</Heading>
                </HStack>
                <HStack spacing={2}>
                  {isConnecting && <Spinner size="sm" />}
                  <Badge 
                    colorScheme={isConnected ? 'green' : 'red'} 
                    variant="subtle"
                  >
                    {isConnected ? t('chat', 'connected') : t('chat', 'disconnected')}
                  </Badge>
                </HStack>
              </HStack>
            </Box>

            {/* Messages */}
            <Box flex={1} p={4} overflowY="auto">
              <VStack spacing={3} align="stretch">
                {messages.map((message) => {
                  const staticPreviews = detectStaticUrls(message.body)
                  const isOwnMessage = message.sender_id === user?.id
                  
                  return (
                    <Box
                      key={message.id}
                      alignSelf={isOwnMessage ? 'flex-end' : 'flex-start'}
                      maxW="70%"
                    >
                      <Box
                        bg={isOwnMessage ? 'blue.500' : 'gray.100'}
                        color={isOwnMessage ? 'white' : 'black'}
                        p={3}
                        borderRadius="lg"
                      >
                        <VStack align="start" spacing={1}>
                          <Text fontSize="xs" opacity={0.8}>
                            {message.sender?.display_name || t('chat', 'unknown')}
                          </Text>
                          <Text>{message.body}</Text>
                          <Text fontSize="xs" opacity={0.7}>
                            {new Date(message.created_at).toLocaleTimeString()}
                          </Text>
                        </VStack>
                      </Box>
                      
                      {staticPreviews.map((preview, index) => (
                        <StaticPreviewComponent
                          key={`${message.id}-preview-${index}`}
                          preview={preview}
                          isOwnMessage={isOwnMessage}
                        />
                      ))}
                      
                      {message.attachments?.attachments?.map((attachment: any, index: number) => (
                        <StaticPreviewComponent
                          key={`${message.id}-attachment-${index}`}
                          preview={{
                            type: attachment.type === 'image' ? 'image' : 'other',
                            url: attachment.url,
                            filename: attachment.filename,
                            extension: attachment.extension
                          }}
                          isOwnMessage={isOwnMessage}
                        />
                      ))}
                    </Box>
                  )
                })}
                
                {/* Typing indicators */}
                {typingUsers.size > 0 && (
                  <Box alignSelf="flex-start" maxW="70%">
                    <Box bg="gray.100" p={2} borderRadius="lg">
                      <Text fontSize="sm" color="gray.600">
                        {Array.from(typingUsers).map(userId => {
                          const user = messages.find(m => m.sender_id === userId)?.sender?.display_name || t('chat', 'someone')
                          return user
                        }).join(', ')} {typingUsers.size === 1 ? t('chat', 'isTyping') : t('chat', 'areTyping')}
                      </Text>
                    </Box>
                  </Box>
                )}
                
                <div ref={messagesEndRef} />
              </VStack>
            </Box>

            {/* Message input */}
            <Box p={4} borderTop="1px" borderColor="gray.200">
              <HStack>
                <Input
                  value={newMessage}
                  onChange={handleInputChange}
                  onKeyPress={handleKeyPress}
                  placeholder={isConnected ? t('chat', 'typeYourMessage') : t('chat', 'connecting')}
                  disabled={sending || !isConnected}
                />
                <Button
                  onClick={handleSendMessage}
                  colorScheme="blue"
                  disabled={!newMessage.trim() || sending || !isConnected}
                  isLoading={sending}
                >
                  {t('chat', 'send')}
                </Button>
              </HStack>
            </Box>
          </>
        ) : (
          <Flex justify="center" align="center" h="full">
            <Text color="gray.500">{t('chat', 'selectChatRoom')}</Text>
          </Flex>
        )}
      </Box>
    </Box>
  )
}

export default ChatPage
