import React from 'react'
import { Box, Button, Heading, Text, VStack } from '@chakra-ui/react'
import { t } from '../lib/translations'
import { useNavigate } from 'react-router-dom'

const AdminPage: React.FC = () => {
  const navigate = useNavigate()

  return (
    <VStack spacing={6} align="stretch">
      <Heading>{t('admin', 'title')}</Heading>
      <Text>{t('admin', 'description')}</Text>
      <Box p={4} border="1px" borderColor="gray.200" borderRadius="md">
        <VStack align="start" spacing={3}>
          <Text>{t('admin', 'adminControls')}</Text>
          <Text fontSize="sm" color="gray.600">{t('admin', 'vacationApprovalDescription')}</Text>
          <Button
            variant="outline"
            colorScheme="blue"
            onClick={() => navigate('/admin/vacation-approval')}
          >
            {t('admin', 'openVacationApproval')}
          </Button>
        </VStack>
      </Box>
    </VStack>
  )
}

export default AdminPage
