import { useEffect, useRef, useCallback, useState } from 'react'
import { useAuth } from '../lib/auth'
import { apiService } from '../lib/api'

interface WebSocketMessage {
  type: string
  message?: any
  user_id?: string
  is_typing?: boolean
}

interface UseWebSocketOptions {
  roomId: string
  onMessage?: (message: any) => void
  onTyping?: (userId: string, isTyping: boolean) => void
  onConnect?: () => void
  onDisconnect?: () => void
}

export const useWebSocket = ({
  roomId,
  onMessage,
  onTyping,
  onConnect,
  onDisconnect
}: UseWebSocketOptions) => {
  const { user } = useAuth()
  const wsRef = useRef<WebSocket | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [isConnecting, setIsConnecting] = useState(false)
  const reconnectTimeoutRef = useRef<number | null>(null)
  const currentRoomIdRef = useRef<string>('')

  
  const stableOnMessage = useCallback(onMessage || (() => {}), [])
  const stableOnTyping = useCallback(onTyping || (() => {}), [])
  const stableOnConnect = useCallback(onConnect || (() => {}), [])
  const stableOnDisconnect = useCallback(onDisconnect || (() => {}), [])

  const connect = useCallback(async () => {
    
    if (wsRef.current?.readyState === WebSocket.CONNECTING || 
        wsRef.current?.readyState === WebSocket.OPEN) {
      return
    }

    if (!user || !roomId) {
      console.log('Cannot connect: missing user or roomId')
      return
    }

    let token: string
    try {
      const response = await apiService.getWebSocketToken()
      if (response.error || !response.data?.token) {
        console.log('Cannot connect: failed to get WebSocket token')
        return
      }
      token = response.data.token
    } catch (error) {
      console.log('Cannot connect: failed to get WebSocket token', error)
      return
    }

    
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current)
      reconnectTimeoutRef.current = null
    }

    setIsConnecting(true)
    
    
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
    const host = window.location.host
    const wsUrl = `${protocol}//${host}/ws/api/chat/ws/${roomId}?token=${token}`

    console.log('Connecting to WebSocket:', wsUrl)

    const ws = new WebSocket(wsUrl)
    wsRef.current = ws
    currentRoomIdRef.current = roomId

    ws.onopen = () => {
      console.log('✅ WebSocket connected to room:', roomId)
      setIsConnected(true)
      setIsConnecting(false)
      stableOnConnect()
    }

    ws.onmessage = (event) => {
      try {
        const data: WebSocketMessage = JSON.parse(event.data)
        
        switch (data.type) {
          case 'new_message':
            stableOnMessage(data.message)
            break
          case 'typing':
            stableOnTyping(data.user_id!, data.is_typing!)
            break
          case 'pong':
            
            break
          default:
            console.log('Unknown WebSocket message type:', data.type)
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error)
      }
    }

    ws.onclose = (event) => {
      console.log('❌ WebSocket disconnected from room:', roomId, 'Code:', event.code, 'Reason:', event.reason)
      setIsConnected(false)
      setIsConnecting(false)
      stableOnDisconnect()
      
      
      if (event.code !== 1000 && currentRoomIdRef.current === roomId) {
        console.log('🔄 Scheduling reconnect in 3 seconds...')
        reconnectTimeoutRef.current = window.setTimeout(() => {
          connect().catch(console.error)
        }, 3000)
      }
    }

    ws.onerror = (error) => {
      console.error('💥 WebSocket error for room:', roomId, error)
      setIsConnecting(false)
    }
  }, [roomId, user, stableOnMessage, stableOnTyping, stableOnConnect, stableOnDisconnect])

  const disconnect = useCallback(() => {
    console.log('Manually disconnecting WebSocket from room:', roomId)
    
    
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current)
      reconnectTimeoutRef.current = null
    }

    if (wsRef.current) {
      wsRef.current.close(1000, 'Manual disconnect')
      wsRef.current = null
    }
    setIsConnected(false)
    setIsConnecting(false)
  }, [roomId])

  const sendMessage = useCallback((body: string, attachments?: any) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'message',
        body,
        attachments
      }))
    } else {
      console.warn('Cannot send message: WebSocket not connected')
    }
  }, [])

  const sendTyping = useCallback((isTyping: boolean) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'typing',
        is_typing: isTyping
      }))
    }
  }, [])

  const sendPing = useCallback(() => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'ping'
      }))
    }
  }, [])

  
  useEffect(() => {
    
    if (currentRoomIdRef.current && currentRoomIdRef.current !== roomId) {
      disconnect()
    }
    
    
    if (roomId) {
      const timeoutId = setTimeout(() => {
        connect().catch(console.error)
      }, 100)
      
      return () => {
        clearTimeout(timeoutId)
        disconnect()
      }
    }
    
    return () => {
      disconnect()
    }
  }, [roomId, connect, disconnect])

  
  useEffect(() => {
    if (!isConnected) return

    const interval = setInterval(() => {
      sendPing()
    }, 30000)

    return () => clearInterval(interval)
  }, [isConnected, sendPing])

  return {
    isConnected,
    isConnecting,
    sendMessage,
    sendTyping,
    disconnect
  }
}
