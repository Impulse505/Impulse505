from typing import List
from pydantic_settings import BaseSettings
from pydantic import validator


class Settings(BaseSettings):
    database_url: str = "postgresql://intranet_user:whitebox-postgres-password@localhost:5432/intranet"
    secret_key: str = "whitebox-secret-key"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7
    cors_origins: str = "http://localhost:3000,http://127.0.0.1:3000"
    redis_url: str = "redis://localhost:6379/0"
    log_level: str = "INFO"
    log_format: str = "json"
    rate_limit_requests: int = 100
    rate_limit_window: int = 60
    max_daily_clicks: int = 10000
    max_weekly_clicks: int = 50000
    min_click_increment: int = 1
    max_click_increment: int = 100
    max_file_size: int = 10485760  
    allowed_file_types: str = "image/jpeg,image/png,image/gif,application/pdf"
    debug: bool = True
    reload: bool = True
    model_config = {
        "env_file": ".env",
        "case_sensitive": False,
    }

settings = Settings()
