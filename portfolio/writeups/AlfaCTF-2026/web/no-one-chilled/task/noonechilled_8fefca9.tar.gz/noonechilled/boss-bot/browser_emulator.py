import aiohttp
import asyncio
import re
import time
from typing import List, Dict, Any, Optional
from urllib.parse import urlparse, urljoin
from loguru import logger
from config import settings


class BrowserEmulator:
    def __init__(self):
        self.session: Optional[aiohttp.ClientSession] = None
        self.user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        self.headers = {
            'User-Agent': self.user_agent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
        
    async def initialize(self, session: aiohttp.ClientSession = None):
        if session:
            self.session = session
            logger.info("Browser emulator initialized with shared session")
        else:
            timeout = aiohttp.ClientTimeout(total=30, connect=10)
            self.session = aiohttp.ClientSession(
                timeout=timeout,
                headers=self.headers,
                connector=aiohttp.TCPConnector(limit=100, limit_per_host=20)
            )
            logger.info("Browser emulator initialized with new session")
    
    async def close(self):
        if self.session:
            await self.session.close()
            logger.info("Browser emulator closed")
    
    def detect_static_urls(self, message: str) -> List[Dict[str, Any]]:
        static_urls = []
        
        url_pattern = r'https?://[^\s]+'
        urls = re.findall(url_pattern, message)
        
        for url in urls:
            try:
                parsed = urlparse(url)
                pathname = parsed.path
                filename = pathname.split('/')[-1] if pathname else ''
                extension = filename.split('.')[-1].lower() if '.' in filename else ''

                file_type = self._get_file_type(extension)
                if file_type != 'image':
                    continue

                static_urls.append({
                    'url': url,
                    'filename': filename,
                    'extension': extension,
                    'type': file_type
                })
                logger.info(f"Found: {url}")
            except Exception as e:
                logger.error(f"Error parsing URL {url}: {e}")
        
        return static_urls
    
    def _get_file_type(self, extension: str) -> str:
        image_extensions = ['png', 'jpg', 'jpeg', 'gif', 'svg', 'ico', 'webp']
        
        if extension in image_extensions:
            return 'image'
        else:
            return 'other'
    
    async def generate_preview(self, static_url: Dict[str, Any]) -> Optional[str]:
        try:
            url = static_url['url']
            file_type = static_url['type']
            
            headers = self.headers.copy()
            if file_type == 'image':
                headers['Accept'] = 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8'

            parsed = urlparse(url)
            if not parsed.hostname:
                logger.info(f"Invalid URL (no hostname): {url}")
                return None

            logger.info(f"Request: {url}")
            try:
                async with self.session.get(url, headers=headers, allow_redirects=False) as response:
                    if response.status == 200:
                        content_type = response.headers.get('Content-Type', '')
                        if file_type == 'image' and not content_type.startswith('image/'):
                            logger.warning(f"Content-type mismatch for {url}: expected image, got {content_type}")
                        logger.info(f"File accessible: {url} (Status: {response.status})")
                    elif response.status == 403:
                        logger.warning(f"File forbidden (403): {url}")
                        return None
                    elif response.status == 404:
                        logger.warning(f"File not found (404): {url}")
                        return None
                    else:
                        logger.warning(f"File not accessible: {url} (Status: {response.status})")
                        return None
            except Exception as e:
                logger.error(f"HTTP request failed for {url}: {e}")
                return None
            
            if file_type == 'image':
                logger.info(f"Image: {url}")
                return url
            
            else:
                return f"File: {static_url['filename']}"
                        
        except Exception as e:
            logger.error(f"Error generating preview for {static_url['url']}: {e}")
            return None
    
browser_emulator = BrowserEmulator()
