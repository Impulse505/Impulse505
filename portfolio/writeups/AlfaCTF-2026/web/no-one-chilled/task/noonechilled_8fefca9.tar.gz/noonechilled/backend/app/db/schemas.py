from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, EmailStr, UUID4
from enum import Enum


class UserBase(BaseModel):
    email: EmailStr
    display_name: str
    role: str
    avatar_url: Optional[str] = None
    timezone: str = "UTC"


class UserCreate(UserBase):
    password: str


class UserInvite(BaseModel):
    email: EmailStr
    display_name: str
    role: str = "employee"


class UserUpdate(BaseModel):
    display_name: Optional[str] = None
    avatar_url: Optional[str] = None
    timezone: Optional[str] = None


class UserResponse(UserBase):
    id: UUID4
    created_at: datetime
    is_active: bool

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    user_id: Optional[str] = None


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    display_name: str
    role: str = "employee"


class RefreshRequest(BaseModel):
    refresh_token: str


class VacationRequest(BaseModel):
    code: str


class ClickLedgerBase(BaseModel):
    delta: int
    reason: str


class ClickLedgerResponse(ClickLedgerBase):
    id: UUID4
    user_id: UUID4
    created_at: datetime
    balance_after: int
    related_task_id: Optional[UUID4] = None

    class Config:
        from_attributes = True


class AchievementBase(BaseModel):
    code: str
    name: str
    description: Optional[str] = None
    criteria: Optional[dict] = None
    icon_url: Optional[str] = None
    points: int = 0


class AchievementCreate(AchievementBase):
    pass


class AchievementResponse(AchievementBase):
    id: UUID4

    class Config:
        from_attributes = True


class UserAchievementResponse(BaseModel):
    user_id: UUID4
    achievement_id: UUID4
    awarded_at: datetime
    evidence: Optional[dict] = None
    achievement: AchievementResponse

    class Config:
        from_attributes = True


class ChatRoomBase(BaseModel):
    kind: str
    title: str


class ChatRoomCreate(ChatRoomBase):
    pass


class ChatRoomResponse(ChatRoomBase):
    id: UUID4
    created_by: UUID4
    created_at: datetime
    is_active: bool
    unread_count: Optional[int] = 0

    class Config:
        from_attributes = True


class MessageBase(BaseModel):
    body: str
    attachments: Optional[dict] = None


class MessageCreate(MessageBase):
    pass


class MessageResponse(MessageBase):
    id: UUID4
    room_id: UUID4
    sender_id: UUID4
    created_at: datetime
    edited_at: Optional[datetime] = None
    deleted_at: Optional[datetime] = None
    sender: Optional[dict] = None  

    class Config:
        from_attributes = True


class MerchItemBase(BaseModel):
    sku: str
    name: str
    description: Optional[str] = None
    price_clicks: int
    inventory: int = 0
    category: Optional[str] = None


class MerchItemCreate(MerchItemBase):
    product_image: Optional[str] = None


class MerchItemUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    price_clicks: Optional[int] = None
    product_image: Optional[str] = None
    inventory: Optional[int] = None
    active: Optional[bool] = None
    category: Optional[str] = None


class MerchItemResponse(MerchItemBase):
    id: UUID4
    image_path: Optional[str] = None
    active: bool

    class Config:
        from_attributes = True


class OrderItemBase(BaseModel):
    merch_item_id: UUID4
    qty: int


class OrderCreate(BaseModel):
    items: List[OrderItemBase]


class OrderResponse(BaseModel):
    id: UUID4
    user_id: UUID4
    total_clicks: int
    status: str
    created_at: datetime
    fulfilled_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class VacationApprovalResponse(BaseModel):
    code: str
    boss_name: str



class PaginatedResponse(BaseModel):
    items: List[dict]
    total: int
    page: int
    size: int
    pages: int


class SuccessResponse(BaseModel):
    message: str
    data: Optional[dict] = None


class ErrorResponse(BaseModel):
    detail: str
