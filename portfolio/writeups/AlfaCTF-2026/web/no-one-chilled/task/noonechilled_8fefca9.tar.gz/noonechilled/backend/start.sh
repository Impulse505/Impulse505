#!/bin/bash

echo "🚀 Starting Intranet Backend..."

echo "⏳ Waiting for database to be ready..."
until python -c "
import psycopg2
try:
    conn = psycopg2.connect('$DATABASE_URL')
    conn.close()
    print('Database is ready!')
except:
    print('Database not ready yet...')
    exit(1)
" 2>/dev/null; do
    sleep 2
done

echo "✅ Database is ready!"

echo "🌱 Running database seeding..."
python -m app.db.seeds

WORKERS="${WORKERS:-1}"
echo "🚀 Starting FastAPI application with ${WORKERS} workers..."
exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers "${WORKERS}"
