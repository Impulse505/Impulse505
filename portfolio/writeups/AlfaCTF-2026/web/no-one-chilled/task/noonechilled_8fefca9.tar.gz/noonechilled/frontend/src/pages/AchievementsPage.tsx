import React, { useState, useEffect } from 'react'
import { apiService } from '../lib/api'
import {
  Box,
  Grid,
  Card,
  CardBody,
  VStack,
  HStack,
  Text,
  Heading,
  Badge,
  Progress,
  Icon,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  useDisclosure,
} from '@chakra-ui/react'
import { 
  StarIcon, 
  CheckIcon,
  SpinnerIcon,
} from '@chakra-ui/icons'
import { t } from '../lib/translations'

interface Achievement {
  id: string
  code: string
  name: string
  description: string
  criteria: any
  icon_url?: string
  points: number
}

interface UserAchievement {
  user_id: string
  achievement_id: string
  awarded_at: string
  evidence?: any
  achievement: Achievement
}

interface AchievementProgress {
  achievement: {
    id: string
    code: string
    name: string
    description: string
    points: number
  }
  is_unlocked: boolean
  progress_percentage: number
  current_value: number
  target_value: number
  progress_description: string
}

const AchievementsPage: React.FC = () => {
  const [userAchievements, setUserAchievements] = useState<UserAchievement[]>([])
  const [achievementProgress, setAchievementProgress] = useState<AchievementProgress[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedAchievement, setSelectedAchievement] = useState<AchievementProgress | null>(null)
  const { isOpen, onOpen, onClose } = useDisclosure()

  useEffect(() => {
    fetchUserAchievements()
    fetchAchievementProgress()
  }, [])

  const fetchUserAchievements = async () => {
    try {
      const response = await apiService.getUserAchievements()
      
      if (response.data) {
        setUserAchievements(response.data)
      }
    } catch (error) {
      console.error('Failed to fetch user achievements:', error)
    }
  }

  const fetchAchievementProgress = async () => {
    try {
      const response = await apiService.getAchievementProgress()
      
      if (response.data) {
        setAchievementProgress(response.data)
      }
    } catch (error) {
      console.error('Failed to fetch achievement progress:', error)
    } finally {
      setLoading(false)
    }
  }

  const openAchievementModal = (achievement: AchievementProgress) => {
    setSelectedAchievement(achievement)
    onOpen()
  }

  const getTotalPoints = () => {
    if (!userAchievements || userAchievements.length === 0) {
      return 0
    }
    return userAchievements.reduce((total, ua) => {
      return total + (ua.achievement?.points || 0)
    }, 0)
  }

  const getUnlockedCount = () => {
    if (!achievementProgress || achievementProgress.length === 0) {
      return 0
    }
    return achievementProgress.filter(p => p.is_unlocked).length
  }

  const getTotalCount = () => {
    if (!achievementProgress || achievementProgress.length === 0) {
      return 0
    }
    return achievementProgress.length
  }

  if (loading) {
    return (
      <Box textAlign="center" py={20}>
        <Text color="gray.400">{t('achievements', 'loadingAchievements')}</Text>
      </Box>
    )
  }

  return (
    <Box>
      <VStack spacing={6} align="stretch" mb={8}>
        <Box>
          <Heading size="lg" color="white" mb={2}>
            {t('achievements', 'title')}
          </Heading>
          <Text color="gray.400">
            {t('achievements', 'description')}
          </Text>
        </Box>

        {/* Achievement Stats */}
        <Grid templateColumns={{ base: '1fr', md: 'repeat(3, 1fr)' }} gap={6}>
          <Card bg="crypto.light" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
            <CardBody p={6}>
              <VStack spacing={2}>
                <Icon as={StarIcon} color="crypto.secondary" boxSize={8} />
                <Text color="white" fontSize="2xl" fontWeight="bold">
                  {getUnlockedCount()}/{getTotalCount()}
                </Text>
                <Text color="gray.400" fontSize="sm">{t('achievements', 'unlocked')}</Text>
              </VStack>
            </CardBody>
          </Card>

          <Card bg="crypto.light" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
            <CardBody p={6}>
              <VStack spacing={2}>
                <Icon as={CheckIcon} color="crypto.success" boxSize={8} />
                <Text color="white" fontSize="2xl" fontWeight="bold">
                  {getTotalPoints()}
                </Text>
                <Text color="gray.400" fontSize="sm">{t('achievements', 'totalPoints')}</Text>
              </VStack>
            </CardBody>
          </Card>

          <Card bg="crypto.light" border="1px solid" borderColor="crypto.lighter" borderRadius="xl">
            <CardBody p={6}>
              <VStack spacing={2}>
                <Icon as={SpinnerIcon} color="crypto.secondary" boxSize={8} />
                <Text color="white" fontSize="2xl" fontWeight="bold">
                  {getTotalCount() > 0 ? Math.round((getUnlockedCount() / getTotalCount()) * 100) : 0}%
                </Text>
                <Text color="gray.400" fontSize="sm">{t('achievements', 'completion')}</Text>
              </VStack>
            </CardBody>
          </Card>
        </Grid>

        {/* Achievements Grid */}
        <Grid templateColumns={{ base: '1fr', md: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' }} gap={6}>
          {achievementProgress && achievementProgress.length > 0 ? achievementProgress.map((achievement) => (
            <Card
              key={achievement.achievement.id}
              bg="crypto.light"
              border="1px solid"
              borderColor={achievement.is_unlocked ? "crypto.success" : "crypto.lighter"}
              borderRadius="xl"
              cursor="pointer"
              onClick={() => openAchievementModal(achievement)}
              _hover={{ transform: 'scale(1.02)', borderColor: 'crypto.primary' }}
              transition="all 0.2s"
            >
              <CardBody p={6}>
                <VStack spacing={4} align="stretch">
                  {/* Achievement Header */}
                  <HStack justify="space-between">
                    <VStack align="start" spacing={1}>
                      <Text color="white" fontWeight="bold" fontSize="lg">
                        {achievement.achievement.name}
                      </Text>
                      <Text color="gray.400" fontSize="sm" noOfLines={2}>
                        {achievement.achievement.description}
                      </Text>
                    </VStack>
                    {achievement.is_unlocked && (
                      <Icon as={CheckIcon} color="crypto.success" boxSize={6} />
                    )}
                  </HStack>

                  {/* Progress Bar */}
                  {!achievement.is_unlocked && (
                    <VStack spacing={2} align="stretch">
                      <HStack justify="space-between">
                        <Text color="gray.400" fontSize="sm">
                          {achievement.progress_description || 'Прогресс...'}
                        </Text>
                        <Text color="crypto.primary" fontSize="sm" fontWeight="medium">
                          {Math.round(achievement.progress_percentage || 0)}%
                        </Text>
                      </HStack>
                      <Progress 
                        value={achievement.progress_percentage || 0} 
                        colorScheme="blue" 
                        borderRadius="full"
                        bg="crypto.darker"
                      />
                    </VStack>
                  )}

                  {/* Points */}
                  <HStack justify="space-between">
                    <Badge colorScheme="purple" variant="subtle">
                      {achievement.achievement.points} {t('achievements', 'pts')}
                    </Badge>
                  </HStack>
                </VStack>
              </CardBody>
            </Card>
          )) : (
            <Box textAlign="center" py={10}>
              <Text color="gray.400">{t('achievements', 'loadingAchievements')}</Text>
            </Box>
          )}
        </Grid>
      </VStack>

      {/* Achievement Modal */}
      <Modal isOpen={isOpen} onClose={onClose} size="lg">
        <ModalOverlay />
        <ModalContent bg="crypto.light" border="1px solid" borderColor="crypto.lighter">
          <ModalHeader color="white">
            {selectedAchievement?.achievement.name}
          </ModalHeader>
          <ModalCloseButton color="gray.400" />
          <ModalBody pb={6}>
            {selectedAchievement && (
              <VStack spacing={4} align="stretch">
                {/* Description */}
                <Box>
                  <Text color="gray.300" fontSize="lg" fontWeight="medium" mb={2}>
                    {t('achievements', 'achievementDescription')}
                  </Text>
                  <Text color="gray.400">
                    {selectedAchievement.achievement.description}
                  </Text>
                </Box>

                {/* Progress */}
                {!selectedAchievement.is_unlocked && (
                  <Box>
                    <Text color="gray.300" fontSize="lg" fontWeight="medium" mb={2}>
                      {t('achievements', 'progress')}
                    </Text>
                    <VStack align="stretch" spacing={2}>
                      <HStack justify="space-between">
                        <Text color="gray.400">{t('achievements', 'completion_percentage')}</Text>
                        <Text color="crypto.primary">{Math.round(selectedAchievement.progress_percentage || 0)}%</Text>
                      </HStack>
                      <Progress 
                        value={selectedAchievement.progress_percentage || 0} 
                        colorScheme="blue" 
                        borderRadius="full"
                        bg="crypto.darker"
                      />
                      <Text color="gray.500" fontSize="sm" textAlign="center">
                        {selectedAchievement.progress_description || 'Прогресс...'}
                      </Text>
                    </VStack>
                  </Box>
                )}

                {/* Points */}
                <Box>
                  <Text color="gray.300" fontSize="lg" fontWeight="medium" mb={2}>
                    {t('achievements', 'points')}
                  </Text>
                  <Badge colorScheme="purple" variant="subtle" fontSize="md" p={2}>
                    {selectedAchievement.achievement.points} {t('achievements', 'points')}
                  </Badge>
                </Box>
              </VStack>
            )}
          </ModalBody>
        </ModalContent>
      </Modal>
    </Box>
  )
}

export default AchievementsPage
