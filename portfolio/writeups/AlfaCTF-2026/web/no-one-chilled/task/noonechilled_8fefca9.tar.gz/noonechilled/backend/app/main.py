from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import structlog

from .core.config import settings
from .core.database import Base, engine
from .db import models
from .api import chat, http_dispatch

structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer() if settings.log_format == "json" else structlog.dev.ConsoleRenderer(),
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()

app = FastAPI(
    title="Intranet API",
    description="Professional Clicking Intranet Backend API",
    version="0.1.0",
    openapi_url=None,
    docs_url=None,
    redoc_url=None,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins.split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(chat.router, prefix="/xhr/api")


@app.middleware("http")
async def dispatch_api_http_requests(request, call_next):
    path = request.url.path

    if path.startswith("/xhr/api/"):
        return await http_dispatch.dispatch_api_request(request)

    return await call_next(request)


@app.on_event("startup")
async def startup_event():
    logger.info("Starting Intranet API")
    
    try:
        Base.metadata.create_all(bind=engine)
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error("Failed to create database tables", error=str(e))
        raise


@app.on_event("shutdown")
async def shutdown_event():
    logger.info("Shutting down Intranet API")


@app.get("/healthz")
async def health_check():
    return {"status": "healthy", "service": "intranet-api"}


@app.get("/readyz")
async def readiness_check():
    try:
        with engine.connect() as conn:
            conn.execute("SELECT 1")
        return {"status": "ready", "database": "connected"}
    except Exception as e:
        logger.error("Readiness check failed", error=str(e))
        return JSONResponse(
            status_code=503,
            content={"status": "not ready", "error": "database connection failed"}
        )


@app.get("/")
async def root():
    return {
        "message": "Intranet API",
        "version": "0.1.0",
        "status": "running"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.reload,
        log_level=settings.log_level.lower(),
    )
