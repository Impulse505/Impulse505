import React from 'react'
import { Outlet, useNavigate, useLocation } from 'react-router-dom'
import {
  Box,
  Flex,
  Button,
  Text,
  HStack,
  Avatar,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  MenuDivider,
  useToast,
  Badge,
  VStack,
} from '@chakra-ui/react'
import { 
  ChevronDownIcon,
  ChatIcon,
  SettingsIcon,
} from '@chakra-ui/icons'
import { useAuth } from '../lib/auth'
import { t } from '../lib/translations'

const Layout: React.FC = () => {
  const navigate = useNavigate()
  const location = useLocation()
  const { user, logout } = useAuth()
  const toast = useToast()

  const handleLogout = () => {
    logout()
    toast({
      title: t('auth', 'logoutSuccessful'),
      status: 'success',
      duration: 2000,
    })
  }

  const isActive = (path: string) => {
    return location.pathname === path
  }

  const getNavButtonProps = (path: string) => ({
    variant: isActive(path) ? 'solid' : 'ghost',
    color: 'white',
    onClick: () => navigate(path),
    _hover: { 
      bg: isActive(path) ? 'crypto.success' : 'crypto.light',
      transform: 'translateY(-2px)',
    },
    transition: 'all 0.2s',
  })

  return (
    <Box minH="100vh" bg="crypto.dark">
      {/* Header with gradient background */}
      <Box
        as="header"
        bg="linear-gradient(135deg, crypto.primary 0%, crypto.accent 100%)"
        backdropFilter="blur(10px)"
        borderBottom="1px solid"
        borderColor="crypto.lighter"
        position="sticky"
        top={0}
        zIndex={10}
      >
        <Flex p={4} justify="space-between" align="center" maxW="1400px" mx="auto">
          <HStack spacing={6}>
            <Text 
              fontSize="2xl" 
              fontWeight="bold" 
              cursor="pointer" 
              onClick={() => navigate('/')}
              textShadow="0 2px 4px rgba(0,0,0,0.3)"
            >
              {t('navigation', 'intranet')}
            </Text>
            <HStack spacing={2}>
              <Button {...getNavButtonProps('/')} size="sm">
                {t('navigation', 'dashboard')}
              </Button>

              <Button {...getNavButtonProps('/clicker')} size="sm">
                {t('navigation', 'clicker')}
              </Button>
              <Button {...getNavButtonProps('/chat')} size="sm" leftIcon={<ChatIcon />}>
                {t('navigation', 'chat')}
              </Button>
              <Button {...getNavButtonProps('/store')} size="sm">
                {t('navigation', 'store')}
              </Button>
              <Button {...getNavButtonProps('/achievements')} size="sm">
                {t('navigation', 'achievements')}
              </Button>
              {user?.role === 'boss' && (
                <Button {...getNavButtonProps('/admin')} size="sm" leftIcon={<SettingsIcon />}>
                  {t('navigation', 'admin')}
                </Button>
              )}
            </HStack>
          </HStack>
          
          <HStack spacing={4}>
            <VStack spacing={0} align="end">
              <Text fontSize="sm" color="whiteAlpha.900" fontWeight="medium">
                {user?.display_name}
              </Text>
              <Badge 
                colorScheme={user?.role === 'boss' ? 'purple' : 'green'} 
                variant="solid"
                size="sm"
                borderRadius="full"
              >
                {user?.role === 'boss' ? t('roles', 'boss') : t('roles', 'employee')}
              </Badge>
            </VStack>
            <Menu>
              <MenuButton 
                as={Button} 
                variant="ghost" 
                color="white" 
                rightIcon={<ChevronDownIcon />}
                _hover={{ bg: 'whiteAlpha.200' }}
              >
                <Avatar 
                  size="sm" 
                  name={user?.display_name} 
                  src={user?.avatar_url}
                  bg="crypto.primary"
                />
              </MenuButton>
              <MenuList bg="crypto.light" borderColor="crypto.lighter">
                <MenuItem 
                  onClick={() => navigate(`/profile/${user?.id}`)}
                  _hover={{ bg: 'crypto.lighter' }}
                >
                  {t('navigation', 'profile')}
                </MenuItem>
                <MenuDivider borderColor="crypto.lighter" />
                <MenuItem 
                  onClick={handleLogout}
                  _hover={{ bg: 'crypto.lighter' }}
                >
                  {t('auth', 'logout')}
                </MenuItem>
              </MenuList>
            </Menu>
          </HStack>
        </Flex>
      </Box>
      
      {/* Main content with subtle gradient background */}
      <Box 
        as="main" 
        p={6} 
        bg="linear-gradient(135deg, crypto.dark 0%, crypto.darker 100%)"
        minH="calc(100vh - 80px)"
      >
        <Box maxW="1400px" mx="auto">
          <Outlet />
        </Box>
      </Box>
    </Box>
  )
}

export default Layout
