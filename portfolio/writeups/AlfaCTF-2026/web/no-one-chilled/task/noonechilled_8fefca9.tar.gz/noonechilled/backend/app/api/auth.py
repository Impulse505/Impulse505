from fastapi import HTTPException, Request, Response, status
from sqlalchemy.orm import Session
from ..core.config import settings
from ..core.security import (
    authenticate_user,
    create_user,
    create_access_token,
    create_refresh_token,
    verify_token,
    set_auth_cookies,
    clear_auth_cookies,
)
from ..core.vacation import generate_vacation_code
from ..db.models import User
from ..db.schemas import LoginRequest, RegisterRequest, VacationApprovalResponse


async def register(
    register_data: RegisterRequest,
    response: Response,
    db: Session,
):
    if register_data.role != "employee":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Регистрироваться могут только сотрудники. Аккаунты босса создаются администраторами."
        )
    
    user = create_user(
        db=db,
        email=register_data.email,
        password=register_data.password,
        display_name=register_data.display_name,
        role=register_data.role
    )
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Пользователь с таким email уже существует"
        )

    access_token = create_access_token(data={"sub": str(user.id)})
    refresh_token = create_refresh_token(data={"sub": str(user.id)})
    
    set_auth_cookies(response, access_token, refresh_token)
    
    return {
        "message": "Регистрация успешна",
        "user": {
            "id": str(user.id),
            "email": user.email,
            "display_name": user.display_name,
            "role": user.role
        }
    }


async def login(
    login_data: LoginRequest,
    response: Response,
    db: Session
):
    user = authenticate_user(db, login_data.email, login_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Неверный email или пароль",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Аккаунт пользователя отключен"
        )
    
    
    access_token = create_access_token(data={"sub": str(user.id)})
    refresh_token = create_refresh_token(data={"sub": str(user.id)})
    
    set_auth_cookies(response, access_token, refresh_token)
    
    return {
        "message": "Вход выполнен успешно",
        "user": {
            "id": str(user.id),
            "email": user.email,
            "display_name": user.display_name,
            "role": user.role
        }
    }


async def refresh_token(
    response: Response,
    request: Request,
    db: Session
):
    refresh_token_value = request.cookies.get("refresh_token")
    if not refresh_token_value:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token не найден"
        )
    
    try:
        payload = verify_token(refresh_token_value)
        if payload.get("type") != "refresh":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Неверный тип токена"
            )
        
        user_id = payload.get("sub")
        if user_id is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Неверный токен"
            )
        
        user = db.query(User).filter(User.id == user_id, User.is_active == True).first()
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Пользователь не найден"
            )
        
        
        access_token = create_access_token(data={"sub": str(user.id)})
        new_refresh_token = create_refresh_token(data={"sub": str(user.id)})
        
        set_auth_cookies(response, access_token, new_refresh_token)
        
        return {
            "message": "Токен обновлен",
            "user": {
                "id": str(user.id),
                "email": user.email,
                "display_name": user.display_name,
                "role": user.role
            }
        }
        
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Неверный refresh-токен"
        )


async def logout(response: Response):
    
    clear_auth_cookies(response)
    
    return {"message": "Вы успешно вышли"}


async def get_vacation_access_code(
    current_boss: User
):
    try:
        return {"code": generate_vacation_code(settings.secret_key, str(current_boss.id))}
    except Exception:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Не удалось сгенерировать код")


async def get_vacation_approval(
    current_boss: User,
):
    try:
        return VacationApprovalResponse(
            code=generate_vacation_code(settings.secret_key, str(current_boss.id)),
            boss_name=current_boss.display_name,
        )
    except Exception:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Не удалось загрузить страницу")


async def get_current_user_info(
    current_user: User
):
    
    return current_user
