import base64
import uuid
from typing import List, Optional

from fastapi import HTTPException, Response
from sqlalchemy.orm import Session

from ..db.models import User, MerchItem, Order, OrderItem, ClickLedger
from ..db.schemas import MerchItemCreate, MerchItemUpdate, MerchItemResponse, OrderCreate, OrderResponse
from datetime import datetime


def build_merch_image_path(item_id: uuid.UUID) -> str:
    return f"/xhr/api/store/images/{item_id}.jpg"


def serialize_merch_item(item: MerchItem) -> dict:
    return {
        "id": item.id,
        "sku": item.sku,
        "name": item.name,
        "description": item.description,
        "price_clicks": item.price_clicks,
        "image_path": build_merch_image_path(item.id) if item.product_image else None,
        "inventory": item.inventory,
        "category": item.category,
        "active": item.active,
    }


def decode_product_image(encoded_image: Optional[str]) -> Optional[bytes]:
    if encoded_image is None:
        return None

    try:
        return base64.b64decode(encoded_image, validate=True)
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=422, detail="product_image must be valid base64") from exc


async def create_merch_item(
    item_data: MerchItemCreate,
    db: Session
):

    existing_item = db.query(MerchItem).filter(MerchItem.sku == item_data.sku).first()
    if existing_item:
        raise HTTPException(status_code=400, detail="SKU уже существует")
    
    item = MerchItem(
        sku=item_data.sku,
        name=item_data.name,
        description=item_data.description,
        price_clicks=item_data.price_clicks,
        product_image=decode_product_image(item_data.product_image),
        inventory=item_data.inventory,
        category=item_data.category,
        active=True
    )
    
    db.add(item)
    db.commit()
    db.refresh(item)
    
    return serialize_merch_item(item)


async def list_merch_items(
    db: Session,
    category: Optional[str] = None,
    active_only: bool = True,
    skip: int = 0,
    limit: int = 100
) -> List[MerchItemResponse]:
    query = db.query(MerchItem)
    
    if active_only:
        query = query.filter(MerchItem.active == True)
    
    if category:
        query = query.filter(MerchItem.category == category)
    
    items = query.offset(skip).limit(limit).all()
    return [serialize_merch_item(item) for item in items]


async def get_merch_item(
    item_id: str,
    db: Session
) -> MerchItemResponse:
    
    item = db.query(MerchItem).filter(MerchItem.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Товар не найден")
    
    return serialize_merch_item(item)


async def update_merch_item(
    item_id: str,
    item_update: MerchItemUpdate,
    db: Session
):
    
    item = db.query(MerchItem).filter(MerchItem.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Товар не найден")
    
    
    update_data = item_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        if field == "product_image":
            item.product_image = decode_product_image(value)
            continue
        setattr(item, field, value)
    
    db.commit()
    db.refresh(item)
    
    return serialize_merch_item(item)


async def get_merch_item_image(
    image_name: str,
    db: Session
) -> Response:
    if not image_name.endswith(".jpg"):
        raise HTTPException(status_code=404, detail="Изображение товара не найдено")

    raw_item_id = image_name.removesuffix(".jpg")

    try:
        item_id = uuid.UUID(raw_item_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail="Изображение товара не найдено") from exc

    item = db.query(MerchItem).filter(
        MerchItem.id == item_id,
        MerchItem.active == True
    ).first()
    if not item or not item.product_image:
        raise HTTPException(status_code=404, detail="Изображение товара не найдено")

    return Response(
        content=item.product_image,
        media_type="image/jpeg",
    )


async def delete_merch_item(
    item_id: str,
    db: Session
):
    
    item = db.query(MerchItem).filter(MerchItem.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    
    
    item.active = False
    db.commit()
    
    return {"message": "Товар успешно деактивирован"}


async def create_order(
    order_data: OrderCreate,
    current_user: User,
    db: Session
):
    
    if not order_data.items:
        raise HTTPException(status_code=400, detail="Заказ должен содержать хотя бы один товар")
    
    
    total_clicks = 0
    order_items = []
    
    for item_data in order_data.items:
        item = db.query(MerchItem).filter(
            MerchItem.id == item_data.merch_item_id,
            MerchItem.active == True
        ).first()
        
        if not item:
            raise HTTPException(status_code=404, detail=f"Товар {item_data.merch_item_id} не найден")
        
        if item.inventory < item_data.qty:
            raise HTTPException(status_code=400, detail=f"Недостаточное количество для {item.name}")
        
        total_clicks += item.price_clicks * item_data.qty
        order_items.append((item, item_data.qty))
    
    
    
    balance = 0
    ledger_entries = db.query(ClickLedger).filter(ClickLedger.user_id == current_user.id).all()
    for entry in ledger_entries:
        balance += entry.delta
    
    if balance < total_clicks:
        raise HTTPException(status_code=400, detail="Недостаточно кликов")
    
    
    order = Order(
        user_id=current_user.id,
        total_clicks=total_clicks,
        status="placed"
    )
    
    db.add(order)
    db.commit()
    db.refresh(order)
    
    
    for item, qty in order_items:
        order_item = OrderItem(
            order_id=order.id,
            merch_item_id=item.id,
            qty=qty,
            unit_price_clicks=item.price_clicks
        )
        db.add(order_item)
        
        
        item.inventory -= qty
    
    
    ledger_entry = ClickLedger(
        user_id=current_user.id,
        delta=-total_clicks,
        reason="purchase",
        balance_after=balance - total_clicks
    )
    db.add(ledger_entry)
    
    db.commit()
    
    return order


async def list_orders(
    current_user: User,
    db: Session,
    status_filter: Optional[str] = None,
    skip: int = 0,
    limit: int = 100
) -> List[OrderResponse]:
    
    query = db.query(Order)
    
    
    if current_user.role != "boss":
        query = query.filter(Order.user_id == current_user.id)
    
    if status_filter:
        query = query.filter(Order.status == status_filter)
    
    orders = query.order_by(Order.created_at.desc()).offset(skip).limit(limit).all()
    return orders


async def get_order(
    order_id: str,
    current_user: User,
    db: Session
) -> OrderResponse:
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Заказ не найден")

    if current_user.role != "boss" and order.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Нет прав для просмотра этого заказа")
    
    return order


async def fulfill_order(
    order_id: str,
    current_user: User,
    db: Session
):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Заказ не найден")
    
    if order.status != "placed":
        raise HTTPException(status_code=400, detail="Заказ не размещен")
    
    order.status = "fulfilled"
    order.fulfilled_at = datetime.utcnow()
    db.commit()
    
    return {"message": "Заказ успешно выполнен"}


async def get_click_balance(
    current_user: User,
    db: Session
):
    balance = 0
    ledger_entries = db.query(ClickLedger).filter(ClickLedger.user_id == current_user.id).all()
    
    for entry in ledger_entries:
        balance += entry.delta
    
    return {
        "user_id": str(current_user.id),
        "balance": balance,
        "currency": "clicks"
    }


async def get_categories(
    current_user: User,
    db: Session
):
    categories = db.query(MerchItem.category).filter(
        MerchItem.active == True,
        MerchItem.category.isnot(None)
    ).distinct().all()
    
    return [cat[0] for cat in categories]


async def record_click(
    current_user: User,
    db: Session
):
    from datetime import datetime, timedelta
    from sqlalchemy import func, and_
    
    today = datetime.utcnow().date()
    
    result = db.query(
        func.coalesce(func.sum(ClickLedger.delta), 0).label('total_balance'),
        func.count(ClickLedger.id).label('today_clicks')
    ).filter(
        and_(
            ClickLedger.user_id == current_user.id,
            func.date(ClickLedger.created_at) == today,
            ClickLedger.reason == "clicker_job"
        )
    ).first()
    
    current_balance = db.query(func.coalesce(func.sum(ClickLedger.delta), 0)).filter(
        ClickLedger.user_id == current_user.id
    ).scalar()
    
    today_clicks = result.today_clicks if result else 0
    
    click_reward = 1
    
    max_daily_clicks = 1000
    if today_clicks >= max_daily_clicks:
        raise HTTPException(
            status_code=429, 
            detail=f"Достигнут дневной лимит кликов ({max_daily_clicks} кликов в день)"
        )
    
    ledger_entry = ClickLedger(
        user_id=current_user.id,
        delta=click_reward,
        reason="clicker_job",
        balance_after=current_balance + click_reward
    )
    db.add(ledger_entry)

    from ..api.achievements import check_achievement_progress
    achievement_result = {
        "awarded_count": 0,
        "awarded_achievements": []
    }
    try:
        checked = await check_achievement_progress(current_user, db)
        if checked and isinstance(checked, dict):
            achievement_result = checked
    except Exception as e:
        print(f"Achievement check error: {e}")
    
    db.commit()
    
    return {
        "message": "Клик успешно засчитан",
        "clicks_earned": click_reward,
        "new_balance": current_balance + click_reward,
        "daily_clicks": today_clicks + 1,
        "max_daily_clicks": max_daily_clicks,
        **achievement_result
    }


async def get_clicker_stats(
    current_user: User,
    db: Session
):
    
    from datetime import datetime, timedelta
    from sqlalchemy import func, and_
    
    today = datetime.utcnow().date()
    
    stats = db.query(
        func.coalesce(func.sum(ClickLedger.delta), 0).label('current_balance'),
        func.count(ClickLedger.id).label('today_clicks')
    ).filter(
        and_(
            ClickLedger.user_id == current_user.id,
            func.date(ClickLedger.created_at) == today,
            ClickLedger.reason == "clicker_job"
        )
    ).first()
    
    current_balance = db.query(func.coalesce(func.sum(ClickLedger.delta), 0)).filter(
        ClickLedger.user_id == current_user.id
    ).scalar()
    
    total_clicks_earned = db.query(func.coalesce(func.sum(ClickLedger.delta), 0)).filter(
        and_(
            ClickLedger.user_id == current_user.id,
            ClickLedger.delta > 0
        )
    ).scalar()
    
    today_clicks = stats.today_clicks if stats else 0
    
    streak = 0
    current_date = today
    for _ in range(30):
        day_clicks = db.query(func.count(ClickLedger.id)).filter(
            and_(
                ClickLedger.user_id == current_user.id,
                ClickLedger.reason == "clicker_job",
                func.date(ClickLedger.created_at) == current_date
            )
        ).scalar() or 0
        
        if day_clicks > 0:
            streak += 1
            current_date -= timedelta(days=1)
        else:
            break
    
    return {
        "current_balance": current_balance,
        "today_clicks": today_clicks,
        "total_clicks_earned": total_clicks_earned,
        "click_streak": streak,
        "max_daily_clicks": 1000
    }
