import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  publicDir: 'public',
  server: {
    port: 3001,
    host: true,
    proxy: {
      '/xhr': {
        target: process.env.VITE_API_URL || 'http://localhost:8000',
        changeOrigin: true,
        timeout: 10000,
      },
      '/ws': {
        target: process.env.VITE_WS_URL || 'ws://localhost:8000',
        ws: true,
        rewrite: (path) => path.replace(/^\/ws/, '/xhr'),
      },
    },
  },
  build: {
    outDir: 'dist',
    sourcemap: true,
  },
})
