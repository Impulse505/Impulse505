import React, { useEffect, useState } from 'react'
import {
  Box,
  Flex,
  Text,
  Spinner,
  Center,
  VStack,
} from '@chakra-ui/react'
import { t } from '../lib/translations'
import { apiService } from '../lib/api'

interface VacationApprovalCard {
  code: string
  boss_name: string
}

const VacationApprovalPage: React.FC = () => {
  const [loading, setLoading] = useState(true)
  const [cardData, setCardData] = useState<VacationApprovalCard | null>(null)
  const [error, setError] = useState('')

  useEffect(() => {
    fetchCardData()
  }, [])

  const fetchCardData = async () => {
    const response = await apiService.getVacationApprovalCard()

    if (response.data) {
      setCardData(response.data)
    } else {
      setError(response.error || t('common', 'error'))
    }

    setLoading(false)
  }

  if (loading) {
    return (
      <Center minH="calc(100vh - 180px)">
        <VStack spacing={4}>
          <Spinner size="xl" color="white" />
          <Text color="gray.300">{t('common', 'loading')}</Text>
        </VStack>
      </Center>
    )
  }

  if (error || !cardData) {
    return (
      <Center minH="calc(100vh - 180px)">
        <Text color="red.300">
          {error || t('errors', 'serverError')}
        </Text>
      </Center>
    )
  }

  return (
    <Flex minH="calc(100vh - 180px)" align="center" justify="center">
      <Box
        bgGradient="linear-gradient(135deg, #1e293b, #1d4ed8)"
        borderRadius="20px"
        p={10}
        maxW="520px"
        w="100%"
        boxShadow="0 20px 60px rgba(0, 0, 0, 0.4)"
        textAlign="left"
      >
        <Text
          color="#93c5fd"
          fontSize="13px"
          letterSpacing="2px"
          textTransform="uppercase"
          mb="16px"
        >
          {t('admin', 'vacationApprovalTitle')}
        </Text>
        <Text fontSize="2xl" fontWeight="700" mb="8px" color="white">
          {cardData.boss_name}
        </Text>
        <Text color="#cbd5e1" fontSize="14px" mb="24px">
          {t('admin', 'vacationApprovalHint')}
        </Text>
        <Box
          bg="#eff6ff"
          borderRadius="12px"
          px={6}
          py={4}
          display="inline-block"
          mb={6}
        >
          <Text
            color="#0f172a"
            fontFamily="SF Mono,Consolas,monospace"
            fontSize="28px"
            fontWeight="700"
            letterSpacing="3px"
          >
            {cardData.code}
          </Text>
        </Box>
        <Text color="#64748b" fontSize="12px">
          {t('admin', 'vacationApprovalFooter')}
        </Text>
      </Box>
    </Flex>
  )
}

export default VacationApprovalPage
