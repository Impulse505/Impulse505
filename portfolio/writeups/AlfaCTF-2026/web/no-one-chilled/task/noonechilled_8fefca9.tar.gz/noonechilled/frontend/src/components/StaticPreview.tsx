import React, { useState, useEffect } from 'react'
import {
  Box,
  VStack,
  Text,
  Image,
  Spinner,
} from '@chakra-ui/react'
import { StaticPreview, generatePreview, getFileIcon } from '../lib/staticPreview'

interface StaticPreviewProps {
  preview: StaticPreview
  isOwnMessage?: boolean
}

const StaticPreviewComponent: React.FC<StaticPreviewProps> = ({ preview, isOwnMessage = false }) => {
  const [previewContent, setPreviewContent] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    const loadPreview = async () => {
      setIsLoading(true)
      try {
        const content = await generatePreview(preview)
        setPreviewContent(content)
      } catch (error) {
        console.error('Failed to load preview:', error)
      } finally {
        setIsLoading(false)
      }
    }

    loadPreview()
  }, [preview.url, preview.type])

  const handleClick = () => {
    window.open(preview.url, '_blank')
  }

  return (
    <Box
      mt={2}
      p={3}
      bg={isOwnMessage ? 'blue.50' : 'gray.50'}
      borderRadius="md"
      border="1px solid"
      borderColor={isOwnMessage ? 'blue.200' : 'gray.200'}
      cursor="pointer"
      _hover={{
        bg: isOwnMessage ? 'blue.100' : 'gray.100',
        transform: 'translateY(-1px)',
        boxShadow: 'sm'
      }}
      transition="all 0.2s"
      onClick={handleClick}
    >
      <VStack align="start" spacing={2}>
        {previewContent && !isLoading && preview.type === 'image' && (
          <Image
            src={previewContent}
            alt={preview.filename}
            maxH="200px"
            maxW="300px"
            objectFit="cover"
            borderRadius="md"
            fallback={
              <Box
                h="100px"
                bg="gray.200"
                borderRadius="md"
                display="flex"
                alignItems="center"
                justifyContent="center"
              >
                <Text color="gray.500">Генерация превью...</Text>
              </Box>
            }
          />
        )}

        {previewContent && !isLoading && preview.type !== 'image' && (
          <Box
            p={3}
            bg="white"
            borderRadius="md"
            border="1px solid"
            borderColor="gray.200"
            display="flex"
            alignItems="center"
            gap={3}
          >
            <Text fontSize="2xl">{getFileIcon(preview.type)}</Text>
            <VStack align="start" spacing={1} flex={1}>
              <Text fontSize="sm" fontWeight="medium" color="gray.700">
                {preview.filename}
              </Text>
              <Text fontSize="xs" color="gray.500">
                {preview.extension.toUpperCase()} файл
              </Text>
            </VStack>
          </Box>
        )}

        {(!previewContent || isLoading) && (
          <Box
            h="100px"
            bg="gray.200"
            borderRadius="md"
            display="flex"
            alignItems="center"
            justifyContent="center"
          >
            {isLoading ? (
              <Spinner size="sm" />
            ) : (
              <Text fontSize="sm" color="gray.600">
                Генерация превью...
              </Text>
            )}
          </Box>
        )}
      </VStack>
    </Box>
  )
}

export default StaticPreviewComponent
