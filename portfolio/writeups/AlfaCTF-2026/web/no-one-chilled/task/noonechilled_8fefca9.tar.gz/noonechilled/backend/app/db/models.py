from datetime import datetime
from typing import Optional
from sqlalchemy import Column, String, Integer, Boolean, DateTime, ForeignKey, Text, JSON, Enum, LargeBinary
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
import uuid
from ..core.database import Base


class User(Base):
    __tablename__ = "users"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)
    role = Column(Enum('boss', 'employee', name='user_role'), nullable=False)
    display_name = Column(String(255), nullable=False)
    avatar_url = Column(String(500), nullable=True)
    timezone = Column(String(50), default='UTC')
    created_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    click_ledger_entries = relationship("ClickLedger", back_populates="user")
    user_achievements = relationship("UserAchievement", back_populates="user")
    chat_memberships = relationship("ChatMembership", back_populates="user")
    messages = relationship("Message", back_populates="sender")
    orders = relationship("Order", back_populates="user")


class ClickLedger(Base):
    __tablename__ = "click_ledger"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False, index=True)
    delta = Column(Integer, nullable=False)  
    reason = Column(Enum('bonus', 'purchase', 'admin_adjustment', 'clicker_job', name='ledger_reason'), 
                   nullable=False)
    related_task_id = Column(UUID(as_uuid=True), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    balance_after = Column(Integer, nullable=False)
    user = relationship("User", back_populates="click_ledger_entries")


class Achievement(Base):
    __tablename__ = "achievements"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    code = Column(String(100), unique=True, nullable=False)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    criteria = Column(JSON, nullable=True)
    icon_url = Column(String(500), nullable=True)
    points = Column(Integer, default=0)
    user_achievements = relationship("UserAchievement", back_populates="achievement")


class UserAchievement(Base):
    __tablename__ = "user_achievements"
    
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), primary_key=True)
    achievement_id = Column(UUID(as_uuid=True), ForeignKey("achievements.id"), primary_key=True)
    awarded_at = Column(DateTime, default=datetime.utcnow)
    evidence = Column(JSON, nullable=True)
    user = relationship("User", back_populates="user_achievements")
    achievement = relationship("Achievement", back_populates="user_achievements")


class ChatRoom(Base):
    __tablename__ = "chat_rooms"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    kind = Column(Enum('global', 'dm', name='room_kind'), nullable=False)
    title = Column(String(255), nullable=False)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    memberships = relationship("ChatMembership", back_populates="room")
    messages = relationship("Message", back_populates="room")


class ChatMembership(Base):
    __tablename__ = "chat_memberships"
    
    room_id = Column(UUID(as_uuid=True), ForeignKey("chat_rooms.id"), primary_key=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), primary_key=True)
    role = Column(Enum('member', 'moderator', name='membership_role'), default='member')
    joined_at = Column(DateTime, default=datetime.utcnow)
    last_read_at = Column(DateTime, nullable=True)
    room = relationship("ChatRoom", back_populates="memberships")
    user = relationship("User", back_populates="chat_memberships")


class Message(Base):
    __tablename__ = "messages"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    room_id = Column(UUID(as_uuid=True), ForeignKey("chat_rooms.id"), nullable=False, index=True)
    sender_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    body = Column(Text, nullable=False)
    attachments = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    edited_at = Column(DateTime, nullable=True)
    deleted_at = Column(DateTime, nullable=True)
    room = relationship("ChatRoom", back_populates="messages")
    sender = relationship("User", back_populates="messages")


class MerchItem(Base):
    __tablename__ = "merch_items"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    sku = Column(String(100), unique=True, nullable=False)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    price_clicks = Column(Integer, nullable=False)
    product_image = Column(LargeBinary, nullable=True)
    inventory = Column(Integer, nullable=False, default=0)
    active = Column(Boolean, default=True)
    category = Column(String(100), nullable=True)
    order_items = relationship("OrderItem", back_populates="merch_item")


class Order(Base):
    __tablename__ = "orders"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    total_clicks = Column(Integer, nullable=False)
    status = Column(Enum('placed', 'fulfilled', 'canceled', name='order_status'), 
                   default='placed')
    created_at = Column(DateTime, default=datetime.utcnow)
    fulfilled_at = Column(DateTime, nullable=True)
    user = relationship("User", back_populates="orders")
    items = relationship("OrderItem", back_populates="order")


class OrderItem(Base):
    __tablename__ = "order_items"
    
    order_id = Column(UUID(as_uuid=True), ForeignKey("orders.id"), primary_key=True)
    merch_item_id = Column(UUID(as_uuid=True), ForeignKey("merch_items.id"), primary_key=True)
    qty = Column(Integer, nullable=False)
    unit_price_clicks = Column(Integer, nullable=False)
    order = relationship("Order", back_populates="items")
    merch_item = relationship("MerchItem", back_populates="order_items")
