import aiohttp
import asyncio
from typing import Optional
from loguru import logger
from config import settings


class BotAuth:
    def __init__(self):
        self.session: Optional[aiohttp.ClientSession] = None
        self.api_base_url = settings.api_base_url
        self.is_authenticated = False
    
    async def initialize(self):
        
        timeout = aiohttp.ClientTimeout(total=30, connect=10)
        self.session = aiohttp.ClientSession(
            timeout=timeout,
            connector=aiohttp.TCPConnector(limit=10, limit_per_host=5),
            cookie_jar = aiohttp.CookieJar()
        )
        logger.info("Bot auth initialized")
    
    async def close(self):
        
        if self.session:
            await self.session.close()
            logger.info("Bot auth closed")
    
    async def authenticate(self) -> bool:
        try:
            login_data = {
                "email": settings.bot_username,
                "password": settings.bot_password
            }
            
            login_url = f"{self.api_base_url}/xhr/api/auth/login"
            
            async with self.session.post(login_url, json=login_data) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("message") == "Вход выполнен успешно":
                        self.is_authenticated = True
                        logger.info(f"Bot authenticated successfully as {settings.bot_username}")
                        return True
                    else:
                        logger.error("Authentication response format unexpected")
                        return False
                else:
                    error_text = await response.text()
                    logger.error(f"Authentication failed: {response.status} - {error_text}")
                    return False
                    
        except Exception as e:
            logger.error(f"Authentication error: {e}")
            return False
    
    async def get_websocket_token(self) -> Optional[str]:
        try:
            if self.is_authenticated:
                token_url = f"{self.api_base_url}/xhr/api/chat/ws-token"
                
                async with self.session.get(token_url) as response:
                    if response.status == 200:
                        data = await response.json()
                        token = data.get("token")
                        if token:
                            logger.info("WebSocket token obtained successfully")
                            return token
                        else:
                            logger.error("No token in WebSocket token response")
                            return None
                    elif response.status in [401, 403]:
                        logger.warning("Token request failed due to authentication issues, re-authenticating")
                        self.is_authenticated = False
                    else:
                        error_text = await response.text()
                        logger.error(f"Failed to get WebSocket token: {response.status} - {error_text}")
                        return None
            
            if not self.is_authenticated:
                if not await self.authenticate():
                    return None
                
                token_url = f"{self.api_base_url}/xhr/api/chat/ws-token"
                
                async with self.session.get(token_url) as response:
                    if response.status == 200:
                        data = await response.json()
                        token = data.get("token")
                        if token:
                            logger.info("WebSocket token obtained successfully after re-authentication")
                            return token
                        else:
                            logger.error("No token in WebSocket token response after re-authentication")
                            return None
                    else:
                        error_text = await response.text()
                        logger.error(f"Failed to get WebSocket token after re-authentication: {response.status} - {error_text}")
                        return None
                    
        except Exception as e:
            logger.error(f"Error getting WebSocket token: {e}")
            return None
    
    async def check_authentication(self) -> bool:
        
        if not self.is_authenticated:
            return await self.authenticate()
        return True
    
    async def refresh_auth_if_needed(self) -> bool:
        try:
            if not self.is_authenticated:
                return await self.authenticate()
            
            test_url = f"{self.api_base_url}/xhr/api/auth/me" 
            
            async with self.session.get(test_url) as response:
                if response.status in [401, 403]:
                    logger.warning("Authentication expired, refreshing...")
                    self.is_authenticated = False
                    return await self.authenticate()
                elif response.status == 200:
                    return True
                else:
                    logger.warning(f"Unexpected response checking auth: {response.status}")
                    return True  
                    
        except Exception as e:
            logger.error(f"Error checking authentication status: {e}")
            self.is_authenticated = False
            return await self.authenticate()


bot_auth = BotAuth()
