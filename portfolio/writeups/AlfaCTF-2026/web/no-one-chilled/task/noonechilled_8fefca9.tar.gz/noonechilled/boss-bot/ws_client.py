import aiohttp
from typing import Optional
from loguru import logger


class ChatWebSocketClient:
    def __init__(self):
        self.session: Optional[aiohttp.ClientSession] = None
        self.ws_base_url: Optional[str] = None

    async def initialize(self, http_base_url: str):
        timeout = aiohttp.ClientTimeout(total=30, connect=10)
        self.session = aiohttp.ClientSession(timeout=timeout)
        if http_base_url.startswith("https://"):
            self.ws_base_url = "wss://" + http_base_url[len("https://"):]
        elif http_base_url.startswith("http://"):
            self.ws_base_url = "ws://" + http_base_url[len("http://"):]
        else:
            self.ws_base_url = http_base_url
        logger.info(f"WS client initialized, base={self.ws_base_url}")

    async def close(self):
        if self.session:
            await self.session.close()
            self.session = None
            logger.info("WS client closed")

    async def send_message(self, room_id: str, body: str, token: str, attachments: Optional[dict] = None) -> bool:
        assert self.session is not None, "WS client not initialized"
        assert self.ws_base_url is not None, "WS base URL not set"

        ws_url = f"{self.ws_base_url}/ws/api/chat/ws/{room_id}?token={token}"
        logger.info(f"Attempting to connect to WS: {ws_url}")
        try:
            async with self.session.ws_connect(ws_url, timeout=15) as ws:
                payload = {
                    "type": "message",
                    "body": body,
                }
                if attachments is not None:
                    payload["attachments"] = attachments

                logger.info(f"Sending payload to WS: {payload}")
                await ws.send_json(payload)
                
                try:
                    msg = await ws.receive(timeout=2)
                    if msg.type == aiohttp.WSMsgType.TEXT:
                        logger.info(f"WS ack/echo for room {room_id}: {msg.data}")
                except Exception as e:
                    logger.info(f"No WS response received: {e}")
                    pass
                logger.info(f"WS message sent to room {room_id}")
                return True
        except Exception as e:
            logger.error(f"Failed to send WS message to room {room_id}: {e}")
            return False


ws_client = ChatWebSocketClient()
