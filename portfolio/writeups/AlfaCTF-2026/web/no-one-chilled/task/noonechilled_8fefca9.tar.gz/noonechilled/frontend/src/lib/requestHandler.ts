export interface RequestOptions {
  method?: string
  headers?: Record<string, string>
  body?: any
  redirect?: RequestRedirect
}

export function createRequestHandler() {
  return {
    async fetch(url: string, options: RequestOptions = {}): Promise<Response> {
      const isSameOrigin = isSameOriginUrl(url)
      const headers: Record<string, string> = { ...options.headers }
      
      if (isSameOrigin) {
        const token = localStorage.getItem('access_token')
        if (token) {
          headers['Authorization'] = `Bearer ${token}`
        }
      }
      
      const fetchOptions: RequestInit = {
        method: options.method || 'GET',
        headers,
        redirect: headers['Authorization'] ? 'manual' : 'follow'
      }
      
      if (options.body) {
        fetchOptions.body = options.body
      }
      
      return fetch(url, fetchOptions)
    }
  }
}

function isSameOriginUrl(url: string): boolean {
  try {
    const target = new URL(url)
    return target.origin === window.location.origin
  } catch {
    return false
  }
}

export const requestHandler = createRequestHandler()
