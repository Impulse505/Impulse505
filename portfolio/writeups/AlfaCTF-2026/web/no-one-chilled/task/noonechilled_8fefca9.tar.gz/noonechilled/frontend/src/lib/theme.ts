import { extendTheme, type ThemeConfig } from '@chakra-ui/react'

const config: ThemeConfig = {
  initialColorMode: 'dark',
  useSystemColorMode: false,
}

const theme = extendTheme({
  config,
  colors: {
    brand: {
      50: '#e6f7ff',
      100: '#b3e0ff',
      200: '#80c9ff',
      300: '#4db2ff',
      400: '#1a9bff',
      500: '#0084ff',
      600: '#0066cc',
      700: '#004799',
      800: '#002966',
      900: '#000a33',
    },
    crypto: {
      primary: '#00d4aa',
      secondary: '#ff6b35',
      accent: '#6366f1',
      success: '#10b981',
      warning: '#f59e0b',
      error: '#ef4444',
      dark: '#0f172a',
      darker: '#020617',
      light: '#1e293b',
      lighter: '#334155',
    },
    gray: {
      50: '#f8fafc',
      100: '#f1f5f9',
      200: '#e2e8f0',
      300: '#cbd5e1',
      400: '#94a3b8',
      500: '#64748b',
      600: '#475569',
      700: '#334155',
      800: '#1e293b',
      900: '#0f172a',
    },
  },
  fonts: {
    heading: 'Inter, system-ui, sans-serif',
    body: 'Inter, system-ui, sans-serif',
  },
  styles: {
    global: {
      body: {
        bg: 'crypto.dark',
        color: 'white',
      },
    },
  },
  components: {
    Button: {
      baseStyle: {
        fontWeight: 'semibold',
        borderRadius: 'lg',
      },
      variants: {
        solid: {
          bg: 'crypto.primary',
          color: 'white',
          _hover: {
            bg: 'crypto.success',
            transform: 'translateY(-2px)',
            boxShadow: 'lg',
          },
          _active: {
            transform: 'translateY(0)',
          },
        },
        outline: {
          borderColor: 'crypto.primary',
          color: 'crypto.primary',
          _hover: {
            bg: 'crypto.primary',
            color: 'white',
          },
        },
        ghost: {
          color: 'crypto.primary',
          _hover: {
            bg: 'crypto.light',
          },
        },
      },
    },
    Card: {
      baseStyle: {
        container: {
          bg: 'crypto.light',
          border: '1px solid',
          borderColor: 'crypto.lighter',
          borderRadius: 'xl',
          backdropFilter: 'blur(10px)',
        },
      },
    },
    Input: {
      baseStyle: {
        field: {
          bg: 'crypto.light',
          borderColor: 'crypto.lighter',
          _focus: {
            borderColor: 'crypto.primary',
            boxShadow: '0 0 0 1px var(--chakra-colors-crypto-primary)',
          },
        },
      },
    },
    Select: {
      baseStyle: {
        field: {
          bg: 'crypto.light',
          borderColor: 'crypto.lighter',
          _focus: {
            borderColor: 'crypto.primary',
            boxShadow: '0 0 0 1px var(--chakra-colors-crypto-primary)',
          },
        },
      },
    },
    Textarea: {
      baseStyle: {
        bg: 'crypto.light',
        borderColor: 'crypto.lighter',
        _focus: {
          borderColor: 'crypto.primary',
          boxShadow: '0 0 0 1px var(--chakra-colors-crypto-primary)',
        },
      },
    },
  },
})

export default theme
